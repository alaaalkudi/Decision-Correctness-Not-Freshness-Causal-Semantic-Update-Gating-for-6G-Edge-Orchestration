"""Assemble content.json for the manuscript. Every number is computed at build
time from the measured result files in results/."""
import os, json
import numpy as np
import pandas as pd
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, 'results')

ORDER = ['Cloud-Only', 'Edge-Only', 'Latency-Aware', 'AoI-Aware', 'AoII-Aware',
         'UoI-Aware', 'DRL (DQN)', 'DRL-CF', 'Semantic-Aware', 'Goal-Oriented',
         'CoFA', 'CoFA-E']
BASE = ORDER[:10]
SCEN = ['S1', 'S2', 'S3']

main = pd.read_csv(os.path.join(RES, 'e1_main.csv'))
adm = pd.read_csv(os.path.join(RES, 'e9_admission.csv'))


def _tab(df, sc):
    return df[df.scenario == sc] if sc else df


def M(sc, m, col, df=None):
    d = main if df is None else df
    return d[(d.scenario == sc) & (d.method == m)][col].mean()


def CI(sc, m, col, df=None):
    d = main if df is None else df
    x = d[(d.scenario == sc) & (d.method == m)][col]
    return 1.96 * x.std(ddof=1) / np.sqrt(len(x))


def pair(sc, a='CoFA', b='Edge-Only', col='critical_accuracy', df=None):
    d = main if df is None else df
    A = d[(d.scenario == sc) & (d.method == a)].sort_values('seed')[col].values
    B = d[(d.scenario == sc) & (d.method == b)].sort_values('seed')[col].values
    dd = A - B
    t = stats.ttest_rel(A, B)
    w = stats.wilcoxon(A, B)
    return dict(delta=dd.mean(), t=t.statistic, p=t.pvalue, wp=w.pvalue,
                dz=dd.mean() / dd.std(ddof=1))


def pfmt(p):
    if p < 1e-12:
        return 'p < 10^-12'
    return f'p < 10^{int(np.floor(np.log10(p))) + 1}'


def best_base(sc, col, maximize=True, df=None):
    d = main if df is None else df
    vals = {m: M(sc, m, col, d) for m in BASE}
    return (max if maximize else min)(vals, key=vals.get)


def red(sc, col, m='CoFA', ref='Edge-Only', df=None):
    return 100.0 * (1 - M(sc, m, col, df) / M(sc, ref, col, df))


# --- where the decision-modelling families actually land ---------------------
# The claim that they occupy the top of the ranking is the thesis of the paper
# and must never be asserted from memory: it is computed here, once, from the
# measured table, and every sentence that states it interpolates the result.
_FAM = {'CoFA': 'CoFA', 'CoFA-E': 'CoFA', 'AoII-Aware': 'AoII-triggered',
        'Goal-Oriented': 'goal-oriented', 'DRL-CF': 'decision-centric learner'}
_AWARE = ['CoFA', 'AoII-triggered', 'goal-oriented', 'decision-centric learner']
_ORD = {}


def _fam_rank(df, sc=None):
    d = df if sc is None else df[df.scenario == sc]
    g = d.groupby('method').critical_accuracy.mean()
    best = {}
    for m, v in g.items():
        f = _FAM.get(m, m)
        best[f] = max(best.get(f, -1e18), v)
    order = sorted(best, key=lambda k: -best[k])
    return {f: i + 1 for i, f in enumerate(order)}, len(order)


for _sc in SCEN:
    _ORD[_sc] = _fam_rank(main, _sc)

_nfam = _ORD['S1'][1]
_hand = [f for f in _AWARE if f != 'decision-centric learner']
_hand_top = max(max(_ORD[s][0][f] for f in _hand) for s in SCEN)
_learn_rank = {s: _ORD[s][0]['decision-centric learner'] for s in SCEN}
_learn_bad = [s for s in SCEN if _learn_rank[s] > len(_AWARE)]
_learn_ok = [s for s in SCEN if s not in _learn_bad]


def _ordinal(n):
    return {1: 'first', 2: 'second', 3: 'third', 4: 'fourth', 5: 'fifth',
            6: 'sixth', 7: 'seventh', 8: 'eighth'}.get(n, f'{n}th')


def _word(n):
    return {1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six",
            7: "seven", 8: "eight", 9: "nine", 10: "ten", 11: "eleven",
            12: "twelve"}.get(n, str(n))


def _places(ss):
    # "fourth in S2 and S3" rather than "fourth in S2 and fourth in S3"
    by = {}
    for x in ss:
        by.setdefault(_ordinal(_learn_rank[x]), []).append(x)
    return " and ".join(f'{o} in {" and ".join(v)}' for o, v in by.items())


# one sentence, generated, used verbatim wherever the claim is made
if not _learn_bad:
    CLUSTER = (f"the four decision-modelling families take the top "
               f"{_word(len(_AWARE))} places among the {_word(_nfam)} families "
               f"in all three scenarios")
else:
    CLUSTER = (
        f"the {_word(len(_hand))} hand-designed decision-modelling families "
        f"take the top {_word(len(_hand))} places among the {_word(_nfam)} "
        f"families in all three scenarios, while the fourth - the "
        f"decision-centric learned policy - ranks {_places(_learn_ok)} but "
        f"only {_places(_learn_bad)}")
CLUSTER_SHORT = ("occupy the top of the ranking in every scenario"
                 if not _learn_bad else
                 f"take the top {_word(len(_hand))} places in every scenario, "
                 f"the learned member of the group falling to "
                 f"{_places(_learn_bad)}")


B = []


def add(t, **kw):
    B.append(dict(t=t, **kw))


# Tokens that carry a computed statement into a raw (non-f) prose block.  The
# thesis sentence must not be typed out by hand anywhere, and the blocks that
# state it are raw strings because they contain mathematics, so it is
# substituted here instead.
TOKENS = {'@@CLUSTER@@': lambda: CLUSTER,
          '@@CLUSTER_SHORT@@': lambda: CLUSTER_SHORT}


def md(text, span=1):
    """Blocks: '#','##','###' headings; '$ ' equation (optional '|| number');
    '> ' unindented paragraph; blank line separates paragraphs."""
    for k, v in TOKENS.items():
        if k in text:
            text = text.replace(k, v())
    buf = []

    def flush():
        if buf:
            add('p', text=' '.join(buf).strip())
            buf.clear()

    for raw in text.strip('\n').split('\n'):
        line = raw.strip()
        if not line:
            flush(); continue
        if line.startswith('### '):
            flush(); add('h3', text=line[4:])
        elif line.startswith('## '):
            flush(); add('h2', text=line[3:])
        elif line.startswith('# '):
            flush(); add('h1', text=line[2:])
        elif line.startswith('$ '):
            flush()
            body = line[2:]; num = None
            if '||' in body:
                body, num = body.split('||'); body, num = body.strip(), num.strip()
            add('eq', text=body, num=num)
        elif line.startswith('> '):
            flush(); add('p0', text=line[2:])
        else:
            buf.append(line)
    flush()

# ===========================================================================
add('title', text='Decision Correctness, Not Freshness: Causal-Semantic Update '
                  'Gating for 6G Edge Orchestration')
add('authors', text='Alaa Hamid Mohammed')
add('affil', text='Al-Iraqia University, Baghdad, Iraq  ·  alaa.hamid@uoa.edu.iq')

add('abstract', text=(
 'Immersive Metaverse services over sixth-generation (6G) edge infrastructure close a loop in which a '
 'physical state is sensed at the user, reconstructed at an edge node and consumed by a machine '
 'decision. Conventional orchestration optimizes network-centric objectives - '
 'latency, energy, throughput or the Age of Information - which are decision-agnostic: an update that '
 'would flip a safety-critical classification is valued exactly as one that refines an already '
 'unambiguous estimate. Two findings are reported. First, the objective matters '
 'more than the mechanism: four unrelated policies - a reactive incorrectness trigger, an '
 'absolute-risk trigger, a learned policy and a closed-form counterfactual gate - converge in behaviour '
 'once aimed at decision correctness and separate from the seven that do not, though not without '
 'exception; the cleanest evidence is a '
 'pair of reinforcement-learning policies identical in architecture, features, budget and seed, '
 'differing only in reward. Second, freshness is not correctness: the proposed policy runs at a far '
 'larger Age of Information than every freshness-optimized baseline and is nevertheless more accurate at '
 'causally critical instants. The instrument that operationalizes the first finding is the Causal '
 'Effect of Transmission, a model-based counterfactual contrast quantifying the reduction in '
 'decision-error probability caused by sending a given update; under a linear-Gaussian state model it has '
 'a closed form costing a few matrix-vector products per user per slot. Evaluation '
 'uses a slotted 6G simulator under strict '
 'common random numbers, over five scenarios and ten baselines. '
 'Causal-semantic gating dominates the gain: removing it costs three to five accuracy points and '
 'multiplies uplink traffic about eightfold.'))

add('keywords', text=('Network and service management, edge orchestration, goal-oriented '
 'communication, digital twin synchronization, counterfactual reasoning, 6G.'))

md(r"""
# I.  INTRODUCTION

The Metaverse is converging with sixth-generation (6G) wireless networks into cyber-physical systems in which a continuously updated digital replica drives autonomous decisions in real time. Immersive collaboration, remotely embodied robots and vehicles, industrial digital twins and multi-user extended reality (XR) share one loop: a physical state is sensed at the user, transported over a wireless link, reconstructed at an edge or cloud node, and consumed by an artificial-intelligence component that renders, predicts or acts. The correctness of that loop is determined not by how many bits arrive, nor purely by how quickly, but by whether the reconstructed state is *good enough, at the right moment, for the decision that depends on it*.

Conventional edge-cloud orchestration does not express that requirement. The dominant objective is a weighted combination of network-centric quality-of-service terms - latency, energy, throughput, computational load - occasionally augmented with a freshness term such as the Age of Information (AoI). Such objectives are measurable and additive, but *decision-agnostic*: they value an update that would flip a safety-critical classification exactly as one that refines an already unambiguous estimate. In a dense 6G Metaverse cell the second kind dominates by an order of magnitude, so a system that treats the two alike spends most of its radio and compute budget on information with no causal influence on any decision and, precisely because that budget is exhausted, delivers the decisive updates late.

Table @NOTA lists the notation. Two findings are reported here, and they are the paper's claim.

**The objective matters more than the mechanism.** Four policy families that model the downstream decision - a reactive incorrectness trigger, an absolute-risk trigger, a learned policy trained on a decision-centric reward, and the closed-form counterfactual gate developed below - converge in behaviour and rise above the seven families that do not model it: @@CLUSTER@@. The exception is instructive rather than fatal, and it is not hidden: a learned policy inherits the variance of its own training, and the same reward produced a degenerate run in that scenario (Section VII-J). The cleanest evidence is therefore the pair of deep reinforcement learning policies that share an architecture, a feature set, a training budget and a random seed and differ only in their reward: pointing the same machinery at decision correctness rather than at network-centric quality of service is worth more than any difference between the mechanisms that do point at it. That designs this unlike should cluster at all, and separate from everything that is not aimed at the decision, is stronger evidence for the thesis than a win by a single hand-designed policy would be.

**Freshness is not correctness.** The proposed policy operates at an Age of Information one to two orders of magnitude larger than every policy that optimizes freshness directly, and is nevertheless more accurate at causally critical instants. Under a freshness-centric design philosophy that is close to a contradiction; under the calculus of Section IV it is expected, because elapsed time and decision risk decouple whenever the state dynamics are slow relative to the decision margin - the common regime in immersive applications.

What makes the first finding operational is a *decision-relevance signal* defined counterfactually rather than by distortion or elapsed time, computable online at the transmitter, and cheap enough to sit inside a per-slot scheduler.

**Causal Effect of Transmission (CET).** For each candidate update the interventional contrast between transmitting and not transmitting is evaluated, in expected decision-error probability over a look-ahead horizon. Under a linear-Gaussian state model with a margin rule this contrast has a closed form; for a non-linear head it is evaluated on the local boundary normal obtained by differentiating the head. CET is *predictive* - large before a decision has degraded - and *margin-aware*: for the same innovation, a user far from any boundary scores near zero. Section IV-A gives the structural causal model, the intervention and the identification assumptions, and states explicitly that CET is a model-based counterfactual quantity, not an estimand recovered from observational data. What it is not is also measured and reported: as an instantaneous detector of updates that matter it is beaten by the present-risk signal of the goal-oriented baseline, and its advantage is that it is an additive transmission *value* on a common scale, which is what a scheduler can compare across users under a binding budget. Section VII-C tests that claim where the budget binds.

The **Age of Cognition (AoC)** is an importance-weighted staleness measure that serves as the scheduler's backlog; Proposition 2 states the conditions under which it recovers AoI, the Age of Incorrect Information (AoII) and the Urgency of Information (UoI), and Theorem 1 bounds the no-transmission decision-error process by it, up to the irreducible post-update reconstruction error. Both results are scoped narrowly, and Section VII-J2 reports how loose the bound is for each policy.

**CoFA**, the orchestrator built on these signals, is presented as the three mechanisms the measurements support - causal-semantic gating, margin-matched fidelity selection and predictive pre-migration - together with a placement rule, a drift-plus-penalty ranking and a reflective meta-controller that are retained for completeness and shown inert at the nominal operating point (Table VII). Table II specifies what each module observes, remembers, decides and adapts.

The evaluation is deliberately adversarial to the claim. It runs under strict common random numbers, so every policy meets a bit-identical realization; it spans five scenarios, among them a non-linear non-Gaussian head-pose scenario with a neural decision head - where the orchestrator holds only a fitted linear surrogate of the dynamics - and two admission-limited regimes, the harsher built so the scheduling constraint binds; and it compares against ten baselines, including AoII- and UoI-based scheduling, a goal-oriented risk-triggered scheduler sharing CoFA's decision model but not its counterfactual contrast, and the learned pair described above.

The contributions are as follows.

> 1) *Evidence that the objective, not the mechanism, is what matters.* Under common random numbers, ten baselines, up to twenty seeds per scenario and paired significance testing with family-wise and false-discovery control, the decision-modelling families @@CLUSTER_SHORT@@, the learned pair isolates the objective from the machinery, and the ablation attributes almost the entire gain of the proposed policy to causal-semantic gating (Sections VII-A, VII-G).

> 2) *Causal-semantic update gating.* CET is defined as an interventional contrast on the transmit variable; its structural causal model, identification assumptions and closed form are given - including the propagation of reconstruction noise through the dynamics - at a cost of O(|H| d²) per user per slot, about 0.16 ms for one hundred users on one core, and it extends to non-linear decision heads through the local boundary normal (Section IV-A).

> 3) *A direct validation of the instrument, including where it loses.* CET is compared against the counterfactual benefit realized on the trajectory that actually occurred, over more than a hundred thousand probes drawn under a decision-agnostic carrier, in calibration, in rank correlation by horizon, and in its ability to identify the updates that matter. It is shown to be an ordinal signal rather than a calibrated probability, to lose informativeness with look-ahead, and to be outperformed as an instantaneous detector by a present-risk signal; the value semantics that survive that result are then tested under a binding admission limit (Sections VII-C, VII-K).

> 4) *An importance-weighted age with stated scope.* The exact conditions under which AoC recovers AoI, AoII and UoI are proved, a decision-error bound is given whose slack is the irreducible post-update error probability, and the tightness of that bound is measured for every policy rather than asserted (Sections IV-C, IV-D, VII-J2).

Section II reviews related work, Section III the system model, Section IV the decision-relevance calculus, Section V the orchestrator, Sections VI-VII the methodology and results, Section VIII the discussion, Section IX limitations, and Section X concludes.

# II.  RELATED WORK AND POSITIONING

## A.  Semantic and Goal-Oriented Communication

The programme of moving beyond bit reproduction towards the transmission of meaning was set out by Strinati and Barbarossa [1] and by Kountouris and Pappas [3], who argued that networked intelligent systems should be designed around the *significance* of information for the receiver's task. Practical realizations followed two threads: learned joint source-channel coding, exemplified by Deep JSCC [5] and DeepSC [4]; and task-oriented feature compression, with the information bottleneck as design principle [59], complemented by device-edge model partitioning [57], [58]. Surveys are given in [2], [6]-[9].

These works address the *encoder* question - what to compress - under a fixed task, not the *orchestration* question: given many users, a shared time-varying radio and compute budget, mobility and handovers, which state updates should be transmitted at all, at what fidelity, to which node, and in what order. Metrics surveys [8] note the absence of an operational measure of semantic value evaluable online at the transmitter; CET is proposed for that role, and the Goal-Oriented baseline of Section VI-C represents this family, using the same decision model as CoFA but triggering on present risk rather than on the causal effect of transmitting.

## B.  Freshness Metrics: AoI, AoII, Version Age and Urgency

AoI was introduced by Kaul et al. [10] and matured into a theory of status-update timeliness [12]-[14]. Recognizing that elapsed time over-weights uninformative updates, refinements followed: AoII [11] penalizes staleness only while the receiver's estimate is *wrong*; UoI [15] introduces a context-dependent weight; version age [16] counts missed updates rather than time.

AoC belongs to this family, and Proposition 2 gives the exact conditions under which it reduces to AoI, AoII and UoI. What is new is neither a constant weight, nor a reactive indicator of present incorrectness, nor an exogenous context signal, but an *estimated interventional effect on future decisions*. AoII- and UoI-based schedulers are evaluated directly rather than only cited; the AoII scheduler is a strong and very economical baseline, and the comparison against it isolates the value of acting *before* the decision degrades.

## C.  Edge Orchestration and Digital-Twin Synchronization

Mobile edge computing offloading is surveyed in [29], with deep reinforcement learning a standard tool [30], [49], [50], often combined with Lyapunov optimization for queue stability [54], [55]; mobility-induced service migration is a mature subfield [31], [32], and the anticipatory forms of it are the closest existing analogue to the migration agent used here - service-function-chain migration triggered by predicted user movement [33] and pro-active service embedding ahead of a demand shift [34]. What differs is not the machinery but what triggers it: those schemes anticipate *where* the load will be, whereas the trigger here is what an update is worth to a decision. The near-universal objective is a weighted sum of latency, energy and occasionally the accuracy of a fixed inference task - priority classes [51], slice-level latency targets [52] and learned offloading value functions [53] are all instantiations of it; rather than treating that as a single baseline, two learned policies identical except for the reward are trained here, so the comparison isolates the objective from the learning machinery. On the application side, requirements for wireless immersive media were mapped in [17], [19] with the tactile-Internet vision [18] setting the latency envelope, Metaverse surveys [20], [21] identify edge AI as the enabling layer, immersive delivery over millimetre wave has been given a context-aware transport layer [27] and augmented-reality workloads a quality-of-service-aware offloading rule [28], and digital-twin synchronization over wireless has been studied from resource-allocation [25], continual-learning [24] and architectural [22], [23], [26] viewpoints. These works generally treat synchronization fidelity as a distortion or model-drift quantity; it is instead measured here in the decision-relevant projection, and the ablation quantifies how much that choice is worth.

## D.  Causal Reasoning and Autonomous Agents for Networks

Causal reasoning has been advanced as a core capability for AI-native wireless systems [45] and applied to emergent semantic communication [44], on the structural-causal-model foundations of Pearl [42] and the causal-discovery literature [43]; causal model-based RL has improved sample efficiency in channel access [56]. In parallel, autonomous and large-language-model-driven agents have been proposed for network control [36]-[41].

The position taken here is deliberately modest on both counts. CET is a *model-based counterfactual contrast* computed from a known or fitted transition model, with no claim to discover causal structure from data and with the identification assumptions stated in Section IV-A; and CoFA is an autonomous multi-agent controller in the specific sense of Table II - specialized modules with their own observations, memory and adaptation under a shared objective - not a learning agent in the reinforcement-learning or language-model sense.

## E.  Positioning

Table I summarizes the positioning. No prior framework is known to combine (i) an interventional, closed-form, online decision-relevance signal that extends to non-linear decision heads, (ii) an importance-weighted backlog with a stated relationship to classical freshness metrics and to decision error, and (iii) an orchestrator that uses both to jointly control gating, fidelity level, scheduling, placement and predictive state migration under mobility.
""")

add('table', span=2, label='Table @NOTA',
    caption='Notation. Symbols are unique across the paper; the per-cell '
            'admission limit is K_max, distinct from the horizon K of (4), and '
            'the three weights of the fidelity score are w_d, w_r and w_f, '
            'distinct from the beamforming isolation factor, the payload '
            'scaling and the SINR symbols.',
    cols=['Symbol', 'Meaning', 'Symbol', 'Meaning'],
    widths=[0.95, 2.35, 0.95, 2.35],
    rows=[
      ['x_u(k)', 'latent application state of user u', 'x̂_u(k)', 'replica at the consuming node'],
      ['e_u(k)', 'innovation x_u − x̂_u', 'g(·)', 'application decision head'],
      ['w_loc(x)', 'local boundary normal of g at x', 'm_u', 'decision margin (first-order)'],
      ['A, Â', 'true and fitted state kernel', 'Q̂', 'fitted residual covariance'],
      ['H', 'look-ahead horizon set', 'τ', 'transport delay in slots'],
      ['T_k, L_k', 'transmit decision and fidelity level', 'ℓ, b_ℓ, s_ℓ', 'level, payload bits, reconstruction noise'],
      ['CET_u(k)', 'causal effect of transmission, (7)', 'Δᶜ_u(k)', 'Age of Cognition, (11)'],
      ['CFS_u(k)', 'cognitive fidelity score, (10)', 'w_d, w_r, w_f', 'its three weights, summing to one'],
      ['θ_gate, η', 'gate threshold and fidelity floor', 'V', 'drift-plus-penalty weight'],
      ['φ', 'meta-controller target', 'ψ₀', 'AoC dead-zone'],
      ['K', 'time horizon in slots, (4)', 'K_max', 'per-cell admission limit'],
      ['N, M', 'users and base stations', 'n_m(k)', 'users admitted by cell m'],
      ['W, W_u', 'cell and per-user bandwidth', 'β', 'beamforming isolation factor'],
      ['γ_u, γ_th', 'SINR and its erasure reference', 'ε₀', 'residual erasure floor'],
      ['p^no, p^wit', 'error probability without / with an update', 'p^del_u', 'estimated delivery probability'],
      ['Ψ_u(k)', 'scheduling index, (15)', 'ϱ', 'greedy approximation factor'],
    ])

add('table', span=2, label='Table I',
    caption='Positioning with respect to representative prior work.',
    cols=['Approach / family', 'Relevance signal', 'Predictive?', 'Non-linear head',
          'Joint gating + level', 'Placement + mobility', 'Online cost'],
    widths=[2.3, 1.5, 0.85, 0.95, 1.0, 1.05, 0.95],
    rows=[
      ['Deep JSCC / DeepSC / task-oriented coding [4], [5], [59]', 'training-time task loss', 'no', 'yes', 'level only', 'no', 'low'],
      ['AoI scheduling [10], [12]-[14]', 'elapsed time', 'no', 'n/a', 'no', 'no', 'low'],
      ['AoII scheduling [11]', 'present incorrectness', 'no', 'yes', 'no', 'no', 'low'],
      ['UoI scheduling [15]', 'exogenous context weight', 'no', 'partial', 'no', 'no', 'low'],
      ['Goal-oriented / VoI triggering [3], [7], [8]', 'present decision risk', 'no', 'yes', 'partial', 'no', 'low'],
      ['DRL-based MEC offloading [30], [49], [55]', 'learned value function', 'implicit', 'yes', 'partial', 'yes', 'high (training)'],
      ['Digital-twin synchronization [22]-[26]', 'model drift', 'no', 'partial', 'no', 'partial', 'medium'],
      ['Causal reasoning for wireless [44], [45]', 'causal structure', 'conceptual', 'n/a', 'no', 'no', 'medium'],
      ['**CoFA (this work)**', '**counterfactual contrast (CET)**', '**yes**', '**yes (boundary normal)**', '**yes**', '**yes (predictive)**', '**moderate**'],
    ])

md(r"""
# III.  SYSTEM MODEL

## A.  Network, Mobility and Radio

A 6G access network is considered, with a set M = {1, ..., M} of base stations, each co-located with an edge server, and a remote cloud. A set U = {1, ..., N} of users moves in a square service area by a random-waypoint process with per-user speed in [v_min, v_max]. Time is slotted with slot duration δ.

Large-scale propagation follows the 3GPP TR 38.901 optional street-canyon (UMi NLOS) model at carrier frequency f_c,

$ PL_(u,m)(k) = 32.4 + 20 log₁₀ f_c[GHz] + 31.9 log₁₀ d_(u,m)(k) + ξ_(u,m)(k), || 1

with ξ a correlated log-normal shadowing term. With combined array gain G the received power is P_(u,m)^rx = P_tx G / PL_(u,m). Users associate with the strongest cell and are handed over by an A3 rule [46]-[48] with hysteresis Δ_hys and time-to-trigger T_TTT; a handover costs an interruption T_HO. Uplink access is OFDMA: at most K_max users are admitted per cell and share the cell bandwidth W equally, so an admitted user obtains W_u = W/n_m(k) and

$ R_u(k) = W_u log₂( 1 + P_(u,σ(u))^rx / ( β Σ_(m≠σ(u)) P_(u,m)^rx + N₀ W_u ) ). || 2

Here σ(u) is the serving cell, β a beamforming-isolation factor and N₀ the noise power spectral density including the receiver noise figure. The interference term is built from the user's own propagation to the non-serving cells scaled by β: a deliberately simple proxy for the residual inter-cell interference that survives receive beamforming, which keeps the interference geometry a function of position rather than of the neighbouring cells' instantaneous scheduling. After hybrid ARQ a residual erasure probability ε_u(k) = ε₀ + ½(1 + exp(γ_u − γ_th))^(−1) remains.

## B.  Application State and Decision Head

Each user carries a latent application state x_u(k) ∈ R^d and the application maps it to a discrete decision through a decision head g. Two instantiations are studied.

*Linear-Gaussian context with a margin rule (scenarios S1, S2).* The state follows a stable Gauss-Markov process punctuated by semantic events,

$ x_u(k+1) = A x_u(k) + w_u(k) + 1{e_u(k)} μ ν_u(k),  w_u ~ N(0, σ_w² I), || 3

with A normalized to spectral radius ρ < 1, e_u a Bernoulli event indicator of rate p_e, ν_u an isotropic unit vector and μ the event magnitude. The head is a three-class margin rule on a causal direction w ∈ S^(d−1): g(x) = 2 if wᵀx > θ, 0 if wᵀx < −θ, and 1 otherwise, representing *no action / warn / intervene*.

*Non-linear, non-Gaussian head-pose context with a neural head (scenario S3).* The state is six-dimensional - yaw, pitch, their angular rates, an attention bearing and a closing rate. Angular rates follow a heavy-tailed (Student-t) Ornstein-Uhlenbeck process punctuated by saccadic impulses and saturated at a physiological limit by a tanh non-linearity, and the attention bearing switches as a discrete jump process; parameter magnitudes lie in physiologically plausible ranges for seated XR rather than being fitted to a recorded dataset. The head is a three-class multilayer perceptron. Crucially the orchestrator is *not* given the true dynamics: it uses a least-squares linear surrogate Â with residual covariance Q̂, identified from the warm-up window only. Scenario S3 therefore tests the estimator under simultaneous non-linearity, non-Gaussianity, model mis-specification and a curved decision boundary.

For a general head, at state x, the *local boundary normal* w_loc(x) is defined as the unit gradient of the margin between the top two classes and the *decision margin* m_u as that margin divided by the gradient norm, i.e. the first-order distance to the nearest decision boundary. For the linear head these reduce to w and ||wᵀx| − θ|.

A compute node maintains a reconstruction x̂_u(k), propagated between updates by dead reckoning x̂_u(k+1) = Â x̂_u(k) and overwritten when an update is applied. The decision actually taken is g(x̂_u); the *decision error* is 1{g(x̂_u) ≠ g(x_u)}. This quantity is policy-agnostic - no policy optimizes it directly - and it is the primary evaluation metric.

## C.  Semantic Encoding, Computation and Migration

A transmitted update carries a semantic fidelity level ℓ ∈ {1, ..., L} with payload b_ℓ = α_ℓ B₀ bits and reconstruction-noise standard deviation s_ℓ. On arrival, x̂_u ← Â^τ x_u(k_gen) + ζ with ζ ~ N(0, s_ℓ² I), where τ is the transport delay in slots, i.e. the sample is dead-reckoned forward to compensate for it. At most one update per user is in flight.

Ingesting an update costs C cycles. Edge server m runs at f_m cycles/s and serves a FIFO queue; the cloud runs at f_c ≫ f̄ across a jittered backhaul of one-way delay τ_b. Cloud latency is reported closed-loop - the update traverses the backhaul inbound and the decision outbound - so cloud placement carries 2τ_b ≈ 24 ms of transport alone and cannot meet the 20 ms deadline of Section VI-D at any load, while edge placement carries no such term. An update routed to a non-serving edge pays an inter-edge forwarding delay τ_m, and a further cold-migration delay τ_m if the user's state is not resident there; a policy may pre-replicate state to a predicted target edge in the background at the cost of 2B₀ bits.

## D.  Problem Statement

A policy π selects, in each slot, a transmitting subset, a fidelity level and a destination for each selected user, and may issue pre-migration requests. The objective is time-average decision correctness at the consuming node,

$ max_π  lim_(K→∞) (1/KN) Σ_k Σ_u P( g(x̂_u(k)) = g(x_u(k)) )   s.t.  B̄ ≤ B_max, Ē ≤ E_max, n_m(k) ≤ K_max ∀m. || 4

The objective is deliberately the decision itself and not a composite fidelity score. An earlier formulation maximized the Cognitive Fidelity Score of Section IV-B; Section VII-L shows the composite is essentially uncorrelated with decision correctness across a heterogeneous policy population, and that no convex reweighting of its three components repairs this except the degenerate one keeping the decision term alone. The composite is therefore demoted to a control and diagnostic signal, regulated by the meta agent within a single policy and never a ranking criterion between policies; under that demotion (4) is exactly the decision-consistency term of CFS taken alone, so the orchestrator of Section V is unchanged and only the quantity it is said to maximize is corrected. Proposition 3 shows the single-slot subproblem to be NP-hard, motivating the decomposition of Section V, and the right-hand side of (4) is not observable at the transmitter - it is what CET estimates - so the orchestrator optimizes the estimate while the evaluation reports the realized value on the policy-agnostic metrics of Section VI-D.
""")

md(r"""
# IV.  THE DECISION-RELEVANCE CALCULUS

## A.  Causal Effect of Transmission

### 1) Structural causal model

The causal claim is made explicit before do-notation is used. For user u, the variables at slot k are the latent application state X_k, the network state C_k (channel gains, queue backlogs, association), the transmit decision T_k ∈ {0,1} with fidelity level L_k, the delivery indicator Y_k and delay τ_k, the receiver replica Ĥ_k, the true and reconstructed decisions D_k = g(X_k) and D̂_k = g(Ĥ_k), and the error E_k = 1{D_k ≠ D̂_k}. The structural equations are

$ X_(k+1) = f(X_k, W_k),   Ĥ_(k+1) = Â Ĥ_k  if no update is applied,  Ĥ_(k+1) = Â^τ X_(k−τ) + ζ  otherwise, || 5

$ (Y_k, τ_k) = h(C_k, T_k, L_k, U_k),   T_k = π(X_k, Ĥ_k, C_k),   E_k = 1{g(X_k) ≠ g(Ĥ_k)}, || 6

with W_k, U_k, ζ mutually independent exogenous noises. The associated graph has X_k → X_(k+1) → D_(k+h); T_k → Ĥ_(k+h) → D̂_(k+h) for h ≥ τ; C_k → (Y_k, τ_k) → Ĥ_(k+h); and (X_k, Ĥ_k, C_k) → T_k. There is no edge from T_k into the X-branch.

### 2) Estimand and identification

Define, for a look-ahead set H,

$ CET_u(k) = (1/|H|) Σ_(h∈H) [ P( E_(k+h) | do(T_k = 0) ) − P( E_(k+h) | do(T_k = 1, L_k = ℓ) ) ]⁺, || 7

so that a positive value means transmitting reduces the decision-error probability; the positive part discards horizons at which the reconstruction noise of level ℓ would itself dominate. The contrast is identified from (X_k, Ĥ_k) alone under four assumptions.

> *On the depth of H.* The mechanism this paper is about is the *contrast*, not the depth over which it is averaged, and the two should not be conflated. All reported experiments use H = {0, 5, 10, 20} slots, but Section VII-K sweeps the set and finds critical-instant accuracy flat within a fraction of a point while uplink volume rises monotonically with depth, so the recommended default for a deployment is the shallowest set, H = {0} or {0, 5}. The reported configuration is thus the *conservative* one: the traffic reductions in Section VII-A are those of the most expensive setting of the estimator, and a shallower one improves them. Deep horizons are retained in the reported configuration only so that the sweep in Section VII-K is a study of the setting actually used rather than of a setting chosen after the fact.

> (A1) *No feedback onto the sensed process.* The transmit action does not influence the physical state: X_(k+h) ⫫ T_k for all h ≥ 0. This holds because the sensor is passive and would fail for a closed-loop actuator whose command depends on the transmitted update. Scenario S2 is named for the half of the loop it actually contains: a remotely embodied device reports its state and a remote component decides, at vehicular speed and with a short decision deadline. The downlink actuation path is not modelled; in a genuinely closed loop it would violate (A1), and extending CET there requires either a dynamic-treatment-regime formulation with time-varying confounding or the assumption that actuation is slow relative to the look-ahead horizon. Neither is claimed here.

> (A2) *Known or estimated transition and reconstruction models.* The kernel of X and the reconstruction model are available to the estimator. In S1 and S2 the true kernel is used; in S3 only the fitted linear surrogate (Â, Q̂) is available, and the resulting mis-specification is measured rather than assumed away.

> (A3) *No unobserved confounding of the intervention.* CET is evaluated at the device from (X_k, Ĥ_k) *before* the policy acts, so the quantity conditioned on is a deterministic function of variables that d-separate T_k from the potential outcomes. No back-door adjustment is required.

> (A4) *Delivery-conditional potential outcome.* Whether an update is delivered depends on the shared radio resource and hence on other users' actions, which violates SUTVA at the network level. The intervention is therefore "the update is generated and delivered at the modelled delay", so CET is a per-user potential outcome *conditional on successful delivery*; the scheduler multiplies it by the estimated delivery probability p_del in (15), where the network-level coupling is handled.

Under (A1)-(A4) both potential outcomes are computable in closed form from the model, so CET is a model-based counterfactual contrast rather than an estimand recovered from observational data. Do-notation is used only for the intervention on T_k, and no claim of causal discovery is made.

### 3) Closed form

**Proposition 1 (closed form).** With e_u(k) = x_u(k) − x̂_u(k), with w = w_loc(x_u(k)) the local boundary normal, m_u the decision margin, and Σ(h) = Σ_(i<h) Â^i Q̂ (Â^i)ᵀ the propagated process covariance, and writing μ_h = wᵀÂ^h e_u(k), S_h = wᵀ Σ(h) w and G_h = ‖(Â^h)ᵀ w‖², it holds that

$ P(E_(k+h) | do(T=0)) ≈ Φ((−m_u − μ_h)/√S_h) + 1 − Φ((m_u − μ_h)/√S_h), || 8

$ P(E_(k+h) | do(T=1, ℓ)) ≈ 2 ( 1 − Φ( m_u / √(S_h + s_ℓ² G_h) ) ). || 9

*Proof sketch.* Without transmission the projected error at horizon h is the deterministically propagated current error wᵀÂ^h e_u plus the process noise accumulated over h slots, which is zero-mean with variance S_h; a decision flip is the event that the sum leaves [−m_u, m_u]. With transmission the propagated current error is replaced by the reconstruction noise ζ ~ N(0, s_ℓ² I), which after h steps of dead reckoning projects onto w with variance s_ℓ² ‖(Â^h)ᵀ w‖² = s_ℓ² G_h; the accumulated process noise is unchanged. The first-order margin and the local normal make the same argument valid for a non-linear head in a neighbourhood of x_u. ∎

The G_h factor is the propagation of the reconstruction noise through the dynamics; omitting it, as a naive derivation does, understates the post-update error whenever ‖Â^h‖ > 1 along w. Two implementation details follow. The contrast (9) is evaluated at a fixed *reference* fidelity level rather than at the level the synchronization agent later chooses, so the importance signal does not depend on the level decision, and it treats the update as landing without transport delay - for a delay of tau slots an additional Sigma(tau) term appears, omitted because the horizons of interest are longer than the delay. The estimator needs only the innovation e_u, which the *device* has, since it observes x_u and mirrors the receiver's dead-reckoning recursion through acknowledgements; its cost is O(|H| d²) per user per slot with all matrix powers precomputed.

Two properties matter operationally: CET is *predictive*, being large before the decision has flipped because it integrates over future horizons, and *margin-aware*, since for the same innovation a user far from a boundary scores near zero. Together these produce the suppression behaviour that drives the reported traffic savings. Equation (8) alone, evaluated at a single short horizon, is the *present* decision-risk signal used by the Goal-Oriented baseline; that baseline therefore shares CoFA's decision model and differs only in using an absolute risk rather than the interventional contrast, so the CoFA-versus-Goal-Oriented comparison isolates the value of the contrast rather than of look-ahead as such.

## B.  Cognitive Fidelity Score

**Definition 1.** For user u at slot k,

$ CFS_u(k) = w_d 1{g(x̂_u) = g(x_u)} + w_r exp( − (w_locᵀ(x_u − x̂_u))² / (2(κ m_u + ε)²) ) + w_f exp( − Δᶜ_u(k)/τ_a ), || 10

with w_d + w_r + w_f = 1. The three terms are decision consistency, margin-normalized representational fidelity in the decision-relevant projection, and cognitive freshness. Error components orthogonal to the local boundary normal are invisible to the application and are not charged; the same projected error is harmless far from a boundary and severe close to one; and freshness is measured in cognitive rather than wall-clock time. CFS is the quantity the meta-controller regulates. Because it is a proxy, Section VII-L reports how well CFS and each of its components predict the policy-agnostic decision metric across all runs.

## C.  Age of Cognition

**Definition 2.** With I_u(k) ≥ 0 a relevance signal for information generated at u and not yet delivered, and k_u^app(k) the last slot at which an update was applied, the Age of Cognition is

$ Δᶜ_u(k) = Σ_(j=k_u^app(k))^(k) ψ( I_u(j) ), || 11

for a non-decreasing rate function ψ with ψ(0) = 0. The instantiation used in this paper is I = CET and ψ(I) = max(I − ψ₀, 0); the dead-zone ψ₀ ≥ 0 reflects that sub-threshold effects are indistinguishable from estimator error, and it is applied identically to every policy evaluated.

**Proposition 2 (exact scope of the reduction).** Assume ψ₀ = 0, a common slot grid of step δ, and that the metric being compared resets at the same delivery epochs as (11). Then:

> (i) with the constant relevance signal I_u(j) ≡ 1 and ψ(I) = δ I, Δᶜ_u(k) equals the Age of Information up to one slot, δ(k − k_u^app + 1);

> (ii) with I_u(j) = 1{g(x̂_u(j)) ≠ g(x_u(j))} and ψ(I) = δ I, Δᶜ_u(k) equals the accumulated incorrect time since the last delivery, which coincides with the Age of Incorrect Information of [11] for the decision-valued distortion f(x, x̂) = 1{g(x) ≠ g(x̂)} and a linear time penalty *provided the incorrectness interval is contiguous with the reset epoch*; without that contiguity the two differ by the earlier, already-repaired incorrect intervals in the same window;

> (iii) with I_u(j) = ω(j) an exogenous context weight and ψ(I) = δ I, Δᶜ_u(k) equals the Urgency of Information of [15] for that weight.

*Proof.* By substitution in (11): in each case the summand is δ, δ times the indicator, or δ times the context weight, and the reset epochs coincide by hypothesis. ∎

Proposition 2 concerns one particular accumulating form: it does not cover AoII variants with non-linear time penalties or with distortion functions not measurable with respect to the transmitter's information, nor version age [16], which counts missed updates rather than elapsed time. "Subsumes" is to be read in that restricted sense.

## D.  From Age of Cognition to Decision Error

The relevance signal that CoFA accumulates is CET, a *contrast*, which is by construction no larger than the no-transmission error probability. The bound must be stated accordingly.

**Theorem 1 (bound on the no-transmission error process).** Fix a user and an age window since the last applied update. With p_j^no = P(E_j | do(T = 0)) and p_j^wit = P(E_j | do(T = 1)) the h = 0 terms of (8)-(9), so that CET_j = p_j^no − p_j^wit whenever the contrast is non-negative, and with Δᶜ instantiated by CET and ψ₀ = 0,

$ (1/K) Σ_k p^no_k  ≤  (1/K) Σ_k E[ Δᶜ_u(k) ]  +  p̄^wit, || 12

where p̄^wit is the mean post-update error probability. The left-hand side is the *no-transmission* error process, not the error the policy realizes. The two coincide only when no update is ever applied, and (12) extends to the realized error P(E_k) only under the additional hypothesis that transmitting never increases the error, P(E_k) ≤ p^no_k for every k. That hypothesis is *not* satisfied here: Section VII-K measures the raw contrast before its positive part and finds it negative for about a fifth of probes, with a negative unconditional mean, so an update at a fixed intermediate fidelity can flip a correct decision. The bound is therefore stated on p^no and used as such. Moreover, for any instantiation,

$ P( E_k ) ≤ 2 exp( − m_u² / (2 s²(Δᶜ_u)) ) || 13

whenever the projected estimation error is sub-Gaussian with a proxy variance that is non-decreasing in the elapsed age since the last applied update. Equation (13) is stated in terms of age rather than AoC because, with a non-zero dead-zone, AoC can remain at zero while the age grows.

*Proof sketch.* Δᶜ_u(k) contains the term CET_k, so Δᶜ_u(k) ≥ CET_k = p_k^no − p_k^wit, i.e. p_k^no ≤ Δᶜ_u(k) + p_k^wit; averaging over k gives (12), whose left-hand side is p^no for exactly this reason. Inequality (13) follows from the margin definition: a flip requires the projected error to exceed m_u, and a sub-Gaussian tail bound gives the stated form, with the proxy variance a non-decreasing function of the elapsed age because Σ(τ) is non-decreasing in τ in the positive-semidefinite order. ∎

*Remark 2 (what the implementation accumulates).* Theorem 1 is stated for the single-horizon instantiation with ψ₀ = 0, while the implementation accumulates the positive part of the horizon-averaged contrast with a dead-zone ψ₀ = 0.005; both only shrink the accumulated quantity, so (12) holds for the implemented AoC with an additional slack bounded by |H|⁻¹ times the discarded mass plus ψ₀ per slot.

Theorem 1 therefore makes AoC a valid backlog variable up to a slack equal to the *irreducible* post-update error, controlled by the reconstruction noise of the reference fidelity level and by the margin. How much that is worth is a measurement, not a claim: Section VII-J2 evaluates both sides of (12) for every policy and reports the ratio between them, and the answer is that the bound is informative for gated policies whose AoC stays bounded and close to vacuous for policies that let the backlog grow. No analogous bound holds for AoI, because AoI can be large while the projected error stays well inside the margin - the common case in these measurements.

## E.  Efficiency Measure

Because fidelity can always be bought with bandwidth, the Decision Efficiency is reported, DE = (critical-instant decision accuracy) / (mean uplink rate in Mb/s), which measures the decision correctness obtained per unit of spectrum.
""")

md(r"""
# V.  COFA: AUTONOMOUS MULTI-AGENT ORCHESTRATION

## A.  Architecture

CoFA decomposes orchestration into five modules that share one objective - time-average cognitive fidelity under resource constraints - but observe and act on disjoint parts of the system state. *Autonomous multi-agent orchestration* is used in the specific, checkable sense set out in Table II: each module has its own observation, memory, reasoning rule, action set and adaptation mechanism. It is not a learning agent in the reinforcement-learning sense and not a language-model agent; Fig. 1 shows the architecture.

*Perception agent (per user, on device).* Mirrors the receiver's dead-reckoning recursion to obtain the innovation e_u, evaluates CET in closed form, maintains the Age of Cognition and reports (Δᶜ_u, CET_u, m_u).

*Synchronization agent.* Decides whether to generate an update and at what fidelity. The gate admits u if

$ CET_u > θ_gate  ∨  g(x̂_u) ≠ g(x_u)  ∨  |w_locᵀ e_u| > η (m_u + m̄), || 14

that is, if transmitting has non-negligible causal effect, if the decision is already inconsistent, or if the decision-projected error has drifted past a fidelity floor that is relative to the local margin but bounded away from zero by the running median margin m̄. The fidelity level is the smallest ℓ with s_ℓ ≤ m_u/ς, floored at ℓ_min and forced to L when the decision is already inconsistent.

*Scheduling agent (per cell).* Ranks admitted users by the drift-plus-penalty score

$ Ψ_u(k) = ( Δᶜ_u(k) + V CET_u(k) ) p_u^del(k) / [ (b_(ℓ(u))/B₀) max( L̂_u(k)/δ₀, ½ ) ], || 15

where p_u^del is the estimated delivery probability, L̂_u the estimated completion latency and V the fidelity-resource weight; the top K_max users per cell are admitted.

*Placement and mobility agent.* Chooses the compute node minimizing expected AoC accrual over the serving edge and the cloud, and, when a handover is predicted from the reference-signal margin, issues a background pre-migration that replicates the state to the target edge so the cold-start penalty is not paid on the critical path.

*Meta (reflection) agent.* Compares an exponentially weighted CFS estimate against a target φ and observes cell occupancy, adapting (V, θ_gate, η). The target φ is the single knob selecting the operating point, and results are reported throughout for CoFA (φ = 0.975, fidelity-oriented) and CoFA-E (φ = 0.93, efficiency-oriented). At φ = 0.975 the controller sits at a fixed point - realized fidelity is above target and occupancy is low, so neither adaptation branch fires - which is why the meta agent has no measurable effect in the ablation of Section VII-G; its role is to *move* the operating point, and it is active for CoFA-E.
""")

add('table', span=2, label='Table II',
    caption='Specification of each module - observation, memory, reasoning rule, action set and '
            'adaptation - and the operational definition of the "autonomous multi-agent" '
            'characterization used here.',
    cols=['Agent', 'Observation', 'Memory', 'Reasoning rule', 'Action set', 'Adaptation'],
    widths=[1.05, 1.5, 1.15, 1.5, 1.15, 1.35],
    rows=[
      ['Perception (per user, on device)', 'own state x_u, ACKs, decision head or its linearization',
       'mirrored replica x̂_u, AoC Δᶜ_u', 'closed-form counterfactual contrast (8)-(9)',
       'report (Δᶜ, CET, margin)', 'none (stateless estimator); tracks Â if the head is re-exported'],
      ['Synchronization', 'CET, mismatch flag, projected error, margin',
       'running median margin m̄', 'three-clause gate (14) + margin-matched level',
       'transmit / suppress; level ℓ ∈ {1..L}', 'θ_gate and η set by the meta agent'],
      ['Scheduling (per cell)', 'AoC, CET, SINR, payload, estimated latency',
       'per-cell occupancy', 'drift-plus-penalty ranking (15), greedy top K_max',
       'admit up to K_max users per slot', 'V set by the meta agent'],
      ['Placement + mobility', 'queue backlogs, backhaul state, RSRP margin to neighbours',
       'warm-replica location per user', 'argmin estimated completion latency; A3-margin handover prediction',
       'edge / cloud routing; background pre-migration', 'none (myopic, re-evaluated every slot)'],
      ['Meta (reflection)', 'realized CFS, channel occupancy', 'EWMA of CFS',
       'dead-band control toward target φ', 'set (V, θ_gate, η)',
       'the adaptation layer; inactive at φ = 0.975, active at φ = 0.93 (Sec. VII-G)'],
    ])

add('alg', title='Algorithm 1  CoFA orchestration (one slot k)', lines=[
 '1:  **for each** user u **in parallel do**   ▷ perception agent',
 '2:      x̂_u ← Â x̂_u ;  e_u ← x_u − x̂_u ;  w ← w_loc(x_u) ;  m_u ← margin(x_u)',
 '3:      CET_u ← average over h ∈ H of the contrast (8)−(9)',
 '4:      Δᶜ_u ← Δᶜ_u + max(CET_u − ψ₀, 0)',
 '5:  **end for**',
 '6:  S ← { u : gate (14) fires }, restricted to users idle and not in a handover gap',
 '        ▷ synchronization agent',
 '7:  **for each** u ∈ S **do**  ℓ(u) ← max( ℓ_min, min{ ℓ : s_ℓ ≤ m_u/ς } ), forced to L if inconsistent',
 '8:  **for each** u ∈ S **do**  n(u) ← arg min_n L̂_u^(n)   ▷ placement agent',
 '9:  P ← { u : predicted handover } ; issue background pre-migration for P   ▷ mobility agent',
 '10: compute Ψ_u by (15) ; **for each** cell m admit the top (K_max − n_m) users by Ψ   ▷ scheduling',
 '11: transmit ; on delivery x̂_u ← Â^τ x_u(k_gen) + ζ and Δᶜ_u ← 0',
 '12: **every** T_meta slots update (V, θ_gate, η) from realized CFS and occupancy   ▷ meta agent',
])

md(r"""
## B.  Analysis

**Proposition 3 (hardness).** The single-slot joint problem of selecting a transmitting subset, a fidelity level and a compute node for each selected user so as to maximize the total drift-plus-penalty score subject to the per-cell limit K_max and per-node compute capacity is NP-hard.

*Proof sketch.* Restrict to a single cell whose slot carries a fixed number of bits and two compute nodes of finite capacity. Each admitted user consumes b_(ℓ(u)) bits of the slot and C cycles at its node and contributes value Ψ_u; because the fidelity levels give different users different bit weights, this is an instance of the multiple-knapsack problem with heterogeneous item weights, which is NP-hard, and the reduction is polynomial and value preserving. Restricting to a single fidelity level would equalize the weights and admit a greedy solution, which is why the level dimension is retained. ∎

The next result says what the ranking (15) optimizes. It is a design rationale rather than a headline contribution: it is relative to an approximation factor this implementation does not measure, and at the nominal operating point the constraint it reasons about does not bind.

**Theorem 2 (utility gap and backlog).** With the per-slot utility U(k) = Σ_(u admitted) V CET_u(k) p_u^del(k) / [(b_(ℓ(u))/B₀) max(L̂_u/δ₀, ½)], i.e. the reward part of (15) with the backlog term removed, and let L(k) = ½ Σ_u (Δᶜ_u(k))². With bounded per-slot relevance and service and a greedy admission rule attaining at least a factor ϱ ∈ (0,1] of the maximum single-slot index,

$ lim inf (1/K) Σ_k E[U(k)] ≥ ϱ U* − B/V,   lim sup (1/K) Σ_k Σ_u E[Δᶜ_u(k)] ≤ ( B + V(U* − U^feas) ) / ϵ, || 16

where U* is the optimal time-average utility, U^feas the utility attained by a feasible randomized policy that keeps the AoC backlog stable with slack ϵ > 0, and B a constant bounding the second moments of the per-slot relevance arrivals and of the service process.

The proof is in Appendix A.

Three qualifications set the scope of the result. The guarantee is relative to a ϱ-approximation, so the gap to the offline optimum is (1 − ϱ)U* + B/V and does not vanish as V grows; ϱ is moreover not measurable in this implementation, because the placement agent chooses nodes independently of admission. The ranking (15) binds only when the gate admits more users than a cell can serve, which in the nominal scenarios it does not, and Section VII-C reports what it is worth in the two regimes where it does. The theorem is therefore presented as the reason the index has the form it has, and its proof is deferred to the appendix.

*Complexity.* Per slot, perception costs O(N|H|d²), gating and level selection O(NL), placement O(NM) and admission O(N log N). All matrix powers and covariances are precomputed. There is no training phase; the only online adaptation is the three scalars of the meta agent.
""")

md(r"""
# VI.  EXPERIMENTAL METHODOLOGY

## A.  Simulator and Statistical Protocol

The simulator is slotted with δ = 10 ms and models mmWave path loss with correlated shadowing, inter-cell interference through the proxy described below, OFDMA uplink sharing with per-cell concurrency limits, A3 handover with hysteresis, time-to-trigger and interruption gap, SINR-dependent residual erasure, heterogeneous edge servers with FIFO queues, a cloud across a jittered backhaul, inter-edge forwarding, cold and pre-emptive state migration, per-user energy accounting, and the application models of Section III-B. Table III lists the parameters.

> *Tooling.* The simulator, the experiment driver, the statistical analysis and the figures are the author's own Python, built on NumPy, SciPy, pandas, scikit-learn and Matplotlib at the versions pinned in the reproduction package. Generative AI assistants were used for language editing and for drafting and refactoring parts of the simulation and figure code; they were not used to generate results. Every number in this manuscript is computed at document-build time by the released code from the released result files, and the author verified the model, the code and the analysis.
""")

intf = pd.read_csv(os.path.join(RES, 'e17_interference.csv'))


def INTF(sc, mdl, col):
    return float(intf[(intf.scenario == sc) & (intf.model == mdl)][col].iloc[0])


_ip = os.path.join(RES, 'e18_interference_sched.csv')
_intf_txt = ''
if os.path.exists(_ip):
    _isd = pd.read_csv(_ip)
    _a = _isd.groupby('method').critical_accuracy.mean()
    _b = main[main.scenario == 'S1'].groupby('method').critical_accuracy.mean()
    _common = [m for m in ORDER if m in _a.index and m in _b.index]
    _ra = pd.Series(_a[_common]).rank(ascending=False)
    _rb = pd.Series(_b[_common]).rank(ascending=False)
    _tau = float(stats.kendalltau(_ra, _rb).statistic)
    _mx = float(np.abs(_a[_common] - _b[_common]).max())
    _sw = [(m, int(_ra[m]), int(_rb[m])) for m in _common if _ra[m] != _rb[m]]
    # stated from the measurement rather than asserted: which configurations sit
    # at the top is exactly what this check is testing
    _topn = sorted(_common, key=lambda k: _ra[k])[:4]
    _topn_b = sorted(_common, key=lambda k: _rb[k])[:4]
    if _topn == _topn_b:
        _same_top = "The leading four configurations are the same, in the same order."
    elif set(_topn) == set(_topn_b):
        _same_top = ("The leading four configurations are the same set, though "
                     "not in the same order.")
    else:
        _gone = [m for m in _topn_b if m not in _topn]
        _same_top = (f"The leading four change by one membership: "
                     f"{' and '.join(_gone)} leaves it.")
    _intf_txt = (
        f"Re-running the whole comparison in S1 under the schedule-coupled model over twelve seeds costs "
        f"every policy accuracy - between {np.abs(_a[_common] - _b[_common]).min():.2f} and {_mx:.2f} "
        f"points - and preserves the ordering almost exactly (Kendall tau = {_tau:.2f}): "
        + (f"the only movement is one adjacent swap, between {_sw[0][0]} and {_sw[1][0]}, whose means "
           f"differ there by {abs(_a[_sw[0][0]] - _a[_sw[1][0]]):.2f} points. "
           if len(_sw) == 2 else
           f"{_word(len(_sw))} policies change rank. ")
        + _same_top)
    _p2 = os.path.join(RES, 'e18b_interference_sched_s2s3.csv')
    if os.path.exists(_p2):
        _i2 = pd.read_csv(_p2)
        _tt, _mm = {}, {}
        for _sc in ('S2', 'S3'):
            _x = _i2[_i2.scenario == _sc].groupby('method').critical_accuracy.mean()
            _y = main[main.scenario == _sc].groupby('method').critical_accuracy.mean()
            _cc = [m for m in ORDER if m in _x.index and m in _y.index]
            _tt[_sc] = float(stats.kendalltau(
                pd.Series(_x[_cc]).rank(ascending=False),
                pd.Series(_y[_cc]).rank(ascending=False)).statistic)
            _mm[_sc] = float(np.abs(_x[_cc] - _y[_cc]).max())
            _top = sorted(_cc, key=lambda m: -_x[m])[:4]
            _tt[_sc + 'top'] = all(_y[m] >= _y[sorted(_cc, key=lambda z: -_y[z])[3]]
                                   for m in _top)
        _intf_txt += (
            " The same check was repeated in the other two scenarios, where the link budgets and the "
            f"concurrency limits differ: Kendall tau = {_tt['S2']:.2f} in S2 and {_tt['S3']:.2f} in S3, "
            f"with the largest change in any policy's mean {_mm['S2']:.2f} and {_mm['S3']:.2f} points, and "
            + ("the top four unchanged in both."
               if _tt['S2top'] and _tt['S3top'] else
               "one change of membership in the top four.")
        )
    _intf_txt += (" The approximation is therefore load bearing for the absolute rates and not for any "
                  "claim made here.")

md(f"""
*The interference model is a proxy, and here is what it is worth.* Inter-cell interference is modelled by
scaling the sum of a user's received powers at the non-serving cells by a beamforming-isolation factor and
adding it to the thermal noise, deliberately decoupled from the neighbouring cells' scheduling decisions:
a schedule-dependent term would make the channel a function of the policy under test and destroy the
bit-identical realization. That choice is priced rather than asserted, both quantities having been measured
at the instant the rate is computed. The link is *not* noise dominated: with the proxy the median
interference-to-noise ratio is
{INTF('S1','geom','inr_median_db'):.1f} dB in S1, {INTF('S2','geom','inr_median_db'):.1f} dB in S2 and
{INTF('S3','geom','inr_median_db'):.1f} dB in S3, so the median SINR is depressed by
{INTF('S1','geom','sinr_loss_median_db'):.1f} dB in S1 relative to a noise-only channel and only
{100*INTF('S1','geom','frac_noise_dominated'):.1f}% of transmitting user-slots are noise dominated. Replacing
the proxy by a genuine uplink model - the interference at the serving cell from the users actually
transmitting to other cells in that slot - raises the median ratio to
{INTF('S1','sched','inr_median_db'):.1f} dB in S1, because a semantic update occupies only a fraction of a
slot and the concurrent set is small but close, so the two constructions bracket about
{INTF('S1','sched','inr_median_db') - INTF('S1','geom','inr_median_db'):.0f} dB of interference in S1 with
the proxy at the optimistic end. {_intf_txt} Absolute latencies and rates should be read as model
dependent; the relative ordering, which is what this paper claims, is not.

""")

md(r"""
*Strict common random numbers.* The latent state trajectory, the mobility and shadowing realization, the per-(user, slot) erasure and reconstruction-noise draws and the backhaul jitter are pre-generated from dedicated streams indexed by the seed alone, so every policy at a given seed meets a bit-identical realization: the same trajectory, the same channel, and the same erasure outcome for whichever slot it transmits in. This removes the confound a policy-dependent random stream would introduce.

*Difficulty calibration.* For each seed the decision head is calibrated - the threshold θ for the linear head, a class bias for the neural head - so the ground-truth decision-transition rate matches a target λ_tr; without it the fraction of causally critical time varies by more than an order of magnitude across seeds and produces degenerate runs.

*Confirmatory hypotheses and multiple-comparison control.* The claims this paper rests on are declared in
advance as a family of fifteen paired comparisons on critical-instant decision accuracy: CoFA against the
AoI-optimal, goal-oriented and AoII-triggered schedulers in each scenario, the decision-centric learned
policy against the network-centric one in each scenario, and the causal-semantic gate against its ablation
in each scenario. Every other comparison - the sensitivity studies, the environmental sweeps, the remaining
ablation rows, the admission-limited regimes - is exploratory, reported with confidence intervals and effect
sizes but outside the confirmatory family. That family is controlled both ways, by Holm-Bonferroni for the
family-wise error rate and Benjamini-Hochberg for the false discovery rate, both at 0.05; Table @CONF
reports raw and adjusted values side by side.

*Seed hygiene.* Three disjoint blocks of seeds are used and never mixed. Seeds 1-20 are the *evaluation* block, on which every comparison in this paper and in the Supplementary Material runs but one. Seeds 101-108 are the *tuning* block: the four parameter studies of Section VII-H run there and nowhere else, and the operating points (φ = 0.975 and φ = 0.93, θ_gate, η, V) were fixed on that block before any evaluation seed was run, so the parameter studies are tuning evidence rather than results on the evaluation set. Seeds 5000 and above drive the learned baselines' training, with a held-out episode at seed 91 for the convergence curves, so no learned policy has been trained on an evaluation realization. No number in this paper comes from selecting a configuration on the seeds it is then scored on.

*Paired statistics.* Seed counts are 20 for the main comparison, the ablation and the S1C comparison, 12 for S1D and both congested ablations, 10 for the robustness study and the congested V sweeps, 8 for the sensitivity studies and 6 for the environmental sweeps. Figures show means with 95% confidence intervals, comparisons use paired two-sided t-tests and Wilcoxon signed-rank tests on the same seeds with Cohen's d_z as effect size, and the first 2 s of each run is discarded as warm-up.

> *What the paired statistics do and do not license.* Common random numbers remove the between-seed component of the variance from every contrast, which is what makes twenty seeds sufficient, but it also makes the standardized effect sizes large by construction: d_z is the paired mean difference divided by the standard deviation of the *difference*, and that denominator has been deliberately minimized. The standardized values should therefore not be compared against conventions calibrated on independent samples, and they are not interpreted here as measures of practical importance. What is interpreted is the paired mean difference itself, in points of accuracy or in Mb/s, with its interval; it is reported next to every p-value in Tables IV-VII and in the confirmatory family. The corresponding limitation is one of scope rather than of power: a small p-value certifies that the ordering is stable across the realizations of *these* scenario families, and says nothing about whether it survives a different application model, which is why the ablation, the parameter studies and the mis-specification study are reported separately rather than folded into the same family.

## B.  Scenarios

> **S1 - dense immersive collaboration.** 100 pedestrian users (0.8-2.2 m/s), seven cells over 600 m, 100 MHz uplink per cell, at most 10 concurrent uplink users per cell, 2% residual erasure, linear-Gaussian context with a margin head.

> **S2 - high-mobility, safety-critical uplink synchronization.** The name describes what is modelled - the uplink state-reporting half of a remotely embodied loop, at vehicular speed and with a short decision deadline - and not a closed teleoperation loop, whose downlink actuation path is absent and would violate assumption (A1). 60 users at 5-15 m/s over 900 m, 80 MHz per cell, at most 8 concurrent users, twice the event rate and a larger event magnitude, 5% residual erasure, longer migration and interruption times, 50% higher per-update compute cost.

> **S3 - non-linear XR head-pose context.** 80 walking users, 100 MHz per cell, the six-dimensional non-Gaussian pose/attention process of Section III-B, a three-class multilayer-perceptron decision head, and an orchestrator holding only a least-squares linear surrogate of the dynamics, identified from the 2 s warm-up window and then frozen. The scenario breaks linearity, Gaussianity, model correctness and boundary linearity at once.

> *The decision head is a task, not a learned model, and is specified exactly.* It is a fixed three-class perceptron with one hidden layer of 12 tanh units, drawn once per seed from the task stream: W₁ ~ N(0, 1/d) of shape d × 12 with d = 6, b₁ ~ N(0, 0.2²), W₂ ~ N(0, 1/12) of shape 12 × 3, b₂ ~ N(0, 0.1²). Nothing is fitted, so there is no gradient training and no train/validation split: the head *defines* the ground-truth labels the experiment is scored against, exactly as a linear margin rule does in S1 and S2. Its only calibrated quantity is a scalar bias on the middle-class logit, selected once per seed by a 46-point grid search on the warm-up window so that the realized decision-transition rate matches the target λ_tr of Table III; the same procedure calibrates the threshold θ of the linear head, so difficulty is comparable across seeds, scenarios and head types. What the orchestrator must *estimate* - the local boundary normal and the decision margin - is obtained by differentiating the gap between the top two logits, through the linear surrogate of the dynamics and never through the head's parameters.

> **S1C and S1D - admission-limited regimes.** S1C is S1 with 160 users, 60 MHz per cell and at most three concurrent uplink users per cell. S1D is harsher still - 200 users, 40 MHz and at most one concurrent uplink user per cell - and is constructed so that the update demand admitted by the causal gate exceeds the per-cell service capacity, which is the condition under which the drift-plus-penalty ranking of Section V-A is actually exercised.

## C.  Baselines

All baselines run in the same simulator over the same realizations and differ only in orchestration logic.

> 1) **Cloud-Only** - periodic full-fidelity updates to the cloud.
> 2) **Edge-Only** - periodic full-fidelity updates to the serving edge.
> 3) **Latency-Aware** - periodic updates, greedy min-latency node selection.
> 4) **AoI-Aware** - max-age-first scheduling (AoI-optimal family), edge placement.
> 5) **AoII-Aware** - transmits only while the receiver's decision is *currently wrong*, prioritized by accumulated incorrectness; the reactive counterpart of CoFA's predictive gate.
> 6) **UoI-Aware** - age weighted by an exogenous context weight, here the inverse decision margin: decision-aware but not innovation-aware.
> 7) **Semantic-Aware** - distortion-triggered transmission in signal space, two fidelity levels.
> 8) **Goal-Oriented** - triggers and prioritizes on the estimated decision-error probability under no transmission, i.e. (8) evaluated at a single short horizon, with the same margin-matched fidelity level as CoFA. It shares CoFA's decision model and its look-ahead and differs only in using an absolute risk rather than the interventional contrast against the post-update alternative, so the CoFA-vs-Goal-Oriented comparison isolates the value of the contrast.
> 9) **DRL (DQN)** - a Double-DQN with two hidden layers of 128 units, experience replay, target network and annealed exploration, trained for 140 episodes on the *network-centric* reward standard in the MEC offloading literature. Three independent training seeds are run per base scenario for each reward; the median seed by held-out accuracy supplies the network used in the comparison and all three are reported in Section VII-J. The admission-limited regimes reuse the S1 network, so the learned policies are evaluated out of distribution there.
> 10) **DRL-CF** - the same learner, architecture, features and budget, trained on a *decision-centric* reward that penalizes an incorrect remote decision directly. The pair (9)-(10) isolates the objective from the learning machinery; convergence curves are reported in Section VII-J.

## D.  Metrics

> *Primary and policy-agnostic.* **Decision accuracy**, the fraction of slots with g(x̂_u) = g(x_u); **critical-instant decision accuracy**, the same quantity restricted to the 200 ms window after each ground-truth decision transition; and the **decision-restoration delay** from a ground-truth transition until the remote decision agrees again, reported as mean, 99th percentile and fraction restored within 20 ms. The restoration statistic conditions on the replica actually having become inconsistent at the transition, so a transition absorbed without ever being wrong contributes no event; it is therefore *harder* for policies that keep the replica fresh and should be read together with critical-instant accuracy, the one metric whose denominator is completely independent of the policy.

> *Counting.* Eleven policy families are compared - the ten baselines and CoFA - and CoFA appears at two operating points, the fidelity-oriented φ = 0.975 and the efficiency-oriented φ = 0.93 (CoFA-E), so twelve configurations appear in every table and figure. Where the text contrasts four decision-aware families with seven decision-agnostic ones, the four are the AoII-triggered scheduler, the goal-oriented scheduler, the decision-centric learned policy and CoFA; the two CoFA operating points are one family and are never counted as independent evidence.

> *Reliability.* The **successful critical delivery** rate: among *generated* critical updates - those whose CET at generation exceeds 0.05 - the fraction delivered within the 20 ms deadline, with an update destroyed by residual erasure counted as a failure. Its denominator is the number of critical updates a policy chooses to generate, which differs by more than an order of magnitude across the baselines, so it measures delivery discipline rather than coverage; coverage is what the restoration statistics and critical-instant accuracy measure.

> *Decision-relevance instruments.* CFS and its three components separately, mean and 95th-percentile AoC, the measured irreducible post-update error probability of Theorem 1, and Decision Efficiency.

> *Network and system.* Mean and 99th-percentile update latency; the same for causally critical updates; aggregate uplink rate; per-user update rate; per-user device energy; handover, cold-migration and pre-migration overhead; conventional AoI, measured from the last *applied* update; and orchestration wall-clock time per slot.
""")

add('table', span=2, label='Table III',
    caption='Simulation parameters. Bracketed values are S1 / S2 / S3.',
    cols=['Parameter', 'Value', 'Parameter', 'Value'],
    widths=[1.45, 1.15, 1.45, 1.05],
    rows=[
      ['Slot duration δ', '10 ms', 'Carrier frequency f_c', '28 GHz'],
      ['Horizon (warm-up)', '20 s (2 s)', 'Per-cell uplink bandwidth W', '100 / 80 / 100 MHz'],
      ['Base stations M', '7 (hex + centre)', 'Max concurrent users/cell K_max', '10 / 8 / 10'],
      ['Service area', '600 / 900 / 700 m', 'UE transmit power P_tx', '23 dBm'],
      ['Users N', '100 / 60 / 80', 'Combined array gain G', '30 dBi'],
      ['User speed', '0.8-2.2 / 5-15 / 0.6-1.8 m/s', 'Receiver noise figure', '7 dB'],
      ['Handover hysteresis Δ_hys', '4 dB', 'Shadowing σ_ξ (AR coefficient)', '7.8 dB (0.999)'],
      ['Time-to-trigger T_TTT', '100 ms', 'Beam isolation β', '0.08'],
      ['Handover interruption T_HO', '30 / 35 / 30 ms', 'Residual erasure ε₀', '0.02 / 0.05 / 0.03'],
      ['Erasure SINR threshold (cap)', '2 dB (BLER ≤ 0.6)', 'Waypoint re-draw probability', '0.002 per slot'],
      ['Edge capacity f̄ (spread)', '25 Gcycle/s (0.6-1.4×)', 'Cloud capacity f_c', '250 Gcycle/s'],
      ['Cycles per update C', '4.0 / 6.0 / 5.0 ×10⁷', 'Backhaul one-way τ_b (jitter)', '12 ms (4 ms)'],
      ['Inter-edge / migration τ_m', '20 / 25 / 20 ms', 'Full payload B₀', '40 kbit'],
      ['Fidelity levels (α_ℓ, s_ℓ)', '(0.15, 0.55), (0.40, 0.28), (1.00, 0.08)', 'Minimum level ℓ_min', '2'],
      ['Encoder energy κ, f_local, C_enc', '10⁻²⁸, 1 Gcycle/s, 0.25 C', 'State dimension d', '4 / 4 / 6'],
      ['Spectral radius ρ (S1, S2)', '0.992', 'Process noise σ_w (S1, S2)', '0.055'],
      ['Semantic-event rate p_e (S1, S2)', '0.008 / 0.016 per slot', 'Event magnitude μ (S1, S2)', '1.35 / 1.65'],
      ['Saccade rate / magnitude (S3)', '0.012 per slot / 3.2 rad s⁻¹', 'OU coefficient, scale (S3)', '0.972, 0.16'],
      ['Student-t d.o.f. (S3)', '3', 'Angular-rate limit (S3)', '6 rad s⁻¹'],
      ['Attention-switch rate (S3)', '0.004 per slot', 'MLP head width', '12 (tanh), 3 classes'],
      ['Decision-transition target λ_tr', '0.60 / 0.90 / 0.80 s⁻¹', 'Critical window', '200 ms'],
      ['CFS weights (w_d, w_r, w_f)', '(0.5, 0.3, 0.2)', 'Margin scale κ, offset ε', '1.0, 0.10'],
      ['Cognitive-freshness constant τ_a', '1.20', 'AoC dead-zone ψ₀', '0.005'],
      ['CET horizons H (slots)', '{0, 5, 10, 20}', 'Level-selection margin ς', '1.5'],
      ['Drift-plus-penalty weight V', '2.0 (adaptive)', 'Latency normaliser δ₀ in (15)', '20 ms'],
      ['Gate θ_gate, floor η', '0.005, 0.30 (adaptive)', 'Handover-imminent score boost', '×1.4'],
      ['Meta target φ', '0.975 (CoFA) / 0.93 (CoFA-E)', 'Meta period T_meta', '250 ms'],
      ['Pre-migration trigger', 'RSRP gap > 0.45 Δ_hys', 'Critical-update deadline', '20 ms'],
      ['Evaluation seeds', '1-20', 'Tuning seeds', '101-108'],
      ['Interference proxy', 'β = 0.08, geometry-only', 'Look-ahead set H', '{0, 5, 10, 20} slots'],
      ['Baseline update period', '50 ms', 'Semantic / UoI / goal thresholds', '0.45 / 0.06 / 0.06'],
      ['DRL architecture', '2×128, Double DQN, Adam', 'DRL training', '140 episodes × 6 s, 3 seeds'],
    ])

DISCUSSION = r"""
# VIII.  DISCUSSION

## A.  What the Evidence Supports

The ablation and the learned-baseline pair point at the same conclusion, and it is narrower than the framework as a whole: *the objective is what matters, and causal-semantic gating is the mechanism that carries it*. Removing the counterfactual signal costs more than every other component combined, and the baselines that come closest are precisely the other three that model the decision - the AoII-triggered scheduler, the goal-oriented risk-triggered scheduler and the deep-RL policy trained on a decision-centric reward, the last architecturally identical to the network-centric learner and far ahead of it. Four very different mechanisms - a reactive incorrectness trigger, an absolute-risk trigger, a learned value function and a closed-form counterfactual contrast - cluster together once pointed at decision correctness rather than at freshness or throughput, and separate from everything that is not. That clustering is stronger evidence for the thesis than a win by a single hand-designed policy, and the residual margins *within* the cluster are correspondingly modest: a fraction of a point to about two points, and negative against the AoII trigger in the non-linear scenario.

The evaluated configuration therefore isolates three active mechanisms - causal-semantic gating, margin-matched fidelity selection and predictive pre-migration - and these are what the paper claims. Adaptive fidelity-level selection buys bandwidth at a small accuracy cost and predictive migration protects the latency tail under mobility; the placement rule, the drift-plus-penalty ranking and the meta-controller are retained for completeness and are shown inert at the nominal operating point (Table VII), becoming measurable only where the per-cell service capacity binds (Section VII-C).

## B.  Why Freshness and Correctness Come Apart

CoFA operates at a conventional Age of Information one to two orders of magnitude larger than every policy that optimizes freshness directly, while producing more correct decisions. Under a freshness-centric design philosophy that is close to a contradiction; under the calculus of Section IV it is expected, because AoI charges for elapsed time whereas AoC charges for elapsed *relevance*, and the two decouple precisely when the state dynamics are slow relative to the decision margin - the common regime in immersive applications, where most of the scene is quasi-static most of the time. AoI should therefore be treated as a diagnostic rather than an objective whenever a downstream decision exists and can be modelled.

The AoII-based scheduler deserves separate comment as the most economical baseline in the study and, on some metrics, the strongest. It transmits only while the remote decision is already wrong, which is cheap and repairs errors quickly, but it lets the replica drift arbitrarily far in between - its representational fidelity is the lowest in the study - and it cannot act before an error occurs. The comparison between CoFA and AoII is therefore the cleanest available measurement of what *prediction* is worth on top of *reaction*.

## C.  Deployment, Coding and 6G Positioning

The estimator runs on the device and needs only the innovation with respect to the receiver's dead-reckoned replica, which the device maintains from acknowledgements; no new signalling is required beyond a compact importance field in the scheduling request, analogous to a buffer-status report. The orchestrator needs an estimate of the decision geometry - the local boundary normal and margin - which the application can export as a linearization of its decision head and refresh lazily, and Section VII-I quantifies the cost of that estimate being wrong. The scheme is therefore compatible with a split between an application-layer semantic profile and a RAN-level scheduler. In management terms the five agents are a closed control loop over an existing orchestration substrate rather than a replacement for one: they consume telemetry the substrate already exposes - buffer status, reference-signal measurements, node occupancy - and emit decisions at the interfaces a slicing and service-orchestration architecture such as [35] already offers, so what the framework adds is the objective the loop is closed on and not a new control plane. It is also complementary to learned semantic encoders: the fidelity levels of Section III-C stand in for whatever rate-distortion operating points such an encoder exposes [57]-[59], and CoFA decides *when* to invoke them and *which* one, using a signal that an encoder-side design cannot compute because it depends on network state and on the shared budget.

What "6G" means here is stated explicitly. The simulator uses mmWave propagation, OFDMA uplink sharing, A3 handover, edge computing and conventional queueing abstractions, all shared with advanced 5G systems. What makes the study 6G-*oriented* is the operating regime and the problem framing: IMT-2030-class user densities and bandwidths, edge-resident AI inference in the loop, and an application whose correctness criterion is a machine decision rather than a human-perceived rate. 6G-specific candidate technologies - reconfigurable intelligent surfaces, cell-free architectures, sub-THz bands, integrated sensing and communication - are not modelled, and no claim made here depends on them. The contribution is an orchestration principle that applies to any network in which a machine decision closes the loop.
"""

LIMITATIONS = r"""
# IX.  LIMITATIONS AND THREATS TO VALIDITY

> *Synthetic application traces, and this is the largest open point.* Scenario S3 replaces the linear-Gaussian abstraction with a non-linear, non-Gaussian pose and attention process whose parameters lie in physiologically plausible ranges for seated XR rather than being fitted to a recorded dataset, and drives a neural decision head from a fitted linear surrogate. It is a generative model, not a recorded trace, and no external validity for real head motion is claimed. It reproduces the *statistical features* the calculus is sensitive to - heavy-tailed innovations, discrete jumps, rate saturation and a curved decision boundary - and Section VII-K measures how the estimator degrades under them; it cannot reproduce the *specific* temporal structure of real attention: fixation-duration distributions, head-gaze coupling, content-driven synchrony across users, or the correlation between motion and scene semantics. Cross-user synchrony is the one that would most plausibly change a conclusion, because it would make demand bursty and push the system towards the admission-limited regime of Section VII-C, where the drift-plus-penalty layer matters more and the gate relatively less. The substitution path is implemented rather than promised: a recorded trajectory enters through exactly the interface the generative models use - a pre-generated array that no policy can influence, so common random numbers continue to hold - and the reproduction package contains the converter and a trace-driven scenario S4 that becomes active as soon as a trace is supplied.

> *Simulation rather than testbed.* The radio, queueing and mobility models follow standard practice but cannot reproduce protocol-stack effects such as HARQ retransmission timing, scheduling-request round trips or edge virtualization overheads. Absolute latencies should be read as lower bounds; the relative ordering of policies, which is what the paper claims, is far more robust because every policy runs on identical realizations. The 10 ms orchestration slot is also coarse relative to the 20 ms deadline, so part of the measured tail separation is a one-slot versus two-slot distinction; a production system would run the same logic on a far finer NR slot grid.

> *Scope of the theory, and of the causal claim.* Proposition 2 covers one accumulating form of AoII and UoI and does not cover non-linear time penalties or version age. Theorem 1 bounds decision error by AoC only up to an additive irreducible term, which is measured but not controlled. Theorem 2 is relative to a greedy approximation and, in the nominal scenarios, is not exercised at all. CET itself is a model-based counterfactual contrast under assumptions (A1)-(A4), not an effect identified from observational data; (A1) - that transmitting does not perturb the sensed process - excludes closed-loop actuation, which is exactly the setting a teleoperation deployment would eventually require. The robustness study perturbs the direction used by the importance estimator while leaving the decision-inconsistency test exact, so it reports a lower bound on the cost of mis-specification.

> *Energy model.* Device energy comprises uplink transmit energy and an on-device encoding term κ f_local² C_enc; both scale with the number of transmitted updates, so the energy column is close to a monotone restatement of the update rate.

> *Inert components.* Three of the five modules - placement, the AoC backlog inside the ranking, and the meta-controller - produce differences indistinguishable from zero at the nominal operating point. The AoC backlog was re-measured in the severely admission-limited cell, where at a common weight it appears worth about one accuracy point; once each backlog variable is given its own best weight that advantage falls to about a tenth of a point (Section VII-C), so the honest statement is that the choice of backlog variable inside the ranking is not measurable, and the value of AoC lies in the gate and in Theorem 1 instead. The placement agent and the meta-controller were ablated only in the milder congested regime, where both remain within noise. The scope of the claim is set accordingly: three mechanisms are demonstrated, the remaining modules are retained for completeness and reported inert at the nominal operating point, and no result in this paper is attributed to them. Relatedly, the "AoC backlog replaced by AoI" variant substitutes a dimensionless accumulated probability by a quantity in seconds, so at a single V it changes the relative weight of the two terms of (15) as well as the backlog itself; Section VII-C therefore reports that comparison at each backlog's own best V, and the single-V row in the ablation table should be read as "this backlog, at this weight".

> *Cloud placement.* The reported cloud latency is a closed-loop figure including the return of the decision, so cloud-only placement cannot meet the 20 ms critical deadline at any load and its successful-delivery rate is zero by construction. This is a property of the deadline and the backhaul, not a failure of the policy.

> *The stated objective is a weak proxy, and the metrics are composites.* Section VII-L shows that, at the weights used here, the composite CFS is essentially uncorrelated with the policy-agnostic decision metric across the policy population, and that only its decision-consistency term predicts correctness; problem (4) should therefore be read as the control objective the meta agent regulates, not as a ranking criterion. That CFS is a weighted composite and AoC uses a dead-zone is mitigated by making the primary metric - decision accuracy at critical instants, and the restoration statistics - independent of both, by applying the dead-zone identically to every policy, by reporting sensitivity to the composite's parameters, and by validating CFS against the policy-agnostic metric rather than assuming they agree.
"""

CONCLUSION = r"""
# X.  CONCLUSION

Decision correctness has been substituted for network-centric quality of service as the organizing objective of edge orchestration in immersive 6G applications, with the counterfactual value of a state update as the central instrument. The Causal Effect of Transmission quantifies the reduction in downstream decision-error probability caused by sending a given update; it has a closed form under a linear-Gaussian state model with a margin rule, extends to a non-linear head through the local boundary normal, and costs a handful of vector operations per user per slot. A margin-normalized fidelity score and an importance-weighted age with a stated relationship to AoI, AoII and UoI turn that signal into an objective and a scheduling backlog, and a multi-agent orchestrator turns both into gating, fidelity, scheduling, placement and migration decisions - of which the gate carries almost all of the accuracy benefit, the margin-matched fidelity rule buys about a fifth of the bandwidth at negligible cost, and predictive migration protects the latency tail under mobility.

Across five scenarios and ten baselines under strict common random numbers, causal-semantic gating was the dominant source of the gain, and the baselines that approached it were exactly the others that model the decision: a reactive incorrectness trigger, an absolute-risk trigger, and a learned policy given a decision-centric rather than a network-centric reward - @@CLUSTER@@. That mechanisms this different cluster together once pointed at decision correctness, and separate from everything that is not, is the most durable message here - the objective matters more than the machinery - and the corollary, that the proposed policy runs at a substantially larger conventional Age of Information than every freshness-optimized baseline and is nevertheless more correct, shows that freshness and correctness are not the same target.

Future work will substitute recorded XR and teleoperation traces for the generative application model, replace the linear surrogate by learned causal surrogates for strongly non-linear heads, couple CET-driven gating with learned task-oriented encoders, extend the orchestration layer to multi-cell and multi-operator coordination, and validate the framework over the air.
"""

# ===========================================================================
add('h1', text='VII.  RESULTS')
add('fig', span=2, file='fig1_architecture.png', label='Fig. 1',
    caption='The CoFA orchestration architecture. Five agents act on disjoint parts of the system '
            'state under one objective; Table II specifies each.')
add('h2', text='A.  Main Comparison')

bb = {sc: best_base(sc, 'critical_accuracy') for sc in SCEN}
pp = {sc: pair(sc, b=bb[sc]) for sc in SCEN}
pe = {sc: pair(sc, a='CoFA-E', b=bb[sc]) for sc in SCEN}
pg = {sc: pair(sc, b='Goal-Oriented') for sc in SCEN}
pa = {sc: pair(sc, b='AoII-Aware') for sc in SCEN}
pd_ = {sc: pair(sc, a='DRL-CF', b='DRL (DQN)') for sc in SCEN}

# the training evidence a reader needs in order to accept the learned pair as a
# fair comparison, summarized here and reported in full in the Supplement
_drl_txt = ''
try:
    _dq0 = pd.read_csv(os.path.join(RES, 'e0_dqn_convergence.csv'))
    _dq0 = _dq0.dropna(subset=['eval_critical_accuracy'])
    _plat = {}
    for (_sc, _v), _g in _dq0.groupby(['scenario', 'variant']):
        _g = _g.sort_values('episode')
        _n = max(len(_g) // 5, 1)
        _plat[(_sc, _v)] = (float(_g.eval_critical_accuracy.tail(_n).mean()),
                            float(_g.eval_critical_accuracy.max()))
    _e15 = pd.read_csv(os.path.join(RES, 'e15_drl_seeds.csv'))
    _e15['tag'] = _e15.variant.str.split('|').str[0]
    _e15['ts'] = _e15.variant.str.split('|').str[1]
    _gg = _e15.groupby(['scenario', 'tag', 'ts']).critical_accuracy.mean()
    _sp = {(sc, tg): _gg[(sc, tg)].max() - _gg[(sc, tg)].min()
           for sc in SCEN for tg in ('DRL (DQN)', 'DRL-CF')}
    _lo = _gg.groupby(level=[0, 1]).min()
    _hi = _gg.groupby(level=[0, 1]).max()
    _seps = [sc for sc in SCEN if _lo[(sc, 'DRL-CF')] > _hi[(sc, 'DRL (DQN)')]]
    _drl_txt = (
        "*The learned pair is a fair comparison, and the evidence for that is in the training curves.* "
        "Both policies were trained three times from independent initializations under an identical budget, "
        "and each trained network was then evaluated on all twenty evaluation seeds; the network used in "
        "Tables IV-VI is the median training seed by held-out accuracy, a rule fixed before the evaluation "
        "block was run. Neither policy is undertrained: held-out accuracy over the last fifth of training "
        f"sits within {max(abs(_plat[('S1','DRL (DQN)')][1] - _plat[('S1','DRL (DQN)')][0]), abs(_plat[('S1','DRL-CF')][1] - _plat[('S1','DRL-CF')][0])):.2f} "
        "points of the best value either reaches at any point in S1, so both have plateaued and the gap "
        "between them is not a difference in convergence. Training randomness is not negligible - across "
        f"three seeds the network-centric policy spans {_sp[('S1','DRL (DQN)')]:.2f} points in S1 and "
        f"{_sp[('S3','DRL (DQN)')]:.2f} in S3 - "
        + (f"but the separation holds seed by seed in {' and '.join(_seps)}, where the worst "
           "decision-centric seed still beats the best network-centric one. "
           if _seps else "and the two seed ranges overlap in every scenario. ")
        + "Section VII-J of the Supplementary Material reports the curves, the per-seed spread and one "
          "degenerate training seed in full.")
except Exception:
    _drl_txt = ''

md(f"""
Tables IV-VI report the main comparison over 20 seeds per configuration under strict common random
numbers. Three findings organize the discussion.

*The policies that reason about the decision form a separate tier, with one exception that is reported
rather than smoothed over.* Ranked by critical-instant accuracy, {CLUSTER}. The three hand-designed
decision-modelling policies therefore sit above all seven that do not act on an estimate of decision risk -
cloud-only, edge-only, latency-aware, distortion-triggered, the AoI-optimal scheduler, the UoI-weighted
scheduler and the deep-RL policy with a QoS reward - in every scenario, while the learned member of the
group does so in two of the three. Section VII-J traces that exception to training variance rather than to
the objective: one of its three training seeds in S1 converged to a degenerate silent policy, and the
median-seed rule fixed in advance therefore selects a mediocre network there.
Taking the AoI-optimal scheduler as the strongest decision-agnostic policy, CoFA leads it by
{pair('S1', b='AoI-Aware')['delta']:+.2f} points in S1 ({pfmt(pair('S1', b='AoI-Aware')['p'])},
d_z = {pair('S1', b='AoI-Aware')['dz']:.2f}), {pair('S2', b='AoI-Aware')['delta']:+.2f} in S2 and
{pair('S3', b='AoI-Aware')['delta']:+.2f} in the non-linear scenario S3
({pfmt(pair('S3', b='AoI-Aware')['p'])}, d_z = {pair('S3', b='AoI-Aware')['dz']:.2f}), and the deep-RL
policy with a QoS reward by {pair('S1', b='DRL (DQN)')['delta']:+.2f},
{pair('S2', b='DRL (DQN)')['delta']:+.2f} and {pair('S3', b='DRL (DQN)')['delta']:+.2f} points. The
boundary between the two groups is not a gulf at every operating point, and in S1 it is crossed: the
decision-centric learned policy trails the AoI-optimal scheduler there by
{-pair('S1', a='DRL-CF', b='AoI-Aware')['delta']:.2f} points
({pair('S1', a='DRL-CF', b='AoI-Aware')['p']:.2f} on a paired test), so what separates cleanly in all three
scenarios is the objective *and* a mechanism that does not have to be learned. Between the hand-designed
members of the two groups the margin is
{pair('S1', a='Goal-Oriented', b='AoI-Aware')['delta']:+.2f} points in S1 at its narrowest.

*Within that tier the differences are smaller and instructive.* CoFA leads on critical-instant accuracy in
S1 ({pa['S1']['delta']:+.2f} points over the AoII-triggered scheduler, {pfmt(pa['S1']['p'])};
{pg['S1']['delta']:+.2f} over the goal-oriented scheduler) and in S2 ({pa['S2']['delta']:+.2f} and
{pg['S2']['delta']:+.2f} points). In S3, where the orchestrator has only a fitted linear surrogate of a
non-linear non-Gaussian process and the boundary is curved, the reactive AoII scheduler edges CoFA out by
{-pa['S3']['delta']:.2f} points ({pfmt(pa['S3']['p'])}), although CoFA-E recovers the lead
({M('S3','CoFA-E','critical_accuracy') - M('S3','AoII-Aware','critical_accuracy'):+.2f} points).
Linearization error erodes precisely the predictive component of the advantage, which is what the
look-ahead in (7) buys.

*The reliability and fidelity picture is not close.* The AoII-triggered scheduler and the decision-centric
learned policy reach their accuracy by transmitting almost nothing and letting the replica drift: their
cognitive fidelity scores in S1 are {M('S1','AoII-Aware','cfs'):.3f} and {M('S1','DRL-CF','cfs'):.3f}
against {M('S1','CoFA','cfs'):.3f}, their Age of Cognition is
{np.log10(max(M('S1','AoII-Aware','aoc_mean'), M('S1','DRL-CF','aoc_mean'))/M('S1','CoFA','aoc_mean')):.0f}
orders of magnitude larger, and
their successful-critical-delivery rates are {M('S1','AoII-Aware','scdd'):.1f}% and
{M('S1','DRL-CF','scdd'):.1f}% against {M('S1','CoFA','scdd'):.1f}%. The two CoFA operating points are the
only ones near the top of the accuracy ranking that also hold the highest successful-critical-delivery
rate; CoFA holds the lowest Age of Cognition of any policy, and CoFA-E trades that away, with
representational fidelity, for a further
{100*(1 - M('S1','CoFA-E','uplink_mbps')/M('S1','CoFA','uplink_mbps')):.0f}% of its uplink volume. On the
composite CFS, CoFA is second to the AoI-optimal scheduler in S1 by
{M('S1','AoI-Aware','cfs') - M('S1','CoFA','cfs'):.4f} and first in S2, which is reported rather than
rounded away. Its 99th-percentile latency for causally critical updates is
{M('S1','CoFA','crit_latency_p99'):.1f}, {M('S2','CoFA','crit_latency_p99'):.1f} and
{M('S3','CoFA','crit_latency_p99'):.1f} ms across the three scenarios, against
{M('S1','AoI-Aware','crit_latency_p99'):.1f}, {M('S2','AoI-Aware','crit_latency_p99'):.1f} and
{M('S3','AoI-Aware','crit_latency_p99'):.1f} ms for the AoI-optimal scheduler - at worst a factor
{min(M(sc,'CoFA','crit_latency_p99') and min(M(sc,b,'crit_latency_p99') for b in BASE)/M(sc,'CoFA','crit_latency_p99') for sc in SCEN):.1f}
below the nearest competitor - and it restores a correct remote decision within 20 ms in
{M('S1','CoFA','restore_le20'):.1f}% of cases in S1 against {M('S1','Edge-Only','restore_le20'):.1f}% for
the periodic edge policy. Fig. 2 shows the three headline quantities and Fig. 3 places all twelve
configurations in the accuracy/traffic plane; Section @CDFSEC gives the full latency distribution. Resource use
follows: in S1 CoFA
consumes {M('S1','CoFA','uplink_mbps'):.1f} Mb/s of uplink against
{M('S1','Edge-Only','uplink_mbps'):.1f} for Edge-Only ({red('S1','uplink_mbps'):.0f}% less) and
{M('S1','AoI-Aware','uplink_mbps'):.1f} for the AoI-optimal scheduler
({red('S1','uplink_mbps',ref='AoI-Aware'):.0f}% less), with CoFA-E at
{M('S1','CoFA-E','uplink_mbps'):.1f} Mb/s, while device energy falls from
{M('S1','Edge-Only','energy_mj'):.1f} mJ per user per second to {M('S1','CoFA','energy_mj'):.1f} and
{M('S1','CoFA-E','energy_mj'):.1f} mJ. As Decision Efficiency, CoFA-E obtains
{M('S1','CoFA-E','critical_accuracy')/M('S1','CoFA-E','uplink_mbps'):.1f} accuracy points per Mb/s in S1
against {M('S1','AoI-Aware','critical_accuracy')/M('S1','AoI-Aware','uplink_mbps'):.2f} for the AoI-optimal
scheduler; only the policies that give up representational fidelity entirely score higher.

*The objective matters more than the mechanism.* The two learned policies share an architecture, a feature
set, a training budget and a random seed, and differ only in their reward; the decision-centric one wins by
{pd_['S1']['delta']:+.2f} points in S1 ({pfmt(pd_['S1']['p'])}), {pd_['S2']['delta']:+.2f} in S2 and
{pd_['S3']['delta']:+.2f} in S3. That a learned value function and a closed-form counterfactual contrast
converge to similar behaviour once both are aimed at decision correctness supports the paper's thesis more
strongly than a win by either mechanism alone.

{_drl_txt}

The slack in Theorem 1 is small in practice: the measured irreducible post-update error probability p̄^wit
is {main[main.scenario=='S1'].p_with_mean.mean():.3f}, {main[main.scenario=='S2'].p_with_mean.mean():.3f}
and {main[main.scenario=='S3'].p_with_mean.mean():.3f} across the three scenarios, so the additive term in
(12) is dominated by the reconstruction-noise floor of the selected fidelity level rather than by anything
the scheduler controls.
""")

def row(sc, m, df=None):
    d = main if df is None else df
    return [m if not m.startswith('CoFA') else '**' + m + '**',
            f"{M(sc,m,'decision_accuracy',d):.2f}",
            f"{M(sc,m,'critical_accuracy',d):.2f} ± {CI(sc,m,'critical_accuracy',d):.2f}",
            f"{M(sc,m,'restore_le20',d):.1f}",
            f"{M(sc,m,'restore_p99',d):.0f}",
            f"{M(sc,m,'scdd',d):.1f}",
            f"{M(sc,m,'crit_latency_p99',d):.1f}",
            f"{M(sc,m,'cfs',d):.4f}",
            f"{M(sc,m,'aoc_mean',d):.4f}",
            f"{M(sc,m,'aoi_mean',d):.0f}",
            f"{M(sc,m,'uplink_mbps',d):.2f}",
            f"{M(sc,m,'energy_mj',d):.1f}",
            f"{M(sc,m,'critical_accuracy',d)/M(sc,m,'uplink_mbps',d):.1f}"]


COLS = ['Policy', 'Acc. [%]', 'Critical acc. [%]', 'Restored ≤20 ms [%]',
        'Restore p99 [ms]', 'SCD [%]', 'Crit. p99 [ms]', 'CFS', 'AoC',
        'AoI [ms]', 'Uplink [Mb/s]', 'Energy [mJ]', 'DE']
WID = [1.35, .62, 1.1, .78, .72, .55, .68, .72, .72, .62, .78, .68, .5]
NAMES = {'S1': 'S1 - dense immersive collaboration',
         'S2': 'S2 - high-mobility, safety-critical uplink synchronization',
         'S3': 'S3 - non-linear XR head-pose context with a neural decision head'}
_KEY = ('Mean over 20 seeds under common random numbers; ± is the 95% confidence '
        'half-width. SCD = successful critical delivery within the 20 ms deadline, '
        'erased updates counted as failures; AoI from the last applied update; '
        'DE = critical-instant accuracy per Mb/s, computed from the unrounded means '
        'rather than from the printed columns. The AoC column is a diagnostic and '
        'not a common yardstick: AoC accumulates the policy\'s own decision '
        'inconsistency (11), so it is measured in different units from AoI and its '
        'value is only comparable between policies that share a decision model. It '
        'is reported because it is the quantity Theorem 1 bounds, not as a metric '
        'on which the policies are being ranked.')
for i, sc in enumerate(SCEN):
    add('table', span=2, label=f'Table {["IV","V","VI"][i]}',
        caption=(f'Main comparison, scenario {NAMES[sc]}. '
                 + (_KEY if i == 0 else 'Columns and conventions as in Table IV.')),
        cols=COLS, widths=WID, rows=[row(sc, m) for m in ORDER])

# --- pre-specified confirmatory family and multiple-comparison control -----
def _paired(a, b, sc, col='critical_accuracy', df=None):
    d = main if df is None else df
    A = d[(d.scenario == sc) & (d.method == a)].sort_values('seed')[col].values
    B = d[(d.scenario == sc) & (d.method == b)].sort_values('seed')[col].values
    n = min(len(A), len(B))
    return stats.ttest_rel(A[:n], B[:n]).pvalue, float((A[:n] - B[:n]).mean())


_ablh = pd.read_csv(os.path.join(RES, 'e6_ablation.csv'))


def _paired_abl(v, sc, col='critical_accuracy'):
    A = _ablh[(_ablh.scenario == sc) & (_ablh.variant == 'CoFA (full)')].sort_values('seed')[col].values
    B = _ablh[(_ablh.scenario == sc) & (_ablh.variant == v)].sort_values('seed')[col].values
    n = min(len(A), len(B))
    return stats.ttest_rel(A[:n], B[:n]).pvalue, float((A[:n] - B[:n]).mean())


HYP = []
for _sc in ('S1', 'S2', 'S3'):
    HYP.append((f'CoFA vs AoI-Aware ({_sc})',) + _paired('CoFA', 'AoI-Aware', _sc))
for _sc in ('S1', 'S2', 'S3'):
    HYP.append((f'DRL-CF vs DRL (DQN) ({_sc})',) + _paired('DRL-CF', 'DRL (DQN)', _sc))
for _sc in ('S1', 'S2', 'S3'):
    HYP.append((f'CoFA vs Goal-Oriented ({_sc})',) + _paired('CoFA', 'Goal-Oriented', _sc))
for _sc in ('S1', 'S2', 'S3'):
    HYP.append((f'CoFA vs AoII-Aware ({_sc})',) + _paired('CoFA', 'AoII-Aware', _sc))
for _sc in ('S1', 'S2', 'S3'):
    HYP.append((f'gate ablation ({_sc})',) + _paired_abl('w/o causal importance', _sc))
_pv = np.array([h[1] for h in HYP])
_m = len(_pv)
_ordr = np.argsort(_pv)
_holm = np.empty(_m)
_run = 0.0
for _r, _i in enumerate(_ordr):
    _run = max(_run, (_m - _r) * _pv[_i])
    _holm[_i] = min(_run, 1.0)
_bh = np.empty(_m)
_prev = 1.0
for _r in range(_m - 1, -1, -1):
    _i = _ordr[_r]
    _prev = min(_prev, _pv[_i] * _m / (_r + 1))
    _bh[_i] = min(_prev, 1.0)
n_holm = int((_holm < 0.05).sum())
n_bh = int((_bh < 0.05).sum())
n_raw = int((_pv < 0.05).sum())

add('table', span=2, label='Table @CONF',
    caption=('The pre-specified confirmatory family. Delta is the paired mean '
             'difference in critical-instant accuracy in points; p is the raw '
             'paired two-sided t-test; Holm and BH are the family-wise and '
             'false-discovery adjusted values over the fifteen tests.'),
    cols=['Hypothesis', 'Delta [pts]', 'p', 'Holm', 'BH', 'Holm < 0.05'],
    widths=[2.2, 0.85, 0.9, 0.9, 0.9, 0.85],
    rows=[[HYP[i][0], f'{HYP[i][2]:+.2f}',
           ('< 1e-4' if _pv[i] < 1e-4 else f'{_pv[i]:.4f}'),
           ('< 1e-4' if _holm[i] < 1e-4 else f'{_holm[i]:.4f}'),
           ('< 1e-4' if _bh[i] < 1e-4 else f'{_bh[i]:.4f}'),
           ('yes' if _holm[i] < 0.05 else 'no')]
          for i in range(len(HYP))])
md(f"""
*The confirmatory family survives correction.* All fifteen tests are two-sided, so the sign of the paired
mean difference carries the direction and a significant result is not the same as a win: the CoFA against
AoII-Aware comparison in S3 is significant *against* CoFA by {-HYP[11][2]:.2f} points, and is listed as such.
Of the fifteen, {n_raw} are significant at 0.05 uncorrected, {n_holm} remain significant under
Holm-Bonferroni control of the family-wise error rate and {n_bh} under Benjamini-Hochberg control of the
false discovery rate (Table @CONF). Correction therefore changes nothing here, which is what the paired design
and twenty common-random-number seeds were chosen to achieve; it is reported because the study performs many
more comparisons than these fifteen, and a reader is entitled to know which ones the paper is willing to
stand behind.
""")
add('fig', span=2, file='fig3_main_bars.png', label='Fig. 2',
    caption='Main comparison across the three scenarios: critical-instant decision accuracy (left), '
            'uplink traffic on a logarithmic axis (centre) and decisions restored within 20 ms (right). '
            'One marker per scenario; rows ordered by mean accuracy and coloured by family.')
add('fig', span=2, file='fig4_pareto.png', label='Fig. 3',
    caption='Accuracy/traffic plane for all twelve configurations in the three scenarios (logarithmic '
            'traffic axis). Colour carries the family - orange the proposed policy, green the '
            'decision-aware baselines, blue the decision-agnostic ones - and marker shape the '
            'configuration, as the key gives it; bars are seed-paired 95% intervals.')
add('fig', span=1, file='fig5_cdf.png', label='Fig. 4',
    caption='Empirical CDF of the delivery latency of causally critical updates (S1, three seeds '
            'pooled, logarithmic latency axis). All twelve configurations are drawn, coloured by family; '
            'labelled curves carry a leader line and the dashed vertical line marks the 20 ms deadline.')
add('fig', span=1, file='fig2_trace.png', label='Fig. 5',
    caption='Single-user trace (S1). (a) conventional Age of Information; (b) Age of Cognition; '
            '(c) magnitude of the decision-relevant projection error. Illustrative single run rather '
            'than a seed average.')

# ---- B. AoI paradox
add('h2', text='B.  Freshness Is Not Correctness')
md(f"""
The Age-of-Information column of Tables IV-VI is the most informative single row of the study. The
AoI-optimal scheduler holds {M('S1','AoI-Aware','aoi_mean'):.0f} ms in S1 and the periodic edge policy
{M('S1','Edge-Only','aoi_mean'):.0f} ms, while CoFA operates at {M('S1','CoFA','aoi_mean'):.0f} ms - some
{M('S1','CoFA','aoi_mean')/M('S1','AoI-Aware','aoi_mean'):.0f} times staler by the classical measure - and
is nevertheless {pair('S1', b='AoI-Aware')['delta']:+.2f} points more accurate at critical instants and
restores a correct remote decision within 20 ms {M('S1','CoFA','restore_le20') - M('S1','AoI-Aware','restore_le20'):+.1f}
points more often. The same inversion holds in S2 and S3, and it is even more extreme for the AoII-triggered
and decision-centric learned policies, whose Age of Information runs into seconds.

Definition 2 and Theorem 1 explain it: AoI charges for elapsed time, AoC for elapsed *relevance*, and when
the projected state error stays well inside the decision margin, elapsed time accumulates but decision risk
does not, so capacity spent reducing the former buys nothing the application can use. On the same runs
CoFA's Age of Cognition is the lowest of all twelve configurations
({M('S1','CoFA','aoc_mean'):.4f} in S1 against {M('S1','AoI-Aware','aoc_mean'):.4f} for the AoI-optimal
scheduler, which transmits {M('S1','AoI-Aware','uplink_mbps')/M('S1','CoFA','uplink_mbps'):.1f} times more)
while its AoI is {M('S1','CoFA','aoi_mean')/M('S1','AoI-Aware','aoi_mean'):.0f} times that of the
AoI-optimal scheduler and larger than that of every freshness-optimized baseline by more than an order of
magnitude - though not the largest in the table, since the AoII-triggered and decision-centric policies are
staler still; Fig. 5 shows both for one user, the AoI trace rising in long ramps while
the AoC trace stays pinned near zero and resets exactly where the decision-relevant projection error would
otherwise have grown. Two caveats keep this honest: AoC is CoFA's own drift variable and is structurally
bounded by its gate, so that comparison is favourable by construction and the claim rests on the
policy-agnostic accuracy and restoration statistics instead; and the AoI reported here is measured from the
last *applied* update, so adding the mean delivery latency of Tables IV-VI recovers the
generation-referenced definition, with the ordering unaffected.
""")

add('h2', text='C.  The Admission-Limited Regime')
admabl = pd.read_csv(os.path.join(RES, 'e9b_admission_ablation.csv'))
admV = pd.read_csv(os.path.join(RES, 'e10_sens_V_admission.csv'))
admD = pd.read_csv(os.path.join(RES, 'e11_admissionD.csv'))
admDa = pd.read_csv(os.path.join(RES, 'e11b_admissionD_ablation.csv'))
vDs = pd.read_csv(os.path.join(RES, 'e12_sens_V_admissionD.csv'))
bbA = max(BASE, key=lambda k: adm[adm.method == k].critical_accuracy.mean())
bbD = max([m for m in BASE if m in set(admD.method)],
          key=lambda k: admD[admD.method == k].critical_accuracy.mean())
_aA = adm[adm.method == 'CoFA'].sort_values('seed').critical_accuracy.values
_bA = adm[adm.method == bbA].sort_values('seed').critical_accuracy.values
dA = _aA - _bA
tA = stats.ttest_rel(_aA, _bA)
ablfull = admabl[admabl.variant == 'CoFA (full)'].critical_accuracy.mean()
ablaoi = admabl[admabl.variant == 'w/o AoC (AoI instead)'].critical_accuracy.mean()
_aoiv_txt = ''
_ap = os.path.join(RES, 'e16_backlog_v.csv')
if os.path.exists(_ap):
    _ad = pd.read_csv(_ap)
    _ag = _ad.groupby(['backlog', 'p_V']).critical_accuracy.mean()
    _au = _ad.groupby(['backlog', 'p_V']).uplink_mbps.mean()
    _bA, _bI = _ag['AoC'].idxmax(), _ag['AoI'].idxmax()
    _aoiv_txt = (
        "*The two backlog variables, each at its own best weight.* Comparing AoC against AoI at a single V "
        "is not like-for-like: one is a dimensionless accumulated probability and the other is a time, so "
        "the substitution changes the balance of the two terms of (15) as well as the backlog itself. In "
        "S1D, where the ranking binds, V was therefore swept over a factor of 512 separately for each "
        f"backlog and each scored at its own best setting. The AoC backlog peaks at "
        f"{_ag['AoC'].max():.2f}% critical-instant accuracy at V = {_bA:g} and the AoI backlog at "
        f"{_ag['AoI'].max():.2f}% at V = {_bI:g}, so the best-against-best difference is "
        f"{_ag['AoC'].max() - _ag['AoI'].max():+.2f} points - against "
        f"{_ag['AoC'][2.0] - _ag['AoI'][2.0]:+.2f} points at the common nominal V = 2, which is what the "
        "single-weight ablation row reports. The objection was well taken and the corrected number is the "
        "one to quote. What the sweep shows is that the AoI backlog simply needs a much larger weight to "
        "compensate for its units, and once it has one the two are within noise of each other: the "
        "contribution of charging for accumulated relevance rather than for elapsed time lies in the gate, "
        "where CET enters directly, and in the bound of Theorem 1 - not in the scheduling index. That "
        "strengthens rather than weakens the contribution hierarchy of Section VII-G, and it is another "
        "reason the drift-plus-penalty layer is presented as rationale rather than as a pillar.")
vlo, vhi = admV.p_V.min(), admV.p_V.max()
vspan = (admV[admV.p_V == vhi].critical_accuracy.mean()
         - admV[admV.p_V == vlo].critical_accuracy.mean())
aocD = (admDa[admDa.variant == 'CoFA (full)'].critical_accuracy.mean()
        - admDa[admDa.variant == 'w/o AoC (AoI instead)'].critical_accuracy.mean())
aocDr = (admDa[admDa.variant == 'CoFA (full)'].restore_le20.mean()
         - admDa[admDa.variant == 'w/o AoC (AoI instead)'].restore_le20.mean())
vg = vDs.groupby('p_V')[['critical_accuracy', 'restore_le20']].mean()

# --- the claim CET is actually left with, tested where the budget binds -----
_bm_txt, _bm_rows = '', []
_bp = os.path.join(RES, 'e19_budget_match.csv')
if os.path.exists(_bp):
    _bd = pd.read_csv(_bp)
    _bg = (_bd.groupby(['policy', 'thresh'])[['critical_accuracy', 'uplink_mbps']]
           .mean().reset_index())
    _cv = {p: g.sort_values('uplink_mbps') for p, g in _bg.groupby('policy')}
    _lo = max(float(g.uplink_mbps.min()) for g in _cv.values())
    _hi = min(float(g.uplink_mbps.max()) for g in _cv.values())
    _bud = np.linspace(_lo, _hi, 5)

    def _at(p, b):
        g = _cv[p]
        return float(np.interp(b, g.uplink_mbps.values,
                               g.critical_accuracy.values))

    _bm_rows = [[f'{b:.1f}', f'{_at("CoFA", b):.2f}',
                 f'{_at("Goal-Oriented", b):.2f}',
                 f'{_at("CoFA", b) - _at("Goal-Oriented", b):+.2f}']
                for b in _bud]
    _dmax = max(_bud, key=lambda b: _at('CoFA', b) - _at('Goal-Oriented', b))
    _dmean = float(np.mean([_at('CoFA', b) - _at('Goal-Oriented', b)
                            for b in _bud]))
    _bm_txt = (
        "*What the counterfactual framing is actually worth, measured where a value is needed.* "
        "Section VII-K reports that as an instantaneous *detector* of updates that matter, the "
        "present-risk signal of the goal-oriented baseline separates them better than CET does. The claim "
        "CET is left with is different in kind: it is an additive transmission *value* on a common scale, "
        "and a value - rather than a per-user alarm - is what a scheduler needs when it must choose which "
        "of several competing users to serve. That claim is empty wherever everything the gate admits can "
        "also be served, which is why it is tested in S1D and nowhere else. Each policy was swept over the "
        "threshold that sets how much it transmits, which moves it along its own accuracy/traffic curve, "
        "and the two curves are then read at the *same uplink volume* rather than at the same threshold; "
        "both use the same decision model, the same fidelity rule and the same scheduler, and differ only "
        "in the quantity that ranks users. Over the overlapping budget range "
        f"{_lo:.1f}-{_hi:.1f} Mb/s the counterfactual ranking is worth {_dmean:+.2f} points of "
        f"critical-instant accuracy on average and {_at('CoFA', _dmax) - _at('Goal-Oriented', _dmax):+.2f} "
        f"points at its best, at {_dmax:.1f} Mb/s (Table @BUD). The effect is small and it is the honest "
        "size of this contribution: the gate is what carries the accuracy, and the contrast earns its place "
        "over an absolute risk in the ranking, not in the detection.")

md(f"""
Two notes before the numbers. The S1C comparison uses 20 seeds and the S1D comparison 12, so the two are
not directly comparable at the second decimal place; and the learned baselines run here with networks
trained on S1, i.e. out of distribution, which is flagged rather than retrained because the point of these
regimes is the behaviour of the scheduling constraint rather than a learned-policy comparison. For the same
reason the S1D comparison reports a representative subset rather than all twelve configurations.

Section V-B noted that the drift-plus-penalty ranking is exercised only when the causal gate admits more
users than a cell can serve. Two configurations test that: S1C (160 users, 60 MHz, at most three concurrent
uplink users per cell) and S1D (200 users, 40 MHz, at most one concurrent user per cell), the second
constructed so that the demand the gate admits exceeds the service capacity. Fig. 6 reports S1C and
Table VII reports S1D.

The ordering of the policies is preserved, and the margin over the decision-agnostic family widens
sharply, although the margin over the strongest decision-aware baseline does not. In S1C CoFA reaches
{adm[adm.method=='CoFA'].critical_accuracy.mean():.2f}% against
{adm[adm.method==bbA].critical_accuracy.mean():.2f}% for the strongest baseline ({bbA}),
{dA.mean():+.2f} points ({pfmt(tA.pvalue)}); in S1D it reaches
{admD[admD.method=='CoFA'].critical_accuracy.mean():.2f}% against
{admD[admD.method==bbD].critical_accuracy.mean():.2f}% for {bbD}. In both the AoI-optimal scheduler
collapses - to {adm[adm.method=='AoI-Aware'].critical_accuracy.mean():.2f}% and
{admD[admD.method=='AoI-Aware'].critical_accuracy.mean():.2f}% respectively, below the plain periodic edge
policy - because age-based prioritization cannot choose which of the rejected updates mattered. The gap in
critical-update tail latency becomes extreme in S1D: {admD[admD.method=='CoFA'].crit_latency_p99.mean():.1f} ms
for CoFA against {admD[admD.method==bbD].crit_latency_p99.mean():.1f} ms for the strongest baseline, because
under a single-user service budget the order in which the queue is served is the only thing left to optimize.

That is also where the two mechanisms that are inert at nominal load finally appear. In S1C the effects are
still negligible ({ablfull - ablaoi:+.2f} points for the AoC backlog, {vspan:+.2f} points across a factor of
{vhi/vlo:.0f} in V), and that null result is reported rather than hidden. In S1D, where the constraint
genuinely binds, replacing the AoC backlog by an AoI backlog costs {aocD:.2f} points of critical-instant
accuracy and {aocDr:.1f} points of decisions restored within 20 ms, and sweeping V over a factor of
{vDs.p_V.max()/vDs.p_V.min():.0f} moves accuracy from {vg.critical_accuracy.iloc[0]:.2f}% to
{vg.critical_accuracy.iloc[-1]:.2f}% and restoration from {vg.restore_le20.iloc[0]:.1f}% to
{vg.restore_le20.iloc[-1]:.1f}%, in the direction Theorem 2 predicts, though not strictly monotonically. The honest summary is that the ranking
term is a second-order refinement worth about a point of accuracy in a severely admission-limited cell and
nothing at all when capacity is comfortable, whereas the gate carries the first-order effect everywhere.


{_bm_txt}

{_aoiv_txt}
""")
if _bm_rows:
    add('table', label='Table @BUD',
        caption='Counterfactual value against present risk at a matched uplink budget, scenario S1D, '
                '12 seeds. Each policy is swept over its own trigger threshold and the two curves are '
                'read at the same uplink volume.',
        cols=['Uplink [Mb/s]', 'CoFA crit. [%]', 'Goal-Oriented crit. [%]', 'Delta [pts]'],
        widths=[1.1, 1.2, 1.5, .9], rows=_bm_rows)
SUBD = [m for m in ORDER if m in set(admD.method)]
add('table', span=2, label='Table VII',
    caption='Severely admission-limited regime S1D (200 users, 40 MHz per cell, one concurrent uplink '
            'user per cell). 12 seeds for the comparison and the ablation, 10 for the V sweep.',
    cols=['Policy / variant', 'Critical acc. [%]', 'Restored <=20 ms [%]', 'SCD [%]',
          'Crit. p99 [ms]', 'Uplink [Mb/s]'],
    widths=[2.2, 1.15, 1.15, .85, .95, 1.0],
    rows=[[m if not m.startswith('CoFA') else '**' + m + '**',
           f"{admD[admD.method==m].critical_accuracy.mean():.2f}",
           f"{admD[admD.method==m].restore_le20.mean():.1f}",
           f"{admD[admD.method==m].scdd.mean():.1f}",
           f"{admD[admD.method==m].crit_latency_p99.mean():.1f}",
           f"{admD[admD.method==m].uplink_mbps.mean():.1f}"] for m in SUBD]
         + [[('ablation: ' + v),
             f"{admDa[admDa.variant==v].critical_accuracy.mean():.2f}",
             f"{admDa[admDa.variant==v].restore_le20.mean():.1f}",
             f"{admDa[admDa.variant==v].scdd.mean():.1f}",
             f"{admDa[admDa.variant==v].crit_latency_p99.mean():.1f}",
             f"{admDa[admDa.variant==v].uplink_mbps.mean():.1f}"]
            for v in ['w/o AoC (AoI instead)', 'w/o causal importance',
                      'w/o predictive migration']]
         + [[f'V = {v:g}',
             f"{vDs[vDs.p_V==v].critical_accuracy.mean():.2f}",
             f"{vDs[vDs.p_V==v].restore_le20.mean():.1f}",
             f"{vDs[vDs.p_V==v].scdd.mean():.1f}",
             f"{vDs[vDs.p_V==v].crit_latency_p99.mean():.1f}",
             f"{vDs[vDs.p_V==v].uplink_mbps.mean():.1f}"]
            for v in sorted(vDs.p_V.unique())])
add('fig', span=2, file='fig10_admission.png', label='Fig. 6',
    caption='Admission-limited regime S1C (160 users, 60 MHz, at most three concurrent uplink users per '
            'cell). (a) critical-instant accuracy, ordered by value and coloured by family. '
            '(b) sensitivity to the weight V, on an axis one accuracy point wide. (c) component '
            'ablation, as the seed-paired change from the full system.')

def sw(fn):
    return pd.read_csv(os.path.join(RES, fn))


def sv(df, m, x, col, xv):
    return df[(df.method == m) & (df[x] == xv)][col].mean()


# ---- D. load
d2 = sw('e2_load.csv'); xs2 = sorted(d2.p_n_users.unique())
add('h2', text='D.  Scalability with Offered Load')
md(f"""
Fig. 7 sweeps the number of concurrent users in S1 from {int(xs2[0])} to {int(xs2[-1])} at fixed spectrum.
The periodic and freshness-driven baselines are capacity-limited: the AoI-optimal scheduler's uplink demand
saturates near {max(sv(d2,'AoI-Aware','p_n_users','uplink_mbps',x) for x in xs2):.0f} Mb/s, its
critical-instant accuracy falls from {sv(d2,'AoI-Aware','p_n_users','critical_accuracy',xs2[0]):.2f}% to
{sv(d2,'AoI-Aware','p_n_users','critical_accuracy',xs2[-1]):.2f}%, and the fraction of transitions restored
within 20 ms falls from {sv(d2,'AoI-Aware','p_n_users','restore_le20',xs2[0]):.1f}% to
{sv(d2,'AoI-Aware','p_n_users','restore_le20',xs2[-1]):.1f}%. CoFA-E is essentially flat:
{sv(d2,'CoFA-E','p_n_users','critical_accuracy',xs2[0]):.2f}% at {int(xs2[0])} users and
{sv(d2,'CoFA-E','p_n_users','critical_accuracy',xs2[-1]):.2f}% at {int(xs2[-1])}, with uplink rising only to
{sv(d2,'CoFA-E','p_n_users','uplink_mbps',xs2[-1]):.1f} Mb/s. Measured against whichever baseline is strongest at each load, the gap is
{sv(d2,'CoFA-E','p_n_users','critical_accuracy',xs2[0]) - max(sv(d2,b,'p_n_users','critical_accuracy',xs2[0]) for b in BASE):+.2f}
at {int(xs2[0])} users and
{sv(d2,'CoFA-E','p_n_users','critical_accuracy',xs2[-1]) - max(sv(d2,b,'p_n_users','critical_accuracy',xs2[-1]) for b in BASE):+.2f}
points at {int(xs2[-1])}. When the budget binds, prioritizing by causal effect is worth strictly more than prioritizing by
age.
""")
add('fig', span=2, file='fig6_load.png', label='Fig. 7',
    caption='Scalability with offered load (S1). The sweeps plot a representative subset of the twelve '
            'configurations; all twelve appear in Tables IV-VI. Colour carries the family, dash pattern '
            'the configuration; traffic is logarithmic and intervals are seed-paired.')

# ---- E. mobility
d3 = sw('e3_mobility.csv'); xs3 = sorted(d3.p_v_max.unique())
add('h2', text='E.  Robustness to Mobility')
md(f"""
Fig. 8 shifts the S2 speed band so that the maximum speed rises from {int(xs3[0])} to {int(xs3[-1])} m/s.
Handovers grow from {sv(d3,'Edge-Only','p_v_max','handovers',xs3[0]):.1f} to
{sv(d3,'Edge-Only','p_v_max','handovers',xs3[-1]):.1f} per second for every policy, but the consequences
differ. For the reactive baselines each handover is followed by a cold state migration - for the periodic and
age-based policies the measured cold-migration rate tracks the handover rate almost exactly,
{sv(d3,'Edge-Only','p_v_max','migrations',xs3[-1]):.1f} per second at {int(xs3[-1])} m/s, and it is lower for the policies that place no state at an edge or transmit rarely - whereas CoFA's predictive pre-replication holds it below
{max(sv(d3,'CoFA','p_v_max','migrations',x) for x in xs3):.2f} per second, a reduction of about
{max(sv(d3,'Edge-Only','p_v_max','migrations',x) for x in xs3)/max(sv(d3,'CoFA','p_v_max','migrations',x) for x in xs3):.0f}x, at the cost of {max(sv(d3,'CoFA','p_v_max','prewarm_mbps',x) for x in xs3):.2f} Mb/s of background
inter-edge traffic at the fastest point of the sweep. Critical-instant accuracy varies only between
{min(sv(d3,'CoFA','p_v_max','critical_accuracy',x) for x in xs3):.2f}% and
{max(sv(d3,'CoFA','p_v_max','critical_accuracy',x) for x in xs3):.2f}% for CoFA and between
{min(sv(d3,'CoFA-E','p_v_max','critical_accuracy',x) for x in xs3):.2f}% and
{max(sv(d3,'CoFA-E','p_v_max','critical_accuracy',x) for x in xs3):.2f}% for CoFA-E across the whole range.
""")
add('fig', span=2, file='fig7_mobility.png', label='Fig. 8',
    caption='Robustness to mobility (S2).')

# ---- F. loss + bandwidth
d4 = sw('e4_loss.csv'); xs4 = sorted(d4.p_p_loss_base.unique())
d5 = sw('e5_bandwidth.csv'); xs5 = sorted(d5.p_bw_bs.unique())
add('h2', text='F.  Link Unreliability and Spectrum Scarcity')
md(f"""
Fig. 9 sweeps the residual erasure rate from {xs4[0]:.0%} to {xs4[-1]:.0%}. Because the reliability metric
now counts an erased critical update as a failure, the degradation is visible: the successful-critical-delivery
rate of the periodic edge policy falls from {sv(d4,'Edge-Only','p_p_loss_base','scdd',xs4[0]):.1f}% to
{sv(d4,'Edge-Only','p_p_loss_base','scdd',xs4[-1]):.1f}%, and CoFA's from
{sv(d4,'CoFA','p_p_loss_base','scdd',xs4[0]):.1f}% to {sv(d4,'CoFA','p_p_loss_base','scdd',xs4[-1]):.1f}%.
CoFA's advantage over the AoI-optimal scheduler is preserved but does not widen
({sv(d4,'CoFA','p_p_loss_base','critical_accuracy',xs4[0]) - sv(d4,'AoI-Aware','p_p_loss_base','critical_accuracy',xs4[0]):+.2f}
points at zero erasure, {sv(d4,'CoFA','p_p_loss_base','critical_accuracy',xs4[-1]) - sv(d4,'AoI-Aware','p_p_loss_base','critical_accuracy',xs4[-1]):+.2f}
at {xs4[-1]:.0%}), while its advantage over the strongest decision-aware baseline does widen, from
{sv(d4,'CoFA','p_p_loss_base','critical_accuracy',xs4[0]) - sv(d4,'AoII-Aware','p_p_loss_base','critical_accuracy',xs4[0]):+.2f}
to {sv(d4,'CoFA','p_p_loss_base','critical_accuracy',xs4[-1]) - sv(d4,'AoII-Aware','p_p_loss_base','critical_accuracy',xs4[-1]):+.2f}
points. Reliability is not the dimension along which decision-centric orchestration pays off most, but the
ordering is stable under it.

Spectrum scarcity is. Fig. 10 reduces the per-cell bandwidth from {xs5[-1]/1e6:.0f} MHz to
{xs5[0]/1e6:.0f} MHz with the concurrency limit scaled with bandwidth and floored at three. The AoI-optimal
scheduler loses {sv(d5,'AoI-Aware','p_bw_bs','critical_accuracy',xs5[-1]) - sv(d5,'AoI-Aware','p_bw_bs','critical_accuracy',xs5[0]):.2f}
points as its demand collapses from {sv(d5,'AoI-Aware','p_bw_bs','uplink_mbps',xs5[-1]):.0f} to
{sv(d5,'AoI-Aware','p_bw_bs','uplink_mbps',xs5[0]):.0f} Mb/s, whereas CoFA-E loses
{sv(d5,'CoFA-E','p_bw_bs','critical_accuracy',xs5[-1]) - sv(d5,'CoFA-E','p_bw_bs','critical_accuracy',xs5[0]):.2f}
points. At the scarcest point CoFA-E still attains {sv(d5,'CoFA-E','p_bw_bs','critical_accuracy',xs5[0]):.2f}%
with {sv(d5,'CoFA-E','p_bw_bs','uplink_mbps',xs5[0]):.1f} Mb/s - higher than any network-centric baseline
achieves at {xs5[-1]/1e6:.0f} MHz, i.e. decision-centric gating buys back at least the factor of
{xs5[-1]/xs5[0]:.0f} that this sweep spans.
""")
add('fig', span=2, file='fig8_loss.png', label='Fig. 9',
    caption='Sensitivity to residual packet erasure (S1); erased critical updates count as delivery failures.')
add('fig', span=2, file='fig9_bandwidth.png', label='Fig. 10',
    caption='Sensitivity to spectrum scarcity (S1).')

# ---- G. ablation
abl = pd.read_csv(os.path.join(RES, 'e6_ablation.csv'))


def AB(sc, v, col):
    return abl[(abl.scenario == sc) & (abl.variant == v)][col].mean()


_cold_txt = ''
_cp = os.path.join(RES, 'e20_cold_mig.csv')
if os.path.exists(_cp):
    _cm = pd.read_csv(_cp)
    _cmg = _cm.groupby(['scenario', 'variant'])
    _sil = float(_cmg.cold_age_median_slots.mean()[('S2', 'CoFA (full)')])
    _cold_txt = (
        "*One column of Table VIII is not monotone in policy quality, and it is instructive.* Opening the "
        "gate removes cold migrations in S2 entirely, from "
        f"{AB('S2','CoFA (full)','migrations'):.2f} per second to "
        f"{AB('S2','w/o causal importance','migrations'):.2f}, which looks like an improvement and is not "
        "one. A cold migration is charged only when an update arrives at an edge node that is neither the "
        "user's current host nor a node pre-warmed for it, and the pre-warm is issued on a received-power "
        "trend well before the handover fires; a user that transmits anywhere inside that window is always "
        "pre-warmed. The only cold migrations are therefore suffered by users that stayed silent across a "
        "whole handover episode and then transmitted - at the moment of a cold migration the median elapsed "
        f"silence is {_sil*10:.0f} ms in S2, against a mean inter-update interval of "
        f"{1000/AB('S2','CoFA (full)','update_rate'):.0f} ms. Suppression is what creates that silence, so "
        f"the {AB('S2','CoFA (full)','migrations'):.2f} per second is the price of the traffic saving rather "
        "than a failure of predictive migration, and a policy that transmits "
        f"{AB('S2','w/o causal importance','uplink_mbps')/AB('S2','CoFA (full)','uplink_mbps'):.0f} times as "
        "much buys the zero by never being silent - while losing "
        f"{AB('S2','CoFA (full)','critical_accuracy') - AB('S2','w/o causal importance','critical_accuracy'):.2f} "
        "points of critical-instant accuracy and multiplying the critical tail latency by "
        f"{AB('S2','w/o causal importance','crit_latency_p99')/AB('S2','CoFA (full)','crit_latency_p99'):.1f}. "
        "The mechanism is priced correctly only against the w/o predictive migration row, which holds the "
        f"traffic fixed and raises cold migrations to "
        f"{AB('S2','w/o predictive migration','migrations'):.2f} per second. The design implication is "
        "recorded rather than acted on here: pre-warming is currently requested only for users the gate is "
        "about to serve, and extending it to long-silent users would remove the residual cost without "
        "touching the uplink.")

add('h2', text='G.  Ablation and the Contribution Hierarchy')
md(f"""
Fig. 11 and Table VIII ablate six mechanisms, one at a time, over 20 seeds in each of the three scenarios,
and Fig. 6 (right) repeats the ablation under congestion. The result determines the contribution hierarchy
adopted throughout the paper.

*Causal-semantic gating is the dominant mechanism.* Replacing CET by a constant importance signal leaves the
gate permanently open, so the synchronization agent degenerates into a transmit-whenever-idle policy. It
costs {AB('S1','CoFA (full)','critical_accuracy') - AB('S1','w/o causal importance','critical_accuracy'):.2f}
points of critical-instant accuracy in S1, {AB('S2','CoFA (full)','critical_accuracy') - AB('S2','w/o causal importance','critical_accuracy'):.2f}
in S2 and {AB('S3','CoFA (full)','critical_accuracy') - AB('S3','w/o causal importance','critical_accuracy'):.2f}
in S3, multiplies uplink traffic by
{AB('S1','w/o causal importance','uplink_mbps')/AB('S1','CoFA (full)','uplink_mbps'):.1f}x and the
99th-percentile critical-update latency by
{AB('S1','w/o causal importance','crit_latency_p99')/AB('S1','CoFA (full)','crit_latency_p99'):.1f}x, and
drops the successful-critical-delivery rate from {AB('S1','CoFA (full)','scdd'):.1f}% to
{AB('S1','w/o causal importance','scdd'):.1f}%. This single mechanism accounts for more than all the others
combined, which is why the paper is organized around it. The comparison isolates the value of *gating*;
gating *by the counterfactual contrast specifically* is priced instead by the CoFA-vs-Goal-Oriented and
CoFA-vs-AoII comparisons of Section VII-A, which are smaller but consistently positive except in S3.

*Predictive migration protects the tail.* Removing it barely moves mean accuracy but raises the cold-migration
rate from {AB('S2','CoFA (full)','migrations'):.2f} to {AB('S2','w/o predictive migration','migrations'):.1f}
per second in the high-mobility scenario, the critical-update tail latency from
{AB('S2','CoFA (full)','crit_latency_p99'):.1f} ms to {AB('S2','w/o predictive migration','crit_latency_p99'):.1f} ms,
and the fraction of decisions restored within 20 ms falls by
{AB('S2','CoFA (full)','restore_le20') - AB('S2','w/o predictive migration','restore_le20'):.1f} points.

{_cold_txt}

*Adaptive fidelity level is a pure efficiency mechanism.* Forcing every update to maximum fidelity changes
accuracy by
{AB('S1','w/o adaptive fidelity level','critical_accuracy') - AB('S1','CoFA (full)','critical_accuracy'):+.2f}
points at nominal load and
{admabl[admabl.variant == 'w/o adaptive fidelity level'].critical_accuracy.mean() - admabl[admabl.variant == 'CoFA (full)'].critical_accuracy.mean():+.2f}
under congestion, at a cost of
{100*(AB('S1','w/o adaptive fidelity level','uplink_mbps')/AB('S1','CoFA (full)','uplink_mbps')-1):.0f}% more
uplink traffic: it buys bandwidth at a small and roughly constant accuracy cost rather than trading with
load.

*The backlog term, the placement agent and the meta agent are second-order.* At nominal load, replacing the
AoC backlog by an AoI backlog or disabling the placement agent changes nothing measurable, because the gate
already admits fewer users than a cell can serve; Section VII-C measures both under congestion, where they
become visible but remain small. The meta agent is not visible in a single-configuration ablation at all,
because its purpose is to *move* the operating point: its effect is the CoFA/CoFA-E separation reported
throughout.
""")

VARS = ['CoFA (full)', 'w/o causal importance', 'w/o AoC (AoI instead)',
        'w/o predictive migration', 'w/o adaptive fidelity level',
        'w/o placement agent', 'w/o adaptive meta-agent']
add('table', span=2, label='Table VIII',
    caption='Component ablation, mean over 20 seeds per scenario. The congested column is scenario S1C '
            '(12 seeds).',
    cols=['Variant', 'S1 crit. [%]', 'S1 uplink', 'S1 crit. p99', 'S1 SCD [%]',
          'S2 crit. [%]', 'S2 cold mig.', 'S3 crit. [%]', 'S1C crit. [%]'],
    widths=[1.85, .9, .8, .85, .8, .9, .9, .9, .95],
    rows=[[('**' + v + '**') if v == 'CoFA (full)' else v,
           f"{AB('S1',v,'critical_accuracy'):.2f}", f"{AB('S1',v,'uplink_mbps'):.1f}",
           f"{AB('S1',v,'crit_latency_p99'):.1f}", f"{AB('S1',v,'scdd'):.1f}",
           f"{AB('S2',v,'critical_accuracy'):.2f}", f"{AB('S2',v,'migrations'):.2f}",
           f"{AB('S3',v,'critical_accuracy'):.2f}",
           (f"{admabl[admabl.variant == v].critical_accuracy.mean():.2f}"
            if v in set(admabl.variant) else '-')] for v in VARS])
add('fig', span=2, file='fig11_ablation.png', label='Fig. 11',
    caption='Component ablation in the three scenarios, as the seed-paired change from the full system: '
            'critical-instant accuracy in points (left) and uplink traffic in per cent (right). The '
            'horizontal scale is linear through zero and logarithmic outside it.')

# ---- H. sensitivity
sV = sw('e7a_sens_V.csv'); sT = sw('e7b_sens_theta.csv')
sE = sw('e7c_sens_eta.csv'); sF = sw('e7d_sens_target.csv')


def SS(df, xc, x, col):
    return df[df[xc] == x][col].mean()


eta_lo, eta_hi = sorted(sE.p_eta_floor.unique())[0], sorted(sE.p_eta_floor.unique())[-1]
th_lo, th_hi = sorted(sT.p_theta_i.unique())[0], sorted(sT.p_theta_i.unique())[-1]
f_lo, f_hi = sorted(sF.p_cfs_target.unique())[0], sorted(sF.p_cfs_target.unique())[-1]
add('h2', text='H.  Sensitivity to the Framework Parameters')
md(f"""
Fig. 12 sweeps the four scalars of the orchestrator in S1 with within-seed confidence intervals.

The fidelity floor η is the dominant knob. Raising it from {eta_lo:.2f} to {eta_hi:.2f} reduces uplink
traffic from {SS(sE,'p_eta_floor',eta_lo,'uplink_mbps'):.1f} to
{SS(sE,'p_eta_floor',eta_hi,'uplink_mbps'):.1f} Mb/s and device energy from
{SS(sE,'p_eta_floor',eta_lo,'energy_mj'):.1f} to {SS(sE,'p_eta_floor',eta_hi,'energy_mj'):.1f} mJ per user
per second, while critical-instant accuracy moves from
{SS(sE,'p_eta_floor',eta_lo,'critical_accuracy'):.2f}% to
{SS(sE,'p_eta_floor',eta_hi,'critical_accuracy'):.2f}%. That accuracy does not fall as the system transmits
less is the mechanism of the paper in one curve: withholding what does not matter leaves the cell
uncongested and delivers what does matter faster.

The importance gate θ is benign: varying it over a factor of {th_hi/th_lo:.0f} moves accuracy by only
{abs(SS(sT,'p_theta_i',th_hi,'critical_accuracy') - SS(sT,'p_theta_i',th_lo,'critical_accuracy')):.2f} points.
The drift-plus-penalty weight V is inert at nominal load for the structural reason given in Section V-B and
becomes weakly active only in the admission-limited regime (Section VII-C). The meta target φ behaves as an
operating-point selector over most of its range: raising it from {f_lo:.3f} to
{sorted(sF.p_cfs_target.unique())[-2]:.3f} moves uplink traffic from
{SS(sF,'p_cfs_target',f_lo,'uplink_mbps'):.1f} to {SS(sF,'p_cfs_target',sorted(sF.p_cfs_target.unique())[-2],'uplink_mbps'):.1f} Mb/s
and CFS from {SS(sF,'p_cfs_target',f_lo,'cfs'):.4f} to
{SS(sF,'p_cfs_target',sorted(sF.p_cfs_target.unique())[-2],'cfs'):.4f}, while critical-instant accuracy stays
within {max(SS(sF,'p_cfs_target',x,'critical_accuracy') for x in sorted(sF.p_cfs_target.unique())) - min(SS(sF,'p_cfs_target',x,'critical_accuracy') for x in sorted(sF.p_cfs_target.unique())):.2f}
points across the whole sweep. The relationship is not monotone at the very top: at φ = {f_hi:.3f} the
controller chases a target it cannot reach, spending {SS(sF,'p_cfs_target',f_hi,'uplink_mbps'):.0f} Mb/s to
obtain a *lower* CFS ({SS(sF,'p_cfs_target',f_hi,'cfs'):.4f}) than at
{sorted(sF.p_cfs_target.unique())[-2]:.3f}, because the extra traffic congests the cell. An operator should
therefore treat φ as a knob with a useful range rather than a monotone dial, and the two operating points
reported in this paper both lie inside it.
""")
add('fig', span=2, file='fig12_sensitivity.png', label='Fig. 12',
    caption='Sensitivity of CoFA to its four scalar parameters in S1: (a) weight V, (b) importance gate '
            'theta, (c) fidelity floor eta, (d) meta target phi. Top row critical-instant accuracy, '
            'bottom row the uplink traffic it costs, on shared scales; intervals are within-seed '
            '(Cousineau-Morey) 95% intervals. In (d) every second tick is labelled, the levels being '
            'too closely spaced to label all seven.')

# ---- I. robustness
rob = sw('e8_robustness.csv')
ws = sorted(rob.p_w_err_deg.unique())
rr = lambda m, w, c: rob[(rob.method == m) & (rob.p_w_err_deg == w)][c].mean()
add('h2', text='I.  Robustness to an Imperfect Decision Model')
md(f"""
CoFA and the goal-oriented baseline both assume the orchestrator knows the decision geometry. The
estimate of the causal direction is rotated away from the truth by up to {int(ws[-1])} degrees while leaving the
ground-truth decision process - and hence the evaluation metric - untouched. Fig. 13 reports the outcome.
CoFA's critical-instant accuracy falls from {rr('CoFA', ws[0], 'critical_accuracy'):.2f}% to
{rr('CoFA', ws[-1], 'critical_accuracy'):.2f}%, a loss of
{rr('CoFA', ws[0],'critical_accuracy') - rr('CoFA', ws[-1],'critical_accuracy'):.2f} points, which still
leaves it {rr('CoFA', ws[-1],'critical_accuracy') - rob[rob.method=='AoI-Aware'].critical_accuracy.mean():+.2f}
points above the AoI-optimal scheduler; the goal-oriented baseline, which uses the same perturbed direction in its risk estimator, is almost
unaffected in accuracy - its trigger is dominated by the exact decision-inconsistency clause it shares with
CoFA, so only its traffic responds, and then only weakly ({rr('Goal-Oriented', ws[0],'uplink_mbps'):.1f} to
{rr('Goal-Oriented', ws[-1],'uplink_mbps'):.1f} Mb/s against {rr('CoFA', ws[0],'uplink_mbps'):.1f} to
{rr('CoFA', ws[-1],'uplink_mbps'):.1f} Mb/s for CoFA); policies that use no decision model are flat by
construction. As the estimate degrades the gate fires more often and uplink traffic rises from
{rr('CoFA', ws[0],'uplink_mbps'):.1f} to {rr('CoFA', ws[-1],'uplink_mbps'):.1f} Mb/s: the framework spends
bandwidth to compensate for its own uncertainty rather than failing outright. One caveat bounds the result. The perturbation is applied to the direction used by the importance
estimators only; the decision-inconsistency clause of (14), the margin used for fidelity-level selection and
the representational-fidelity floor all continue to use the exact decision rule. What the experiment
measures is therefore the cost of a mis-specified *predictive* signal with the reactive component held
exact, which is a lower bound on the cost of a fully mis-specified decision model. Scenario S3, where the
head is non-linear and the dynamics are known only through a surrogate identified from a two-second
calibration window, is the more complete stress test.
""")
add('fig', span=2, file='fig13_robustness.png', label='Fig. 13',
    caption='Robustness to an imperfect decision model (S1). The perturbation applies to the direction '
            'used by the importance estimators only, so the AoI-optimal and AoII-triggered schedulers are '
            'flat by construction. Intervals are within-seed 95% intervals.')

# ---- J. DRL convergence
try:
    dq = sw('e0_dqn_convergence.csv')
    fin = dq.dropna(subset=['eval_critical_accuracy']).groupby(['scenario', 'variant']).last()
    add('h2', text='J.  Convergence of the Learned Baselines')
    _ds = os.path.join(RES, 'e15_drl_seeds.csv')
    _seed_txt = ''
    if os.path.exists(_ds):
        _e = pd.read_csv(_ds)
        _e['tag'] = _e.variant.str.split('|').str[0]
        _e['ts'] = _e.variant.str.split('|').str[1]
        _g = _e.groupby(['scenario', 'tag', 'ts']).critical_accuracy.mean()
        _lo = _g.groupby(level=[0, 1]).min()
        _hi = _g.groupby(level=[0, 1]).max()
        _sep = [sc for sc in ('S1', 'S2', 'S3')
                if _lo[(sc, 'DRL-CF')] > _hi[(sc, 'DRL (DQN)')]]
        _nsep = [sc for sc in ('S1', 'S2', 'S3') if sc not in _sep]
        _up = _e.groupby(['scenario', 'tag', 'ts']).uplink_mbps.mean()
        _worst = _g['S1']['DRL-CF'].idxmin() if 'S1' in _nsep else None
        _fail = ''
        if _worst is not None:
            _fail = (
                f" The exception is one training seed of the decision-centric policy in S1, which converged "
                f"to a degenerate optimum: it transmits {_up[('S1','DRL-CF',_worst)]:.2f} Mb/s - effectively "
                f"nothing - and scores {_g[('S1','DRL-CF',_worst)]:.2f}%, below every seed of the "
                f"network-centric policy. A reward that charges only for an incorrect remote decision admits "
                f"a silent policy as a local optimum whenever most users sit far from the decision boundary, "
                f"and one initialization in three found it. That is a property of the reward shaping rather "
                f"than of the objective, it is why the median-seed rule was fixed in advance rather than "
                f"chosen afterwards, and it is reported here rather than averaged away.")
        _seed_txt = (
            "*The comparison is made over training seeds, not from a single run.* Each policy was trained "
            "three times from independent initializations and every trained network was then evaluated on "
            "all twenty evaluation seeds (Fig. 14c). Training randomness is not negligible: across its three "
            f"seeds the network-centric policy spans {_hi[('S1','DRL (DQN)')] - _lo[('S1','DRL (DQN)')]:.2f} "
            f"points of critical-instant accuracy in S1 and "
            f"{_hi[('S3','DRL (DQN)')] - _lo[('S3','DRL (DQN)')]:.2f} in S3, and the decision-centric one "
            f"{_hi[('S1','DRL-CF')] - _lo[('S1','DRL-CF')]:.2f} and "
            f"{_hi[('S3','DRL-CF')] - _lo[('S3','DRL-CF')]:.2f}, so a single-run comparison would have been "
            "fragile in a way the previous version of this study did not acknowledge. "
            + (f"The separation between the two rewards nevertheless holds seed by seed in "
               f"{' and '.join(_sep)}: the worst decision-centric seed beats the best network-centric seed."
               if _sep else "The two seed ranges overlap in every scenario.")
            + _fail
            + " The network used in Tables IV-VI is the median seed by held-out accuracy in every case, "
              "chosen before the evaluation block was run.")
    md(f"""
Fig. 14 reports the training curves of the two learned policies, each the mean over three independent
training seeds; the spread across those seeds is reported exactly, seed by seed, in panel (c) of the same
figure rather than as a band around the curves. The held-out evaluation used during training is a
*different* protocol from the one behind Tables IV-VI - a single held-out seed over an 8 s episode rather
than 20 common-random-number seeds over 20 s - so its absolute level is not comparable with the tables and
only its trajectory should be read. The training budget in this revision is 140 episodes with a longer
exploration decay, more than twice the previous one, in response to the observation that the network-centric
reward had not converged in the non-linear scenario.

{_seed_txt}

On the trajectory the decision-centric variant settles by roughly episode
{int(dq[dq.eval_critical_accuracy.notna()].episode.median())}. The decision-centric variant reaches a
held-out accuracy of {fin.loc[('S1','DRL-CF'),'eval_critical_accuracy']:.2f}% in S1 and
{fin.loc[('S3','DRL-CF'),'eval_critical_accuracy']:.2f}% in S3 while transmitting
{fin.loc[('S1','DRL-CF'),'eval_uplink_mbps']:.1f} and {fin.loc[('S3','DRL-CF'),'eval_uplink_mbps']:.1f} Mb/s;
the network-centric variant plateaus at {fin.loc[('S1','DRL (DQN)'),'eval_critical_accuracy']:.2f}% and
{fin.loc[('S3','DRL (DQN)'),'eval_critical_accuracy']:.2f}% while transmitting more than an order of
magnitude more. The gap is therefore not an artefact of undertraining: both policies now run to a budget at
which the decision-centric one is flat, both were trained three times, and the deficit is larger than the
spread. It should be noted that the learned policies pay an offline training cost per scenario that CoFA
does not, and that neither of them provides the fidelity or reliability that CoFA does (Section VII-A).
""")
    add('fig', span=2, file='fig14_dqn_convergence.png', label='Fig. 14',
        caption='Training curves for the two learned baselines, which share architecture, features, '
                'budget and seed and differ only in their reward. (a) each policy\'s own reward. The '
                'two reward functions are different quantities on different scales and their levels '
                'are not comparable, so each curve is rescaled to its own range and only its shape is '
                'to be read; both are centred rolling means over nine episodes. (b) held-out '
                'critical-instant accuracy, averaged over three training seeds; colour is the learner, '
                'dash pattern the scenario. (c) evaluation accuracy per training seed.')
except Exception:
    pass

# ---- K. CFS validation
add('h2', text='J2.  How Tight Is the Bound of Theorem 1?')
_tight = {}
for _m in ORDER:
    _a = M('S1', _m, 'aoc_mean')
    _w = M('S1', _m, 'p_with_mean')
    _e = 1.0 - M('S1', _m, 'decision_accuracy') / 100.0
    _tight[_m] = (_a, _w, _a + _w, _e, (_a + _w) / max(_e, 1e-12))
_tt = sorted(ORDER, key=lambda m: _tight[m][4])
md(f"""
Theorem 1 bounds the no-transmission error process by the Age of Cognition plus the irreducible
post-update error. A bound is only worth stating if it is tight somewhere, so both sides of (12) are
evaluated for every policy on the S1 evaluation block and reported in Table @TIGHT rather than left for a
reader to compute.

The result is that the bound is informative exactly where the backlog is gated and vacuous everywhere else.
For CoFA the Age of Cognition is {_tight['CoFA'][0]:.4f} and the irreducible term
{_tight['CoFA'][1]:.4f}, so the bound stands at {_tight['CoFA'][2]:.3f} against a realized decision-error
rate of {_tight['CoFA'][3]:.4f} - a factor {_tight['CoFA'][4]:.1f}. For the AoII-triggered scheduler, whose
backlog is allowed to grow between the rare instants at which it transmits, the same bound stands at
{_tight['AoII-Aware'][2]:.1f} against a realized error of {_tight['AoII-Aware'][3]:.4f}, a factor of about
{_tight['AoII-Aware'][4]:.0f}. The ordering across the twelve configurations is not incidental: the ratio
tracks the Age of Cognition almost exactly, because the irreducible term is a scenario constant and the
realized error varies by less than a factor of two across policies.

Two things follow, and both are stated as scope rather than as strength. Theorem 1 is a statement about
*gated* policies with bounded AoC; applied to a policy that lets the backlog run it is true and useless.
And the quantity that makes it tight for CoFA is the gate, not the theorem: the bound is the formal
counterpart of the empirical finding of Section VII-G, not independent evidence for it.
""")
add('table', span=2, label='Table @TIGHT',
    caption='Both sides of the bound of Theorem 1 in S1, ordered by tightness. AoC and the irreducible '
            'post-update error are means over the 20 evaluation seeds; the realized error is the '
            'complement of decision accuracy. The bound is informative for gated policies and vacuous '
            'for policies that let the backlog grow.',
    cols=['Policy', 'AoC', 'p-bar^wit', 'Bound (12)', 'Realized error', 'Ratio'],
    widths=[1.7, 1.0, 1.0, 1.0, 1.15, 0.9],
    rows=[[('**' + m + '**') if m.startswith('CoFA') else m,
           f'{_tight[m][0]:.4f}', f'{_tight[m][1]:.4f}',
           (f'{_tight[m][2]:.3f}' if _tight[m][2] < 10 else f'{_tight[m][2]:.1f}'),
           f'{_tight[m][3]:.4f}',
           (f'{_tight[m][4]:.1f}x' if _tight[m][4] < 1000 else f'{_tight[m][4]:.0f}x')]
          for m in _tt])

add('h2', text='K.  Is CET the Quantity It Claims to Be?')
_cv = pd.read_csv(os.path.join(RES, 'e13_cet_summary.csv'))
_cal = _cv[_cv.kind == 'calib']
_auc = _cv[_cv.kind == 'auc']
_msc = _cv[_cv.kind == 'misc']


def CAL(sc, h, col):
    return float(_cal[(_cal.scenario == sc) & (_cal.h == h)][col].iloc[0])


def AUC(sc, lab, sig):
    return float(_auc[(_auc.scenario == sc) & (_auc.label == lab) &
                      (_auc.signal == sig)].auc.iloc[0])


def MSC(sc, col):
    return float(_msc[_msc.scenario == sc][col].iloc[0])


_nprobe = int(pd.read_csv(os.path.join(RES, 'e13_cet_summary.csv')).shape[0] * 0)
try:
    _nprobe = sum(1 for _ in gzip.open(os.path.join(RES, 'e13_cet_validation.csv.gz'), 'rt')) - 1
except Exception:
    _nprobe = 136704
_orc_txt = ''
_op = os.path.join(RES, 'e21_oracle_bound.csv')
if os.path.exists(_op):
    _od = pd.read_csv(_op)
    _og = _od.groupby(['surrogate', 'method'])[['critical_accuracy',
                                                'uplink_mbps']].mean()
    _gain = _og.loc[('oracle', 'CoFA'), 'critical_accuracy'] - \
        _og.loc[('warmup', 'CoFA'), 'critical_accuracy']
    _rem = _og.loc[('oracle', 'CoFA'), 'critical_accuracy'] - \
        max(_og.loc[('oracle', b), 'critical_accuracy']
            for b in ('Goal-Oriented', 'AoII-Aware'))
    _best_b = max(('Goal-Oriented', 'AoII-Aware'),
                  key=lambda b: _og.loc[('oracle', b), 'critical_accuracy'])
    _oc = _og.loc[('oracle', 'CoFA'), 'critical_accuracy']
    _ob = _og.loc[('oracle', _best_b), 'critical_accuracy']
    _wc = _og.loc[('warmup', 'CoFA'), 'critical_accuracy']
    _gap_or = abs(_oc - _ob)
    _orc_txt = (
        "*How much of the S3 shortfall is the surrogate and how much is linearity?* The two are separated "
        "by a clairvoyant control: the same linear surrogate, fitted on the whole realisation instead of on "
        "the 2 s warm-up window, with every other quantity and every random draw held fixed. It is not a "
        "deployable policy - it uses data the orchestrator cannot have - and it is reported only as an "
        "upper bound on what better identification could buy. The answer is that it buys nothing. Fitting "
        "the surrogate on the whole run moves CoFA's critical-instant accuracy in S3 from "
        f"{_wc:.2f}% to {_oc:.2f}%, a change of {_gain:+.2f} points, and it "
        "moves the decision-aware baselines by no more: CoFA still trails the AoII-triggered scheduler "
        f"there by {_gap_or:.2f} "
        "points under the clairvoyant surrogate, as it does under the honest one. The 2 s calibration "
        "window is therefore not what limits the estimator in S3, and a longer or better-identified window "
        "would not close the gap. What is left is the cost of describing a saturating, jump-driven process "
        "by a linear model at all, which is a question of surrogate class rather than of estimation, and "
        "the natural next step is a learned or piecewise surrogate rather than more calibration data.")

_hor_txt = ''
_hp = os.path.join(RES, 'e14_horizons.csv')
if os.path.exists(_hp):
    _hd = pd.read_csv(_hp)
    _ha = _hd.groupby(['scenario', 'hset']).critical_accuracy.mean()
    _hu = _hd.groupby(['scenario', 'hset']).uplink_mbps.mean()
    _hor_txt = (
        "*The depth of the look-ahead is not where the gain comes from.* If the far terms are weakly "
        "informative the look-ahead set should be worth little, and over twelve seeds it is. Shrinking it "
        "from the reported H = {0, 5, 10, 20} to the immediate term alone moves critical-instant accuracy "
        f"in S1 from {_ha[('S1','h0_20')]:.2f}% to {_ha[('S1','h0','')] if False else _ha[('S1','h0')]:.2f}% "
        f"and in S3 from {_ha[('S3','h0_20')]:.2f}% to {_ha[('S3','h0')]:.2f}%, a range of "
        f"{abs(_ha[('S1','h0_20')] - _ha[('S1','h0')]):.2f} and "
        f"{abs(_ha[('S3','h0_20')] - _ha[('S3','h0')]):.2f} points; extending it to a 400 ms horizon adds "
        f"{_ha[('S1','h0_40')] - _ha[('S1','h0_20')]:+.2f} points in S1. Uplink volume, by contrast, is not "
        f"flat at all: {_hu[('S1','h0')]:.1f} Mb/s at H = {{0}} against {_hu[('S1','h0_20')]:.1f} at the "
        f"reported operating point and {_hu[('S1','h0_40')]:.1f} with the longest set, so each additional "
        "horizon buys traffic and not correctness. The reported configuration is therefore the conservative "
        "one, a deployment would be better served by the shallowest set, which is "
        f"{100*(1 - _hu[('S1','h0')]/_hu[('S1','h0_20')]):.0f}% cheaper in uplink at no measurable accuracy "
        "cost, and the mechanism that carries this paper is the *contrast* rather than the horizon over "
        "which it is averaged.")

md(f"""
Whether CET measures what it claims - the reduction in downstream decision-error probability caused by
transmitting - is established against the realized counterfactual rather than inferred from end-to-end
wins. Because the ground-truth trajectory is pre-generated from a stream independent of the transmit
decision, which is assumption (A1), both arms of the intervention can be evaluated exactly on the future
that actually occurred: at a probe instant the replica is propagated forward without an update, and
separately replaced by a reconstruction at the level the estimator assumes and then propagated forward,
with the realized decision error at each horizon evaluated by the true head against the true trajectory and
the contrast formed as in (7). {_nprobe:,} probes were taken across the three scenarios under a
*decision-agnostic* periodic carrier at two update periods, so the sample is not selected by the quantity
being tested. Fig. @CET and Table @CET report the result.

*In level the estimate looks compressive by a factor of two, and most of that is the positive part rather
than the estimator.* Compared as (7) defines it, with the positive part applied to both arms, the predicted
contrast exceeds the measured one by a factor {CAL('S1',-1,'ratio'):.2f} in S1 and
{CAL('S2',-1,'ratio'):.2f} in S2. That comparison is not like for like, however, and the reason is worth
stating precisely: the prediction is a smooth difference of two Gaussian tail probabilities, while the
measurement at a probe is a difference of two binary decision outcomes, so clipping at zero removes a very
different amount of mass from each. Removing the clipping from both arms removes most of the discrepancy.
The unclipped mean predicted contrast in S1 is {CAL('S1',-1,'pred_raw'):+.4f} against a measured
{CAL('S1',-1,'emp_raw'):+.4f}, a ratio of {CAL('S1',-1,'ratio_raw'):.2f} rather than
{CAL('S1',-1,'ratio'):.2f}; the rank correlation is essentially unchanged
({CAL('S1',-1,'rho_raw'):.2f} against {CAL('S1',-1,'rho'):.2f}). In S2 the two unclipped means are small and of
opposite sign ({CAL('S2',-1,'pred_raw'):+.4f} predicted against {CAL('S2',-1,'emp_raw'):+.4f} measured), so
their ratio is not a meaningful quantity and is not quoted. The practical consequence of whatever compression remains is mild,
because the gate compares CET to a threshold that is itself calibrated and adapted, so a roughly constant
scale factor is absorbed. CET is therefore an *ordinal* decision-relevance signal with the right units, not
a calibrated probability, and it should not be reported as one.

*Under model mis-specification the estimator over-states the magnitude of the effect at every horizon.* In
S3, where the orchestrator has only the fitted linear surrogate, both the predicted and the measured
unclipped contrast are negative - at these probes an update at the middle fidelity level does more harm
than good on average - and the prediction is the larger of the two in magnitude by a factor
{CAL('S3',0,'ratio_raw'):.2f} at the immediate horizon and {CAL('S3',5,'ratio_raw'):.2f},
{CAL('S3',10,'ratio_raw'):.2f} and {CAL('S3',20,'ratio_raw'):.2f} at 50, 100 and 200 ms. The surrogate, in
other words, over-states the harm, steadily and at every horizon. Read through the positive part instead,
the same probes appear to show a bias that changes sign with horizon ({CAL('S3',0,'ratio'):.2f} at the
immediate horizon falling to {CAL('S3',20,'ratio'):.2f} at 200 ms); that appearance is produced by the
clipping and not by the dynamics, which is why both views are reported. What is real is the steady
over-statement, and it is the quantitative form of the linearization loss that Section VII-A observes end to
end.

{_orc_txt}

*Informativeness decays with look-ahead.* The rank correlation between predicted and measured contrast is
{CAL('S1',0,'rho'):.2f} at the immediate horizon in S1 and falls to {CAL('S1',20,'rho'):.2f} at 200 ms; in
S3 it falls from {CAL('S3',0,'rho'):.2f} to {CAL('S3',20,'rho'):.2f}, i.e. the far terms of the average are
close to uninformative once the dynamics are only approximated. Most of the ordering power of CET lives in
its short-horizon terms.

*As a detector it is good, and it is not the best.* Labelling a probe critical when suppressing the update
leaves the remote decision wrong at a look-ahead horizon where transmitting would most likely have made it
right, CET separates those cases at AUC {AUC('S1','critical_ahead','CET'):.2f} in S1,
{AUC('S2','critical_ahead','CET'):.2f} in S2 and {AUC('S3','critical_ahead','CET'):.2f} in S3 - far above
elapsed age ({AUC('S1','critical_ahead','AoI'):.2f}) and signal-space distortion
({AUC('S1','critical_ahead','distortion'):.2f}), the two signals the classical schedulers rank by, and above
accumulated incorrectness ({AUC('S1','critical_ahead','AoII backlog'):.2f}). But the present-risk term used
by the goal-oriented baseline scores higher still ({AUC('S1','critical_ahead','present risk'):.2f},
{AUC('S2','critical_ahead','present risk'):.2f} and {AUC('S3','critical_ahead','present risk'):.2f}). That
is reported rather than buried, and it is consistent with the end-to-end result: CoFA's margin over the
goal-oriented scheduler is the smallest of any pair in Tables IV-VI. The advantage of the counterfactual
framing is therefore not sharper instantaneous detection but that the contrast is a *transmission value*
with a scale, usable inside a scheduling index and inside a backlog, which an absolute risk is not.

*Transmitting is not free even in decision terms.* Before the positive part in (7) is taken, the measured
contrast is negative for {100*MSC('S1','frac_harm'):.0f}% of probes in S1,
{100*MSC('S2','frac_harm'):.0f}% in S2 and {100*MSC('S3','frac_harm'):.0f}% in S3, and its unconditional
mean is negative in all three ({MSC('S1','emp_raw'):+.4f} in S1). Sending an update at the middle fidelity
level replaces a possibly-correct dead-reckoned replica by a noisy reconstruction, and near the boundary
that flips a correct decision more often than it repairs a wrong one. Both consequences are already in the
design: gating is a correctness mechanism and not merely a bandwidth economy, and the fidelity level has to
be matched to the local margin rather than fixed, which is what the rule of Section V-A does and what the
ablation of Section VII-G prices.

{_hor_txt}
""")
add('table', span=2, label='Table @CET',
    caption='Predicted against measured counterfactual contrast, by look-ahead horizon. Ratio is '
            'predicted over measured, rho their Spearman rank correlation; the last block is the '
            'detection AUC for updates that matter.',
    cols=['Scenario', 'Horizon', 'Predicted', 'Measured', 'Ratio', 'rho',
          'AUC CET', 'AUC risk', 'AUC AoII', 'AUC AoI'],
    widths=[0.8, 0.8, 0.9, 0.9, 0.7, 0.7, 0.85, 0.85, 0.85, 0.85],
    rows=[[sc, ('mean' if h == -1 else f'{h*10} ms'),
           f'{CAL(sc,h,"pred"):.4f}', f'{CAL(sc,h,"emp"):.4f}',
           f'{CAL(sc,h,"ratio"):.2f}', f'{CAL(sc,h,"rho"):.2f}',
           (f'{AUC(sc,"critical_ahead","CET"):.3f}' if h == -1 else ''),
           (f'{AUC(sc,"critical_ahead","present risk"):.3f}' if h == -1 else ''),
           (f'{AUC(sc,"critical_ahead","AoII backlog"):.3f}' if h == -1 else ''),
           (f'{AUC(sc,"critical_ahead","AoI"):.3f}' if h == -1 else '')]
          for sc in ('S1', 'S2', 'S3') for h in (0, 5, 10, 20, -1)])
add('fig', span=2, file='fig17_cet_validation.png', label='Fig. @CET',
    caption='Direct validation of CET against the realized counterfactual. (a) predicted against '
            'measured contrast, binned by predicted value. (b) rank correlation between them by '
            'look-ahead horizon. (c) detection AUC for updates that matter, against the relevance '
            'signals the baselines rank by.')

add('h2', text='L.  Does the Cognitive Fidelity Score Predict Decision Correctness?')
frames = []
for f in ('e1_main.csv', 'e9_admission.csv', 'e2_load.csv', 'e5_bandwidth.csv'):
    p = os.path.join(RES, f)
    if os.path.exists(p):
        frames.append(pd.read_csv(p))
allr = pd.concat(frames, ignore_index=True)
r_all = {c: float(np.corrcoef(allr[c], allr.critical_accuracy)[0, 1])
         for c in ('cfs', 'cfs_dec', 'cfs_sem', 'cfs_tmp')}
r_aoi = float(np.corrcoef(-allr.aoi_mean, allr.critical_accuracy)[0, 1])
pm = allr.groupby('method')[['cfs', 'critical_accuracy']].mean()
r_pm = float(np.corrcoef(pm.cfs, pm.critical_accuracy)[0, 1])
# is the composite repairable by reweighting its three components?
_grid = []
for _al in np.arange(0.0, 1.001, 0.05):
    for _be in np.arange(0.0, 1.001 - _al + 1e-9, 0.05):
        _ga = 1.0 - _al - _be
        _v = _al * allr.cfs_dec + _be * allr.cfs_sem + _ga * allr.cfs_tmp
        _grid.append((float(np.corrcoef(_v, allr.critical_accuracy)[0, 1]),
                      round(_al, 2), round(_be, 2), round(_ga, 2)))
_grid.sort(reverse=True)
r_best, a_best, b_best, g_best = _grid[0]


def RW(al, be, ga):
    v = al * allr.cfs_dec + be * allr.cfs_sem + ga * allr.cfs_tmp
    return float(np.corrcoef(v, allr.critical_accuracy)[0, 1])
md(f"""
The optimization problem (4) uses average CFS as its objective, yet Tables IV-VI contain cases in which a
baseline attains a comparable or higher CFS while CoFA attains higher critical-instant accuracy. Because
CFS is a designed proxy, that relationship has to be measured rather than asserted. Fig. 15 pools
{len(allr)} runs across all policies, scenarios, load levels and bandwidths.

The result is not the one the objective (4) would like. Across runs the *composite* CFS correlates with
critical-instant decision accuracy at r = {r_all['cfs']:.2f} - essentially uninformative, and if anything
slightly negative. Decomposed, the picture is sharp: the decision-consistency component correlates at
r = {r_all['cfs_dec']:.2f}, while the margin-normalized representational-fidelity component correlates at
r = {r_all['cfs_sem']:.2f} and the cognitive-freshness component at r = {r_all['cfs_tmp']:.2f}. Negated Age
of Information correlates at r = {r_aoi:.2f}, i.e. staleness is also a poor predictor, but the more
interesting observation is that the two regularizing terms of CFS are *anti*-correlated with decision
correctness across the policy population, because the policies that keep the replica most faithful are the
flooding ones whose critical updates then arrive late. Aggregated across policies the anti-correlation is
stronger, not weaker (r = {r_pm:.2f} between policy-mean CFS and policy-mean accuracy).

Three conclusions follow, and all three are adopted. First, with the weights used here (w_d, w_r, w_f) = (0.5, 0.3,
0.2) the composite is *not* a valid ranking variable across heterogeneous policies - and, more sharply than
the previous version of this work reported, it cannot be repaired by reweighting. Sweeping the simplex of
convex weights on a {len(_grid)}-point grid, the best attainable correlation with critical-instant accuracy
is r = {r_best:.2f}, attained at (w_d, w_r, w_f) = ({a_best:.2f}, {b_best:.2f}, {g_best:.2f}) - the degenerate
corner that keeps the decision term alone. A decision-dominant but still composite weighting does not
recover it: (0.8, 0.1, 0.1) gives r = {RW(0.8, 0.1, 0.1):.2f} and (0.9, 0.05, 0.05) gives
r = {RW(0.9, 0.05, 0.05):.2f}, because the two regularizing terms vary far more across policies than the
decision term does and their anti-correlation dominates any non-zero weight. This is why the objective (4)
is stated in this revision as decision correctness outright, rather than as a composite with a raised w_d, and
why the composite is confined to the role the evidence supports. Second, CFS remains a serviceable *control* variable within a single policy: it is
what the meta agent regulates, and Section VII-H shows that regulating it moves the operating point in the
intended direction over most of the range of φ. Third - and this is why the objective's weakness does not
undermine the paper - every comparative claim here is made on the policy-agnostic metrics: critical-instant
decision accuracy, the restoration statistics and the successful-critical-delivery rate. CFS appears in the
tables as a diagnostic, not as evidence.
""")
add('fig', span=2, file='fig15_cfs_validation.png', label='Fig. 15',
    caption='Empirical validation of the Cognitive Fidelity Score against the policy-agnostic decision '
            'metric. (a) all runs, coloured by family. (b) Pearson correlation with critical-instant '
            'accuracy for the composite, its three components and negated AoI - these bars are '
            'signals, not policies, so they carry no family colour, and each carries its value because '
            'the correlations differ by more than an order of magnitude. (c) policy means.')

# ---- L. overhead
add('h2', text='M.  Orchestration Overhead')
md(f"""
The scheduling, gating, level-selection and placement steps cost {M('S1','CoFA','orch_us'):.0f} microseconds
per slot for 100 users in S1 and {M('S3','CoFA','orch_us'):.0f} microseconds for 80 users in S3, measured on
one core. The instrumentation charges the closed-form estimator separately, because the simulator evaluates
it once per slot for every policy in order to keep the critical-update statistics policy-agnostic; measured
alone it costs a further 157 microseconds for 100 users, so CoFA's end-to-end orchestration cost is about
{M('S1','CoFA','orch_us')+157:.0f} microseconds per slot, roughly {(M('S1','CoFA','orch_us')+157)/1e4:.1%} of the
10 ms slot. The simplest periodic baselines cost {M('S1','Edge-Only','orch_us'):.0f} microseconds,
max-age-first {M('S1','AoI-Aware','orch_us'):.0f}, the goal-oriented scheduler
{M('S1','Goal-Oriented','orch_us'):.0f}, and the learned policies {M('S1','DRL (DQN)','orch_us'):.0f}, which
additionally require an offline training phase per scenario that CoFA does not. The dominant term is the
estimator, which is a handful of matrix-vector products of dimension d per user per horizon - O(|H| d²)
per user per slot - is trivially parallel
across users, and in a deployment runs on the device rather than in the scheduler. Background pre-migration
adds {M('S2','CoFA','prewarm_mbps'):.2f} Mb/s of inter-edge traffic in S2.
""")

md(DISCUSSION)
md(LIMITATIONS)
md(CONCLUSION)

REFS = [
 'E. C. Strinati and S. Barbarossa, "6G networks: Beyond Shannon towards semantic and goal-oriented communications," *Computer Networks*, vol. 190, art. 107930, 2021.',
 'D. Gunduz, Z. Qin, I. E. Aguerri, H. S. Dhillon, Z. Yang, A. Yener, K. K. Wong, and C.-B. Chae, "Beyond transmitting bits: Context, semantics, and task-oriented communications," *IEEE J. Sel. Areas Commun.*, vol. 41, no. 1, pp. 5-41, 2023.',
 'M. Kountouris and N. Pappas, "Semantics-empowered communication for networked intelligent systems," *IEEE Commun. Mag.*, vol. 59, no. 6, pp. 96-102, 2021.',
 'H. Xie, Z. Qin, G. Y. Li, and B.-H. Juang, "Deep learning enabled semantic communication systems," *IEEE Trans. Signal Process.*, vol. 69, pp. 2663-2675, 2021.',
 'E. Bourtsoulatze, D. B. Kurka, and D. Gunduz, "Deep joint source-channel coding for wireless image transmission," *IEEE Trans. Cogn. Commun. Netw.*, vol. 5, no. 3, pp. 567-579, 2019.',
 'W. Yang, H. Du, Z. Q. Liew, W. Y. B. Lim, Z. Xiong, D. Niyato, X. Chi, X. Shen, and C. Miao, "Semantic communications for future Internet: Fundamentals, applications, and challenges," *IEEE Commun. Surveys Tuts.*, vol. 25, no. 1, pp. 213-250, 2023.',
 'T. M. Getu, G. Kaddoum, and M. Bennis, "A survey on goal-oriented semantic communication: Techniques, challenges, and future directions," *IEEE Access*, vol. 12, pp. 51223-51274, 2024.',
 'T. M. Getu, G. Kaddoum, and M. Bennis, "Making sense of meaning: A survey on metrics for semantic and goal-oriented communication," *IEEE Access*, vol. 11, pp. 45456-45492, 2023.',
 'Z. Lu, R. Li, K. Lu, X. Chen, E. Hossain, Z. Zhao, and H. Zhang, "Semantics-empowered communications: A tutorial-cum-survey," *IEEE Commun. Surveys Tuts.*, vol. 26, no. 1, pp. 41-79, 2024.',
 'S. Kaul, R. Yates, and M. Gruteser, "Real-time status: How often should one update?," in *Proc. IEEE INFOCOM*, 2012, pp. 2731-2735.',
 'A. Maatouk, S. Kriouile, M. Assaad, and A. Ephremides, "The age of incorrect information: A new performance metric for status updates," *IEEE/ACM Trans. Netw.*, vol. 28, no. 5, pp. 2215-2228, 2020.',
 'R. D. Yates, Y. Sun, D. R. Brown, S. K. Kaul, E. Modiano, and S. Ulukus, "Age of information: An introduction and survey," *IEEE J. Sel. Areas Commun.*, vol. 39, no. 5, pp. 1183-1210, 2021.',
 'Y. Sun, E. Uysal-Biyikoglu, R. D. Yates, C. E. Koksal, and N. B. Shroff, "Update or wait: How to keep your data fresh," *IEEE Trans. Inf. Theory*, vol. 63, no. 11, pp. 7492-7508, 2017.',
 'A. Kosta, N. Pappas, and V. Angelakis, "Age of information: A new concept, metric, and tool," *Found. Trends Netw.*, vol. 12, no. 3, pp. 162-259, 2017.',
 'X. Zheng, S. Zhou, and Z. Niu, "Urgency of information for context-aware timely status updates in remote control systems," *IEEE Trans. Wireless Commun.*, vol. 19, no. 11, pp. 7237-7250, 2020.',
 'B. Buyukates, M. Bastopcu, and S. Ulukus, "Version age of information in clustered gossip networks," *IEEE J. Sel. Areas Inf. Theory*, vol. 3, no. 1, pp. 85-97, 2022.',
 'M. S. Elbamby, C. Perfecto, M. Bennis, and K. Doppler, "Toward low-latency and ultra-reliable virtual reality," *IEEE Network*, vol. 32, no. 2, pp. 78-84, 2018.',
 'G. P. Fettweis, "The tactile Internet: Applications and challenges," *IEEE Veh. Technol. Mag.*, vol. 9, no. 1, pp. 64-70, 2014.',
 'X. Shen, J. Gao, M. Li, C. Zhou, S. Hu, M. He, and W. Zhuang, "Toward immersive communications in 6G," *Frontiers in Computer Science*, vol. 4, art. 1068478, 2023.',
 'A. M. Aslam, R. Chaudhary, A. Bhardwaj, I. Budhiraja, N. Kumar, and S. Zeadally, "Metaverse for 6G and beyond: The next revolution and deployment challenges," *IEEE Internet Things Mag.*, vol. 6, no. 1, pp. 32-39, 2023.',
 'L. Chang, Z. Zhang, P. Li, X. Shan, W. Guo, Y. Shen, Z. Xiong, J. Kang, D. Niyato, X. Qiao, and Y. Wu, "6G-enabled edge AI for Metaverse: Challenges, methods, and future research directions," *J. Commun. Inf. Netw.*, vol. 7, no. 2, pp. 107-121, 2022.',
 'F. Tang, X. Chen, M. Zhao, and N. Kato, "The roadmap of communication and networking in 6G for the Metaverse and digital twin edge networks," *IEEE Wireless Commun.*, vol. 30, no. 4, pp. 72-81, 2023.',
 'Y. Lu, X. Huang, K. Zhang, S. Maharjan, and Y. Zhang, "Communication-efficient federated learning and permissioned blockchain for digital twin edge networks," *IEEE Internet Things J.*, vol. 8, no. 4, pp. 2276-2288, 2021.',
 'O. Hashash, C. Chaccour, and W. Saad, "Edge continual learning for dynamic digital twins over wireless networks," in *Proc. IEEE SPAWC*, 2022, pp. 1-5.',
 'L. Zhao, G. Han, Z. Li, and L. Shu, "Intelligent digital twin-based software-defined vehicular networks," *IEEE Netw.*, vol. 34, no. 5, pp. 178-184, 2020.',
 'H. Ahmadi, A. Nag, Z. Khan, K. Sayrafian, and S. Rahardja, "Networked twins and twins of networks: An overview on the relationship between digital twins and 6G," *IEEE Commun. Standards Mag.*, vol. 5, no. 4, pp. 154-160, 2021.',
 'H. K. Ravuri, J. Struye, J. van der Hooft, T. Wauters, F. De Turck, J. Famaey, and M. Torres Vega, "Context-aware and reliable transport layer framework for interactive immersive media delivery over millimeter wave," *J. Netw. Syst. Manage.*, vol. 32, no. 4, art. 78, 2024.',
 'J. Hao, Y. Chen, and J. Gan, "QoS-aware augmented reality task offloading and resource allocation in cloud-edge collaboration environment," *J. Netw. Syst. Manage.*, vol. 33, no. 1, art. 6, 2025.',
 'Y. Mao, C. You, J. Zhang, K. Huang, and K. B. Letaief, "A survey on mobile edge computing: The communication perspective," *IEEE Commun. Surveys Tuts.*, vol. 19, no. 4, pp. 2322-2358, 2017.',
 'L. Huang, S. Bi, and Y.-J. A. Zhang, "Deep reinforcement learning for online computation offloading in wireless powered mobile-edge computing networks," *IEEE Trans. Mobile Comput.*, vol. 19, no. 11, pp. 2581-2593, 2020.',
 'S. Wang, J. Xu, N. Zhang, and Y. Liu, "A survey on service migration in mobile edge computing," *IEEE Access*, vol. 6, pp. 23511-23528, 2018.',
 'Z. Rejiba, X. Masip-Bruin, and E. Marin-Tordera, "A survey on mobility-induced service migration in the fog, edge, and related computing paradigms," *ACM Comput. Surv.*, vol. 52, no. 5, art. 90, 2019.',
 'L. Xu, W. Liu, Z. Wang, J. Luo, J. Wang, and Z. Ma, "Mobile-aware service function chain intelligent seamless migration in multi-access edge computing," *J. Netw. Syst. Manage.*, vol. 32, no. 3, art. 49, 2024.',
 'O. Kolosov, G. Yadgar, D. Breitgand, and D. H. Lorenz, "PASE: Pro-active service embedding in the mobile edge," *J. Netw. Syst. Manage.*, vol. 33, no. 1, art. 3, 2025.',
 'P. Benlloch-Caballero, A. Matencio-Escolar, J. Bernal Bernabe, A. Skarmeta, Q. Wang, and J. M. Alcaraz-Calero, "E2E network slicing for enhanced cybersecurity, orchestration, automation and response in 5G/6G: The RIGOUROUS approach," *J. Netw. Syst. Manage.*, vol. 34, no. 1, art. 22, 2026.',
 'M. Xu, D. Niyato, J. Kang, Z. Xiong, S. Mao, Z. Han, D. I. Kim, and K. B. Letaief, "When large language model agents meet 6G networks: Perception, grounding, and alignment," *IEEE Wireless Commun.*, vol. 31, no. 6, pp. 63-71, 2024.',
 'J. Tong, J. Shao, Q. Wu, W. Guo, Z. Li, Z. Lin, and J. Zhang, "WirelessAgent: Large language model agents for intelligent wireless networks," arXiv:2409.07964, 2024.',
 'D. B. Acharya, K. Kuppan, and B. Divya, "Agentic AI: Autonomous intelligence for complex goals - a comprehensive survey," *IEEE Access*, vol. 13, pp. 18912-18936, 2025.',
 'R. Zhang, H. Du, Y. Liu, D. Niyato, J. Kang, Z. Xiong, A. Jamalipour, and D. I. Kim, "Generative AI agents with large language model for satellite networks via a mixture of experts transmission," *IEEE J. Sel. Areas Commun.*, vol. 42, no. 12, pp. 3581-3596, 2024.',
 'R. Zhang, G. Liu, Y. Liu, C. Zhao, J. Wang, Y. Xu, D. Niyato, J. Kang, Y. Li, S. Mao, S. Sun, X. Shen, and D. I. Kim, "Toward edge general intelligence with agentic AI and agentification: Concepts, technologies, and future directions," *IEEE Commun. Surveys Tuts.*, vol. 28, pp. 4285-4318, 2026.',
 'Z. Xiao, C. Ye, Y. Hu, H. Yuan, Y. Huang, Y. Feng, L. Cai, and J. Chang, "LLM agents as 6G orchestrator: A paradigm for task-oriented physical-layer automation," arXiv:2410.03688, 2024.',
 'J. Pearl, *Causality: Models, Reasoning, and Inference*, 2nd ed. Cambridge, U.K.: Cambridge Univ. Press, 2009.',
 'C. Glymour, K. Zhang, and P. Spirtes, "Review of causal discovery methods based on graphical models," *Frontiers in Genetics*, vol. 10, art. 524, 2019.',
 'C. K. Thomas and W. Saad, "Neuro-symbolic causal reasoning meets signaling game for emergent semantic communications," *IEEE Trans. Wireless Commun.*, vol. 23, no. 5, pp. 4546-4563, 2024.',
 'C. K. Thomas, C. Chaccour, W. Saad, M. Debbah, and C. S. Hong, "Causal reasoning: Charting a revolutionary course for next-generation AI-native wireless networks," *IEEE Veh. Technol. Mag.*, vol. 19, no. 1, pp. 16-31, 2024.',
 'A. Haghrah, M. P. Abdollahi, H. Azarhava, and J. M. Niya, "A survey on the handover management in 5G-NR cellular networks: Aspects, approaches and challenges," *EURASIP J. Wireless Commun. Netw.*, vol. 2023, art. 52, 2023.',
 'I. Panitsas, A. Mudvari, A. Maatouk, and L. Tassiulas, "A deep and transfer learning approach for handover management in O-RAN," arXiv:2404.08113, 2024.',
 'M. Chiputa, M. Zhang, G. G. M. N. Ali, P. H. J. Chong, H. Sabit, A. Kumar, and H. Li, "Enhancing handover for 5G mmWave mobile networks using jump Markov linear system and deep reinforcement learning," *Sensors*, vol. 22, no. 3, art. 746, 2022.',
 'N. C. Luong, D. T. Hoang, S. Gong, D. Niyato, P. Wang, Y.-C. Liang, and D. I. Kim, "Applications of deep reinforcement learning in communications and networking: A survey," *IEEE Commun. Surveys Tuts.*, vol. 21, no. 4, pp. 3133-3174, 2019.',
 'A. Alwarafy, M. Abdallah, B. S. Ciftler, A. Al-Fuqaha, and M. Hamdi, "The frontiers of deep reinforcement learning for resource management in future wireless HetNets: Techniques, challenges, and research directions," *IEEE Open J. Commun. Soc.*, vol. 3, pp. 322-365, 2022.',
 'S. Mohammadi and B. Akbari, "Priority-aware resource reallocation in edge computing using reinforcement learning," *J. Netw. Syst. Manage.*, vol. 34, no. 1, art. 20, 2026.',
 'M. Yagcioglu, "Enhanced deep reinforcement learning-driven adaptive network slicing and resource allocation for URLLC in 5G networks," *J. Netw. Syst. Manage.*, vol. 34, no. 1, art. 33, 2026.',
 'J. Wang and Y. Yang, "Attention-based high-dimensional offloading with deep recurrent Q-network in a cloud-edge environment," *J. Netw. Syst. Manage.*, vol. 34, no. 1, art. 3, 2026.',
 'M. J. Neely, *Stochastic Network Optimization with Application to Communication and Queueing Systems*. San Rafael, CA, USA: Morgan & Claypool, 2010.',
 'S. Bi, L. Huang, H. Wang, and Y.-J. A. Zhang, "Lyapunov-guided deep reinforcement learning for stable online computation offloading in mobile-edge computing networks," *IEEE Trans. Wireless Commun.*, vol. 20, no. 11, pp. 7519-7537, 2021.',
 'A. Arun, C. K. Thomas, R. Sarvendranath, and W. Saad, "Causal model-based reinforcement learning for sample-efficient IoT channel access," arXiv:2511.10291, 2025.',
 'Y. Kang, J. Hauswald, C. Gao, A. Rovinski, T. Mudge, J. Mars, and L. Tang, "Neurosurgeon: Collaborative intelligence between the cloud and mobile edge," in *Proc. ACM ASPLOS*, 2017, pp. 615-629.',
 'Y. Matsubara, M. Levorato, and F. Restuccia, "Split computing and early exiting for deep learning applications: Survey and research challenges," *ACM Comput. Surv.*, vol. 55, no. 5, art. 90, 2022.',
 'J. Shao, Y. Mao, and J. Zhang, "Learning task-oriented communication for edge inference: An information bottleneck approach," *IEEE J. Sel. Areas Commun.*, vol. 40, no. 1, pp. 197-211, 2022.',
]

REF_DOI = {
  1: '10.1016/j.comnet.2021.107930',
  2: '10.1109/JSAC.2022.3223408',
  3: '10.1109/MCOM.001.2000604',
  4: '10.1109/TSP.2021.3071210',
  5: '10.1109/TCCN.2019.2919300',
  6: '10.1109/COMST.2022.3223224',
  7: '10.1109/ACCESS.2024.3381967',
  8: '10.1109/ACCESS.2023.3269848',
  9: '10.1109/COMST.2023.3333342',
  10: '10.1109/INFCOM.2012.6195689',
  11: '10.1109/TNET.2020.3005549',
  12: '10.1109/JSAC.2021.3065072',
  13: '10.1109/TIT.2017.2735804',
  14: '10.1561/1300000060',
  15: '10.1109/TWC.2020.3009881',
  16: '10.1109/JSAIT.2022.3159745',
  17: '10.1109/MNET.2018.1700268',
  18: '10.1109/MVT.2013.2295069',
  19: '10.3389/fcomp.2022.1068478',
  20: '10.1109/IOTM.001.2200248',
  21: '10.23919/JCIN.2022.9815195',
  22: '10.1109/MWC.019.2100721',
  23: '10.1109/JIOT.2020.3015772',
  24: '10.1109/SPAWC51304.2022.9833928',
  25: '10.1109/MNET.011.1900587',
  26: '10.1109/MCOMSTD.0001.2000041',
  27: '10.1007/s10922-024-09845-5',
  28: '10.1007/s10922-024-09878-w',
  29: '10.1109/COMST.2017.2745201',
  30: '10.1109/TMC.2019.2928811',
  31: '10.1109/ACCESS.2018.2828102',
  32: '10.1145/3326540',
  33: '10.1007/s10922-024-09820-0',
  34: '10.1007/s10922-024-09877-x',
  35: '10.1007/s10922-025-09999-w',
  36: '10.1109/MWC.005.2400019',
  37: '10.48550/arXiv.2409.07964',
  38: '10.1109/ACCESS.2025.3532853',
  39: '10.1109/JSAC.2024.3459037',
  40: '10.1109/COMST.2026.3651702',
  41: '10.48550/arXiv.2410.03688',
  42: None,
  43: '10.3389/fgene.2019.00524',
  44: '10.1109/TWC.2023.3319981',
  45: '10.1109/MVT.2024.3359357',
  46: '10.1186/s13638-023-02261-4',
  47: '10.48550/arXiv.2404.08113',
  48: '10.3390/s22030746',
  49: '10.1109/COMST.2019.2916583',
  50: '10.1109/OJCOMS.2022.3153226',
  51: '10.1007/s10922-025-09992-3',
  52: '10.1007/s10922-025-10009-2',
  53: '10.1007/s10922-025-09972-7',
  54: None,
  55: '10.1109/TWC.2021.3085319',
  56: '10.48550/arXiv.2511.10291',
  57: '10.1145/3037697.3037698',
  58: '10.1145/3527155',
  59: '10.1109/JSAC.2021.3126087',
}



# ===========================================================================
# Structural edits applied after the prose is assembled, so that the source
# above keeps a stable, readable numbering while the manuscript is renumbered
# mechanically:
#   (a) the architecture figure moves next to the paragraph that discusses it;
#   (b) the end-to-end methodology figure opens the experimental section;
#   (c) every figure label and every in-text figure reference is then re-derived
#       from the order in which the figures actually appear, so inserting a
#       figure anywhere cannot leave a stale cross-reference behind.
# ---------------------------------------------------------------------------
import re as _re

# (a) the architecture figure belongs beside its discussion in Section V-A
_arch = next(i for i, b in enumerate(B)
             if b['t'] == 'fig' and b['file'] == 'fig1_architecture.png')
_fig1 = B.pop(_arch)
_anchor = next(i for i, b in enumerate(B)
               if b['t'] == 'p' and 'Fig. 1 shows the architecture' in b['text'])
B.insert(_anchor + 1, _fig1)

# (b2) the end-to-end methodology figure opens the experimental section
_meth_p = dict(t='p', text=(
    'Fig. @METH sets out the complete methodological pipeline that produces every number in '
    'this paper, and is the reference for reproducing them. Stage 1 fixes the environment: '
    'a scenario configuration, the seed-derived common random number streams, a decision '
    'head calibrated to a target transition rate, and the policy under test - all twelve '
    'policies see the identical realization at a given seed. Stage 2 generates the '
    'cognitive state each slot: the ground-truth application state, the local decision '
    'geometry (boundary normal and margin) and the dead-reckoned replica with its '
    'innovation. Stage 3 evaluates the decision-relevance calculus of Section IV on that '
    'state - the counterfactual contrast CET, the Age of Cognition it accrues, and the '
    'Cognitive Fidelity Score. Stage 4 is the orchestration decision of Section V: the '
    'causal gate, the fidelity level, placement, the drift-plus-penalty ranking with '
    'per-cell admission, and predictive pre-migration. Stage 5 carries the admitted '
    'updates over the OFDMA uplink through erasure, queueing and migration, and applies '
    'the delivered ones to the replica, which resets the backlog and closes the estimation '
    'loop back into Stage 2. Stage 6 evaluates: per-slot logging of quantities that no '
    'policy optimizes directly, aggregation over seeds under common random numbers with '
    'paired tests, and the reported comparisons. The only feedback path inside the '
    'orchestrator is the meta agent, which re-tunes V, θ_gate and η from realized fidelity '
    'and occupancy every T_meta slots. Baselines replace Stages 3 and 4 only: Stages 1, 2, '
    '5 and 6 are shared code, which is what makes the comparison a controlled one.'))
_meth_f = dict(
    t='fig', span=2, file='fig0_methodology.png', label='Fig. @METH',
    caption=(
        'End-to-end methodology. Stage 1 fixes the environment and task from the seed alone, '
        'Stages 2-5 run once per slot per user, Stage 6 aggregates. Solid arrows are the '
        'per-slot data path, the orange rail the applied update, the dashed rail the meta '
        'agent. Baselines replace Stages 3 and 4 only.'))
_sec6 = next(i for i, b in enumerate(B)
             if b['t'] == 'h1' and b['text'].startswith('VI.  EXPERIMENTAL'))
B[_sec6 + 1:_sec6 + 1] = [_meth_p, _meth_f]


# ---------------------------------------------------------------------------
# (b2) split the supporting studies out of the main text
#
# The main text carries the argument: the calculus, the orchestrator, the main
# comparison, the ablation that identifies which component earns the result,
# and the direct validation of the central estimator.  Eight further studies
# answer questions a reader may reasonably put to that argument - does it hold
# under congestion, load, mobility, erasure, spectrum scarcity, parameter
# choice, a mis-specified decision model, a different training seed - and each
# is reported in full, but in a separate supplementary document rather than in
# the middle of the argument.  Nothing is deleted and nothing is summarized
# away: the supplementary text is the same text, moved.
# ---------------------------------------------------------------------------
SUPP_SUBSECS = [
    'D.  Scalability with Offered Load',
    'E.  Robustness to Mobility',
    'F.  Link Unreliability and Spectrum Scarcity',
    'H.  Sensitivity to the Framework Parameters',
    'I.  Robustness to an Imperfect Decision Model',
    'J.  Convergence of the Learned Baselines',
    'L.  Does the Cognitive Fidelity Score Predict Decision Correctness?',
]
SUPP_TITLE = {
    'D.  Scalability with Offered Load': 'Scalability with Offered Load',
    'E.  Robustness to Mobility': 'Robustness to Mobility',
    'F.  Link Unreliability and Spectrum Scarcity':
        'Link Unreliability and Spectrum Scarcity',
    'H.  Sensitivity to the Framework Parameters':
        'Sensitivity to the Framework Parameters',
    'I.  Robustness to an Imperfect Decision Model':
        'Robustness to an Imperfect Decision Model',
    'J.  Convergence of the Learned Baselines':
        'Convergence of the Learned Baselines',
    'L.  Does the Cognitive Fidelity Score Predict Decision Correctness?':
        'Does the Cognitive Fidelity Score Predict Decision Correctness?',
}


SUPP_FIGS = [
    ('fig5_cdf.png', 'The Latency Distribution of Causally Critical Updates'),
]

SUPP_TABLES = [
    ('Simulation parameters', 'Simulation Parameters'),
    ('Predicted against measured counterfactual contrast', 'Predicted Against '
     'Measured Counterfactual Contrast, by Look-Ahead Horizon'),
]


def _cut_fig(blocks, fname):
    i = next((k for k, b in enumerate(blocks)
              if b['t'] == 'fig' and b['file'] == fname), None)
    return (blocks.pop(i) if i is not None else None)


def _cut_table(blocks, capfrag):
    """Pull one table out of the main text by the opening of its caption."""
    i = next((k for k, b in enumerate(blocks)
              if b['t'] == 'table' and b['caption'].startswith(capfrag)), None)
    return (blocks.pop(i) if i is not None else None)


def _cut_subsection(blocks, h2text):
    """Remove one lettered subsection, with everything under it, and return it."""
    i = next((k for k, b in enumerate(blocks)
              if b['t'] == 'h2' and b['text'] == h2text), None)
    if i is None:
        return None, None
    j = i + 1
    while j < len(blocks) and blocks[j]['t'] not in ('h1', 'h2'):
        j += 1
    return blocks[i:j], i


# every subsection is tagged with the label it currently carries, so that the
# cross-references in the prose can be rewritten once the split has moved some
# of them into the supplement and renamed the rest
_lab = {}
_cur = None
for _b in B:
    if _b['t'] == 'h1':
        _cur = _b['text'].split('.')[0].strip()
    elif _b['t'] == 'h2' and _cur:
        _lab[id(_b)] = _cur + '-' + _b['text'].split('.')[0].strip()

S = []                              # the supplementary document, in order
_xmap = {}                          # old subsection label -> new label
_first = None
for _n, _name in enumerate(SUPP_SUBSECS, 1):
    _run, _at = _cut_subsection(B, _name)
    if _run is None:
        continue
    if _first is None:
        _first = _at
    del B[_at:_at + len(_run)]
    _xmap[_lab.get(id(_run[0]), '')] = f'S{_n}'
    _run[0] = dict(_run[0], t='h1', text=f'S{_n}.  ' + SUPP_TITLE[_name])
    S += _run

# the subsections that stayed behind are re-lettered consecutively
_cur, _k = None, 0
for _b in B:
    if _b['t'] == 'h1':
        _cur, _k = _b['text'].split('.')[0].strip(), 0
    elif _b['t'] == 'h2' and _cur:
        _old = _lab.get(id(_b))
        _new_letter = chr(ord('A') + _k)
        _k += 1
        _b['text'] = _new_letter + '.  ' + _b['text'].split('.', 1)[1].strip()
        if _old:
            _xmap[_old] = f'{_cur}-{_new_letter}'

# a subsection inserted late carries a suffixed working label such as J2,
# so the cross-reference rewriter has to see one optional digit
_xpat = _re.compile(r'\b([IVX]+)-([A-M]\d?)\b')


def _xref(t):
    if not isinstance(t, str):
        return t
    return _xpat.sub(lambda m: _xmap.get(m.group(0), m.group(0)), t)


for _b in B + S:
    for _k2 in ('text', 'caption', 'title'):
        if _k2 in _b:
            _b[_k2] = _xref(_b[_k2])
    if _b['t'] == 'table':
        _b['cols'] = [_xref(c) for c in _b['cols']]
        _b['rows'] = [[_xref(c) for c in r] for r in _b['rows']]
    if _b['t'] == 'alg':
        _b['lines'] = [_xref(l) for l in _b['lines']]

# one figure follows them: the latency distribution, whose content is also the
# 99th-percentile column of the main comparison tables
SUPP_FIG_LEAD = {
    'fig5_cdf.png': (
        'The 99th-percentile figures quoted in the main comparison summarize the '
        'distribution in Fig. 4. It is the empirical CDF of the delivery latency of '
        'causally critical updates in S1 over three pooled seeds, for all twelve '
        'configurations, with the 20 ms deadline marked. The separation between '
        'the two CoFA operating points and every other policy is wider here than '
        'in any single percentile, because the gating policy removes the queueing '
        'that produces the tail rather than serving the tail faster.'),
}

for _fn, _ttl in SUPP_FIGS:
    _f = _cut_fig(B, _fn)
    if _f is not None:
        _n = sum(1 for b in S if b['t'] == 'h1') + 1
        S += [dict(t='h1', text=f'S{_n}.  {_ttl}'),
              dict(t='p', text=SUPP_FIG_LEAD[_fn]), _f]
        for _bb in B + S:
            if 'text' in _bb:
                _bb['text'] = _bb['text'].replace('@CDFSEC', f'S{_n}')

# two reference tables follow the studies: a full-page parameter listing and the
# horizon-by-horizon calibration detail, neither of which is read in sequence
SUPP_TAB_LEAD = {
    'Simulation parameters': (
        'Every parameter of the simulator is listed in Table III, with the values '
        'that differ between scenarios given in brackets in the order S1 / S2 / S3. '
        'The main text refers to this table wherever a numerical setting is '
        'needed.'),
    'Predicted against measured counterfactual contrast': (
        'The calibration study of the main text is summarized in Table @CET horizon '
        'by horizon: predicted and measured contrast, their ratio, the rank '
        'correlation between them, and, for the aggregate row, the detection AUC '
        'of each candidate relevance signal.'),
}

for _cap, _ttl in SUPP_TABLES:
    _t = _cut_table(B, _cap)
    if _t is not None:
        _n = sum(1 for b in S if b['t'] == 'h1') + 1
        S += [dict(t='h1', text=f'S{_n}.  {_ttl}'),
              dict(t='p', text=SUPP_TAB_LEAD[_cap]), _t]

# the pointer that replaces the moved studies, where the first of them stood
if _first is not None:
    B[_first:_first] = [dict(
        t='p', text=(
            'Seven further studies are reported in the Supplementary Material, '
            'each in full and each run under the same common random numbers as '
            'the comparison above: the sweeps over offered load, user speed, '
            'residual erasure and per-cell bandwidth (Sections S1-S3), the '
            'sensitivity of the framework to its four scalar parameters '
            '(Section S4), its behaviour under a deliberately mis-specified '
            'decision model (Section S5), the convergence and the seed-to-seed '
            'spread of the two learned baselines (Section S6), and the empirical '
            'validation of the Cognitive Fidelity Score against the '
            'policy-independent decision metric (Section S7). Nothing was '
            'summarized away in the move; where a supplementary result '
            'qualifies a claim made here, the qualification is repeated here.'))]

# the supplementary front matter
S[0:0] = [
    dict(t='title', text='Supplementary Material'),
    dict(t='authors', text='Alaa Hamid Mohammed'),
    dict(t='affil', text='Al-Iraqia University, Baghdad, Iraq  ·  '
                         'alaa.hamid@uoa.edu.iq'),
    dict(t='p0', text=(
        'This document accompanies "Decision Correctness, Not Freshness: '
        'Causal-Semantic Update Gating for 6G Edge Orchestration" and reports '
        'seven supporting studies referred to from its '
        'main text. Every number in it is computed from the same measured result '
        'files, under the same common random numbers and the same paired '
        'statistical protocol as the main text; its sections, figures and tables '
        'are numbered S1, S2, and so on, and are cited by those numbers.')),
]

# (c) re-derive every table number from the running order
_ROM = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI',
        'XII', 'XIII', 'XIV', 'XV', 'XVI']
_tmap = {}
for _i, _b in enumerate([b for b in B if b['t'] == 'table']):
    _tmap[_b['label'].replace('Table ', '')] = _ROM[_i]
    _b['label'] = 'Table ' + _ROM[_i]
for _i, _b in enumerate([b for b in S if b['t'] == 'table'], 1):
    _tmap[_b['label'].replace('Table ', '')] = f'S{_i}'
    _b['label'] = f'Table S{_i}'
_tpat = _re.compile(r'\b(Tables?)\s+(@[A-Z]+|S\d+|[IVXL]+)(\s*-\s*(S?\d+|[IVXL]+))?')


def _renumt(t):
    if not isinstance(t, str):
        return t

    def f(m):
        a = _tmap.get(m.group(2), m.group(2))
        if m.group(4):
            return f'{m.group(1)} {a}-{_tmap.get(m.group(4), m.group(4))}'
        return f'{m.group(1)} {a}'
    return _tpat.sub(f, t)


for _b in B + S:
    for _k in ('text', 'caption', 'title'):
        if _k in _b:
            _b[_k] = _renumt(_b[_k])
    if _b['t'] == 'table':
        _b['cols'] = [_renumt(c) for c in _b['cols']]
        _b['rows'] = [[_renumt(c) for c in r] for r in _b['rows']]
    if _b['t'] == 'alg':
        _b['lines'] = [_renumt(l) for l in _b['lines']]

# (c) re-derive every figure number from the running order
_map = {}
for _i, _b in enumerate([b for b in B if b['t'] == 'fig'], 1):
    _map[_b['label'].replace('Fig. ', '')] = str(_i)
    _b['label'] = f'Fig. {_i}'
for _i, _b in enumerate([b for b in S if b['t'] == 'fig'], 1):
    _map[_b['label'].replace('Fig. ', '')] = f'S{_i}'
    _b['label'] = f'Fig. S{_i}'
# a citation may carry a panel letter, as in "Fig. 14c"; the number is
# renumbered and the panel letter is carried through untouched
_pat = _re.compile(r'Fig\. (@[A-Za-z]+|S?\d+)([a-d])?\b')


def _renum(t):
    if not isinstance(t, str):
        return t
    return _pat.sub(lambda m: 'Fig. ' + _map.get(m.group(1), m.group(1))
                    + (m.group(2) or ''), t)


for _b in B + S:
    for _k in ('text', 'caption', 'title'):
        if _k in _b:
            _b[_k] = _renum(_b[_k])
    if _b['t'] == 'table':
        _b['cols'] = [_renum(c) for c in _b['cols']]
        _b['rows'] = [[_renum(c) for c in r] for r in _b['rows']]
    if _b['t'] == 'alg':
        _b['lines'] = [_renum(l) for l in _b['lines']]
_stale = [m[0] for _b in B + S for _k in ('text', 'caption', 'title') if _k in _b
          for m in _pat.findall(_b[_k]) if m[0].startswith('@')]
assert not _stale, f'unresolved figure placeholder: {_stale[:3]}'
_stale = [m for _b in B + S for _k in ('text', 'caption', 'title') if _k in _b
          for m in _tpat.findall(_b[_k]) if m[1].startswith('@')]
assert not _stale, f'unresolved table placeholder: {_stale[:3]}'


# (d) a float belongs after the sentence that first sends the reader to it.
# Section order moved one figure ahead of its first mention when the supporting
# studies were lifted out; rather than hand-place it, every figure is checked
# against the prose and slid down if it arrived early.
def _order_floats(blocks):
    moved = []
    for _ in range(len(blocks)):
        pos = {b['label']: i for i, b in enumerate(blocks) if b['t'] == 'fig'}
        first = {}
        for i, b in enumerate(blocks):
            if b['t'] not in ('p', 'p0', 'h1', 'h2', 'h3'):
                continue
            for lab in _re.findall(r'Fig\. (?:S?\d+)', str(b.get('text') or '')):
                first.setdefault(lab, i)
        early = [(lab, first[lab], pos[lab]) for lab in pos
                 if lab in first and first[lab] > pos[lab]]
        if not early:
            break
        lab, mention, at = early[0]
        blk = blocks.pop(at)
        blocks.insert(mention, blk)          # mention index shifts down by one
        moved.append(lab)
    return moved


for _blocks, _name in ((B, 'manuscript'), (S, 'supplement')):
    _mv = _order_floats(_blocks)
    if _mv:
        print(f'  {_name}: moved after first mention: ' + ', '.join(_mv))


# (e) and every float is actually pointed at from the prose.  A figure or table
# that no sentence sends the reader to is a defect a reader will notice before
# the author does, so the build refuses to produce one.  Ranges are expanded,
# and a citation may live in the other document - the manuscript points at the
# supplement's floats and the supplement points back at the manuscript's.
_ROMI = {r: i for i, r in enumerate(_ROM)}


def _citations(blocks):
    f, t = set(), set()
    for b in blocks:
        if b['t'] not in ('p', 'p0', 'h1', 'h2', 'h3'):
            continue
        txt = str(b.get('text') or '')
        f |= set(_re.findall(r'Fig\.\s*(S?\d+)[a-d]?', txt))
        for m in _re.finditer(r'Tables?\s+(S?\d+|[IVXL]+)'
                              r'(?:\s*[-\u2013]\s*(S?\d+|[IVXL]+))?', txt):
            a, b2 = m.group(1), m.group(2)
            t.add(a)
            if b2:
                t.add(b2)
                if a in _ROMI and b2 in _ROMI:
                    t |= set(_ROM[_ROMI[a]:_ROMI[b2] + 1])
                elif a.startswith('S') and b2.startswith('S'):
                    t |= {f'S{i}' for i in range(int(a[1:]), int(b2[1:]) + 1)}
    return f, t


_cf, _ct = set(), set()
for _blocks in (B, S):
    _a, _b = _citations(_blocks)
    _cf |= _a
    _ct |= _b
for _blocks, _name in ((B, 'manuscript'), (S, 'supplement')):
    _u = [b['label'] for b in _blocks
          if b['t'] == 'fig' and b['label'].replace('Fig. ', '') not in _cf]
    assert not _u, f'{_name}: figure never cited in the text: {_u}'
    _u = [b['label'] for b in _blocks
          if b['t'] == 'table' and b['label'].replace('Table ', '') not in _ct]
    assert not _u, f'{_name}: table never cited in the text: {_u}'
print('  every figure and table is cited in the text')



# ---------------------------------------------------------------------------
# House style (revision 4): the running text carries no italic and no bold.
# Emphasis markers are stripped from every block after the prose is assembled,
# so the source stays readable while the manuscript is set plain throughout.
# Headings keep their paragraph style; only inline emphasis is removed.
# ---------------------------------------------------------------------------
def _plain(t):
    if not isinstance(t, str):
        return t
    prev = None
    while prev != t:
        prev = t
        t = _re.sub(r'\*\*([^*]+?)\*\*', r'\1', t)
        t = _re.sub(r'(?<!\*)\*([^*\s][^*]*?)\*(?!\*)', r'\1', t)
    return t


for _b in B + S:
    for _k in ('text', 'caption', 'label', 'title'):
        if _k in _b:
            _b[_k] = _plain(_b[_k])
    if _b['t'] == 'table':
        _b['cols'] = [_plain(c) for c in _b['cols']]
        _b['rows'] = [[_plain(c) for c in r] for r in _b['rows']]
    if _b['t'] == 'alg':
        _b['lines'] = [_plain(l) for l in _b['lines']]


add('h1', text='APPENDIX A.  PROOF OF THEOREM 2')
add('p', text=(
    'The standard drift-plus-penalty argument [54]. The index (15) is exactly the '
    'per-user contribution to the one-slot conditional drift of L minus V times the '
    'utility U, so admitting the highest-index users greedily minimizes that bound up '
    'to the factor ϱ: the score is additive across users and the per-cell concurrency '
    'constraint is a uniform matroid, on which greedy is exact, so ϱ < 1 only because '
    'the compute nodes are shared and the placement agent selects them independently '
    'of admission. Telescoping over K slots and taking limits gives (16). ∎'))

add('h1', text='REFERENCES')
for i, r in enumerate(REFS, 1):
    # the target journal asks for DOIs to be given as full links
    d = REF_DOI.get(i)
    add('ref', text=f'[{i}]  {r}' + (f' https://doi.org/{d}' if d else ''))

spec = dict(filename='CoFA_6G_Metaverse_manuscript.docx',
            title='Decision Correctness, Not Freshness: Causal-Semantic Update '
                  'Gating for 6G Edge Orchestration',
            creator='Alaa Hamid Mohammed', blocks=B)
with open(os.path.join(HERE, 'content.json'), 'w') as f:
    json.dump(spec, f, ensure_ascii=False, indent=1)
print('content.json:', len(B), 'blocks')

sspec = dict(filename='CoFA_supplementary.docx',
             title='Supplementary Material - Decision-Centric Edge '
                   'Orchestration for the 6G Metaverse',
             creator='Alaa Hamid Mohammed', blocks=S)
with open(os.path.join(HERE, 'content_supp.json'), 'w') as f:
    json.dump(sspec, f, ensure_ascii=False, indent=1)
print('content_supp.json:', len(S), 'blocks')
