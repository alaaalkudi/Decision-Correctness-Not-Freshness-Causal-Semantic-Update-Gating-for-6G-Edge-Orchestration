"""Publication-quality figures for the CoFA paper (600 dpi PNG plus vector PDF)."""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, '..', 'results')
FIG = os.path.join(HERE, '..', 'figs')
os.makedirs(FIG, exist_ok=True)

# ---------------------------------------------------------------------------
# Colour system
#
# Twelve equally-weighted hues is more than any categorical palette can keep
# separable, and it also buries the paper's actual claim.  Colour therefore
# carries the *group* - does the policy reason about the downstream decision or
# not - and identity is carried by position, direct labels and marker shape.
#
#   GROUP  three hues, validated on the all-pairs list (scatter, bars, dots)
#   LINE8  eight hues, validated on the adjacent-pairs list (line sweeps)
#
# Both sets come from the reference palette and pass the lightness band, the
# chroma floor, CVD separation and the normal-vision floor; the sub-3:1 contrast
# entries are relieved by direct labels, which every figure using them carries.
# ---------------------------------------------------------------------------
GROUP = {
    'agnostic': '#2a78d6',      # decision-agnostic families
    'aware':    '#1baf7a',      # decision-aware baselines
    'proposed': '#eb6834',      # CoFA, at either operating point
}
LINE8 = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100',
         '#e87ba4', '#008300', '#4a3aa7', '#e34948']

INK = '#16181d'
INK2 = '#5b616e'
INK3 = '#8b919c'
GRID = '#d9dce1'

# which family reasons about the decision
AWARE = {'AoII-Aware', 'Goal-Oriented', 'DRL-CF'}
PROPOSED = {'CoFA', 'CoFA-E'}


def grp(m):
    return 'proposed' if m in PROPOSED else ('aware' if m in AWARE else 'agnostic')


def gcol(m):
    return GROUP[grp(m)]


MARK = {
    'Cloud-Only': 'v', 'Edge-Only': 's', 'Latency-Aware': '^', 'AoI-Aware': 'D',
    'AoII-Aware': 'p', 'UoI-Aware': 'h', 'DRL (DQN)': 'P', 'DRL-CF': 'X',
    'Semantic-Aware': 'o', 'Goal-Oriented': '<', 'CoFA': '*', 'CoFA-E': 'd',
}
DASH = {
    'Cloud-Only': (0, (1, 1.6)), 'Edge-Only': (0, (5, 1.8)),
    'Latency-Aware': (0, (3, 1.4, 1, 1.4)), 'AoI-Aware': (0, (6, 1.6, 1, 1.6)),
    'AoII-Aware': (0, (4, 1.3)), 'UoI-Aware': (0, (2, 1.2, 1, 1.2)),
    'DRL (DQN)': (0, (5, 2.2)), 'DRL-CF': (0, (1.2, 1.2)),
    'Semantic-Aware': (0, (2.6, 1.2)), 'Goal-Oriented': (0, (4, 1.4, 1, 1.4)),
    'CoFA': (0, ()), 'CoFA-E': (0, (7, 1.6, 1.5, 1.6)),
}
# kept for the few call sites that still ask for a (colour, marker, dash) triple
PAL = {m: (gcol(m), MARK[m], DASH[m]) for m in MARK}

ORDER = ['Cloud-Only', 'Edge-Only', 'Latency-Aware', 'AoI-Aware', 'AoII-Aware',
         'UoI-Aware', 'DRL (DQN)', 'DRL-CF', 'Semantic-Aware', 'Goal-Oriented',
         'CoFA', 'CoFA-E']
BASE = ORDER[:10]
SWEEP = ['Edge-Only', 'AoI-Aware', 'DRL (DQN)', 'AoII-Aware', 'Goal-Oriented',
         'DRL-CF', 'CoFA', 'CoFA-E']
SHORT = {'Cloud-Only': 'Cloud', 'Edge-Only': 'Edge', 'Latency-Aware': 'Latency',
         'AoI-Aware': 'AoI', 'AoII-Aware': 'AoII', 'UoI-Aware': 'UoI',
         'DRL (DQN)': 'DRL', 'DRL-CF': 'DRL-CF', 'Semantic-Aware': 'Semantic',
         'Goal-Oriented': 'Goal', 'CoFA': 'CoFA', 'CoFA-E': 'CoFA-E'}
SCEN = ['S1', 'S2', 'S3']
# Colour means policy family everywhere in the paper, without exception.  Where
# the scenario is the categorical variable instead, it is carried by marker
# shape and by a neutral light-to-dark ramp, so that a reader can never read a
# scenario as a family: the three hues above appear only when they mean CoFA,
# a decision-aware baseline or a decision-agnostic one.
SCOL = {'S1': '#969daa', 'S2': '#5f6875', 'S3': '#22262d'}
SMK = {'S1': 'o', 'S2': 's', 'S3': '^'}

LBL = {k: k for k in MARK}
LBL['CoFA'] = 'CoFA (proposed)'
LBL['CoFA-E'] = 'CoFA-E (efficiency)'

plt.rcParams.update({
    'font.family': 'DejaVu Serif', 'font.size': 7.4,
    'axes.labelsize': 7.6, 'axes.titlesize': 8.0, 'axes.titleweight': 'normal',
    'axes.labelcolor': INK, 'axes.edgecolor': INK3, 'axes.linewidth': 0.6,
    'text.color': INK,
    'xtick.labelsize': 6.9, 'ytick.labelsize': 6.9,
    'xtick.color': INK2, 'ytick.color': INK2,
    'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
    'xtick.major.size': 2.4, 'ytick.major.size': 2.4,
    'legend.fontsize': 6.8, 'legend.frameon': False,
    'axes.grid': True, 'axes.grid.axis': 'y', 'axes.axisbelow': True,
    'grid.color': GRID, 'grid.alpha': 1.0, 'grid.linewidth': 0.5,
    'axes.spines.top': False, 'axes.spines.right': False,
    'lines.linewidth': 1.15, 'lines.markersize': 3.6,
    'lines.markeredgewidth': 0.0,
    'errorbar.capsize': 0,
    # Springer asks for 600 dpi on combination art (line work over shaded
    # regions), which is what these panels are; the vector PDF written beside
    # each PNG by save() is what a production department would actually use.
    'figure.dpi': 300, 'savefig.dpi': 600, 'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})
W1, W2 = 3.45, 7.16          # IEEE single / double column width [in]


def style(ax, xgrid=False):
    """Recessive grid behind the marks, no vertical rules on a category axis."""
    ax.set_axisbelow(True)
    ax.grid(axis='y', color=GRID, lw=0.5)
    if xgrid:
        ax.grid(axis='x', color=GRID, lw=0.5)
    else:
        ax.grid(axis='x', visible=False)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
    return ax


def group_legend(fig, y=1.02, extra=None):
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=GROUP['proposed'], lw=2.4,
                label='CoFA (proposed)'),
         Line2D([], [], color=GROUP['aware'], lw=2.4,
                label='decision-aware baselines'),
         Line2D([], [], color=GROUP['agnostic'], lw=2.4,
                label='decision-agnostic baselines')]
    if extra:
        h += extra
    fig.legend(handles=h, loc='upper center', bbox_to_anchor=(0.5, y),
               ncol=len(h), handlelength=1.5, columnspacing=1.4,
               handletextpad=0.45, borderpad=0.0)


def ci95(x):
    x = np.asarray(x, float)
    return 1.96 * x.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else 0.0


def agg(df, by, val):
    g = df.groupby(by)[val]
    return g.mean(), g.apply(ci95)


def save(fig, name):
    for ext in ('png', 'pdf'):
        fig.savefig(os.path.join(FIG, f'{name}.{ext}'))
    plt.close(fig)
    print('  ->', name)


# ---------------------------------------------------------------- Fig. 1
def fig_architecture():
    fig, ax = plt.subplots(figsize=(W2, 3.6))
    ax.set_xlim(0, 100); ax.set_ylim(0, 74); ax.axis('off'); ax.grid(False)

    labels = []            # (text artist, box width in data units)

    # No fills anywhere in this figure: the boxes are outlines on the page and
    # the bands are named at the left rather than tinted.  Emphasis, where the
    # figure needs it, is carried by a heavier outline, which survives a
    # greyscale print and a photocopy in a way that a pale tint does not.
    def box(x, y, w, h, txt, strong=False, fs=6.8):
        ax.add_patch(FancyBboxPatch((x, y), w, h,
                     boxstyle="round,pad=0.5,rounding_size=1.1",
                     fc='none', ec=INK if strong else INK2,
                     lw=1.3 if strong else 0.7))
        labels.append((ax.text(x + w / 2, y + h / 2, txt, ha='center',
                               va='center', fontsize=fs, linespacing=1.4,
                               color=INK), w))

    def arrow(x1, y1, x2, y2, style='-|>', ls='-', col=INK2):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style,
                     mutation_scale=7, lw=0.8, color=col, ls=ls,
                     shrinkA=1, shrinkB=1))

    L = 9.5                                   # left margin reserved for band labels
    for y, h, lab in [(56, 17, 'Physical /\nuser layer'),
                      (27, 25, 'Agentic edge-\nintelligence layer'),
                      (1, 22, 'Infrastructure\nlayer')]:
        ax.plot([L - 1.4, L - 1.4], [y + 1.2, y + h - 1.2], color=INK3,
                lw=0.7, solid_capstyle='butt', zorder=1)
        ax.text(L / 2 - 0.8, y + h / 2, lab, fontsize=6.2,
                color=INK2, ha='center', va='center', rotation=90,
                linespacing=1.2)

    # the rounded outline adds half a unit on each side, so the columns are
    # spaced to leave a visible gap between neighbouring boxes rather than
    # letting their corners touch
    G = 1.8
    W = (100 - L - 3.5 - 3 * G) / 4.0
    xs = [L + 1 + i * (W + G) for i in range(4)]
    FULL = 4 * W + 3 * G
    box(xs[0], 58.5, W, 11.5, 'XR / embodied users\n$x_u(t)$, mobility $p_u(t)$')
    box(xs[1], 58.5, W, 11.5, 'On-device semantic\nencoder, level $\\ell$')
    box(xs[2], 58.5, W, 11.5, 'Causal-semantic\nimportance $I_u(t)$ (CET)', strong=True)
    box(xs[3], 58.5, W, 11.5, 'Application decision\nhead $g(\\cdot)$, margin $m_u$')

    box(xs[0], 40.5, W, 11.5, 'Perception agent\nCFS / AoC tracking')
    box(xs[1], 40.5, W, 11.5, 'Synchronisation agent\ngate $\\theta$, level $\\ell$')
    box(xs[2], 40.5, W, 11.5, 'Scheduling agent\ndrift-plus-penalty')
    box(xs[3], 40.5, W, 11.5, 'Placement + mobility\nedge/cloud, pre-migration')
    box(xs[0], 29.5, FULL, 7.5,
        'Meta (reflection) agent  —  adapts $V$, $\\theta$, $\\eta$ from observed CFS, AoC and cell occupancy')

    ew = W
    box(xs[0], 10.5, ew, 10, 'Edge server 1\n$f_1$, queue')
    box(xs[1], 10.5, ew, 10, 'Edge server $m$\n$f_m$, queue')
    box(xs[2], 10.5, ew, 10, 'Edge server $M$\n$f_M$, queue')
    box(xs[3], 10.5, ew, 10, 'Cloud $f_c$\nbackhaul $2\\tau_b$')
    box(xs[0], 2.0, FULL, 6.5,
        'gNB / mmWave RAN  —  OFDMA uplink, A3 handover (hysteresis, TTT), erasures')

    for x in [xi + W / 2 for xi in xs]:
        arrow(x, 58.3, x, 52.3)
        arrow(x, 40.3, x, 37.2)
        arrow(x, 29.3, x, 20.7, style='<|-|>')
        arrow(x, 10.3, x, 8.7)
    # the telemetry path back to the meta agent is routed orthogonally: drawn
    # as one long shallow diagonal it crossed its own caption and read as a
    # stray rule rather than as a feedback edge
    fb_y = 24.6
    ax.plot([88, 88], [26.4, fb_y], color=INK3, lw=0.8, ls='--', zorder=1)
    ax.plot([88, xs[0] + 10], [fb_y, fb_y], color=INK3, lw=0.8, ls='--',
            zorder=1)
    arrow(xs[0] + 10, fb_y, xs[0] + 10, 29.2, style='-|>', ls='--', col=INK3)
    ax.text(56, fb_y + 1.1, 'observed CFS, AoC, queue backlog, occupancy',
            fontsize=6.0, color=INK2, ha='center', va='bottom',
            bbox=dict(fc='white', ec='none', pad=0.6), zorder=2)

    # a label that runs past its own box reads as a mistake; each is measured
    # once the canvas exists and shrunk until it sits inside, with the smallest
    # size reported so the figure is never silently rendered below legibility
    fig.canvas.draw()
    inv = ax.transData.inverted()
    small = 99.0
    for t, w in labels:
        for _ in range(12):
            bb = t.get_window_extent(fig.canvas.get_renderer())
            x0, _ = inv.transform((bb.x0, bb.y0))
            x1, _ = inv.transform((bb.x1, bb.y1))
            if (x1 - x0) <= w - 2.4:
                break
            t.set_fontsize(t.get_fontsize() * 0.96)
        small = min(small, t.get_fontsize())
    print(f'     smallest box font: {small:.2f} pt')
    save(fig, 'fig1_architecture')


# ---------------------------------------------------------------- Fig. 2
def fig_methodology():
    """End-to-end methodological pipeline: seeded environment generation ->
    cognitive-state generation -> decision-relevance calculus -> orchestration
    decision -> transmission and synchronization -> policy-independent
    evaluation, with the two feedback paths that close the loop."""
    fig, ax = plt.subplots(figsize=(6.3, 5.2))   # drawn at final print size
    ax.set_position([0, 0, 1, 1])          # the axes fills the canvas, so the
    ax.set_xlim(0, 100); ax.set_ylim(0, 98)   # drawn point sizes are the final
    ax.axis('off'); ax.grid(False)           # point sizes at 15.5 cm width

    L, R, PAD, GAP = 13.2, 6.5, 0.35, 1.4
    SPAN = 100 - L - R

    labels = []                      # (artist, usable width, usable height)

    # unfilled boxes throughout: the stages are named at the left and separated
    # by a rule, so no tint is needed to tell them apart
    def box(x, y, w, h, txt, strong=False, fs=6.9):
        ax.add_patch(FancyBboxPatch((x + PAD, y + PAD), w - 2 * PAD,
                     h - 2 * PAD,
                     boxstyle=f"round,pad={PAD},rounding_size=1.0",
                     fc='none', ec=INK if strong else INK2,
                     lw=1.2 if strong else 0.7))
        t = ax.text(x + w / 2, y + h / 2, txt, ha='center', va='center',
                    fontsize=fs, linespacing=1.45, color=INK)
        labels.append((t, w - 3.0 * PAD, h - 3.0 * PAD))

    def line(x1, y1, x2, y2, ls='-', col=INK2, lw=0.85):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle='-',
                     mutation_scale=7, lw=lw, color=col, ls=ls,
                     shrinkA=0, shrinkB=0))

    def head(x1, y1, x2, y2, ls='-', col=INK2, lw=0.85):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle='-|>',
                     mutation_scale=7, lw=lw, color=col, ls=ls,
                     shrinkA=0, shrinkB=0))

    def row(items, y, h, strong=False, fs=6.9):
        n = len(items)
        w = (SPAN - GAP * (n - 1)) / n
        xs = [L + i * (w + GAP) for i in range(n)]
        for x, t in zip(xs, items):
            box(x, y, w, h, t, strong, fs)
        return [x + w / 2 for x in xs], w

    def bus(ya, cu, yb, cl):
        """Fan the upper band's outputs into the lower band's inputs."""
        r = (ya + yb + H) / 2.0
        for x in cu:
            line(x, ya, x, r)
        line(min(cu + cl), r, max(cu + cl), r)
        for x in cl:
            head(x, r, x, yb + H)

    H = 12.4
    BANDS = [
        (83.8, 'Stage 1\nInputs'),
        (67.4, 'Stage 2\nCognitive state'),
        (51.0, 'Stage 3\nDecision relevance'),
        (34.6, 'Stage 4\nOrchestration'),
        (18.2, 'Stage 5\nSynchronization'),
        (1.8, 'Stage 6\nEvaluation'),
    ]
    for y, lab in BANDS:
        ax.plot([L - 1.9, L - 1.9], [y - 0.4, y + H + 0.4], color=INK3,
                lw=0.7, solid_capstyle='butt', zorder=1)
        ax.text(3.4, y + H / 2, lab, fontsize=6.2,
                color=INK2, ha='center', va='center', linespacing=1.3)

    y1, y2, y3, y4, y5, y6 = [b[0] for b in BANDS]

    c1, w1 = row([
        'Scenario setup\nS1 / S2 / S3 / S1C / S1D\nusers, spectrum, $K$',
        'Common random\nnumbers per seed\nstate, channel, noise',
        'Task model\nhead $g(\cdot)$ calibrated\nto rate $\lambda_{\mathrm{tr}}$',
        'Policy under test\none of twelve, same\nrealisation',
    ], y1, H)

    c2, w2 = row([
        'Ground-truth state $x_u(k)$\nGauss-Markov (S1, S2) or\nnon-Gaussian pose (S3)',
        'Local geometry\nboundary normal $w_{\mathrm{loc}}(x_u)$,\ndecision margin $m_u$',
        'Replica $\hat{x}_u(k)$, innovation\n$e_u = x_u - \hat{x}_u$; dead\nreckoning between updates',
    ], y2, H)

    c3, w3 = row([
        'CET$_u(k)$, eqs. (7)-(9)\ninterventional contrast\nover horizons $\mathcal{H}$',
        'Age of Cognition, eq. (11)\n$\Delta^{\mathrm{c}}_u \!\leftarrow\! \Delta^{\mathrm{c}}_u + [\mathrm{CET}_u - \psi_0]^{+}$',
        'Cognitive Fidelity Score\neq. (10): decision, fidelity,\nfreshness',
    ], y3, H)

    c4, w4 = row([
        'Causal gate\neq. (14)\ntransmit?',
        'Fidelity level\n$\ell$ from the\nmargin $m_u$',
        'Placement\nedge or cloud,\nmin. latency',
        'Ranking $\Psi_u$ (15)\nadmit top $K$\nper cell',
        'Predictive\npre-migration\nat handover',
    ], y4, H)

    c5, w5 = row([
        'Uplink transport\nOFDMA rate (2), erasure\n$\\varepsilon_u$, handover gap',
        'Edge / cloud compute\nFIFO queues, backhaul,\nstate migration',
        'Replica update\n$\hat{x}_u\!\leftarrow\!\hat{A}^{\\tau}x_u(k_{\mathrm{gen}}) + \zeta$,\n$\Delta^{\mathrm{c}}_u\!\leftarrow\!0$',
    ], y5, H)

    c6, w6 = row([
        'Per-slot logging\ndecision error, latency,\nAoI / AoC, bits, energy',
        'Paired statistics\n6-20 seeds, common\nrandom numbers, $t$ test',
        'Reported outcomes\naccuracy, SCDD, latency,\nablation, sensitivity',
    ], y6, H)

    bus(y1, c1, y2, c2)
    bus(y2, c2, y3, c3)
    bus(y3, c3, y4, c4)
    bus(y4, c4, y5, c5)
    bus(y5, c5, y6, c6)

    # feedback 1: the applied update refreshes the replica (right rail)
    xr = 100 - R / 2
    xe = c5[2] + w5 / 2
    line(xe, y5 + H / 2, xr, y5 + H / 2, col=GROUP['proposed'])
    line(xr, y5 + H / 2, xr, y2 + H / 2, col=GROUP['proposed'])
    head(xr, y2 + H / 2, c2[2] + w2 / 2, y2 + H / 2, col=GROUP['proposed'])
    ax.text(xr - 1.5, (y2 + y5) / 2 + H / 2,
            'the applied update refreshes the replica',
            fontsize=6.2, color=GROUP['proposed'], rotation=90,
            ha='center', va='center')

    # feedback 2: the meta agent re-tunes the orchestrator (left rail)
    xl = L - 2.5
    line(c6[0] - w6 / 2, y6 + H / 2, xl, y6 + H / 2, ls='--', col=INK3)
    line(xl, y6 + H / 2, xl, y4 + H / 2, ls='--', col=INK3)
    head(xl, y4 + H / 2, c4[0] - w4 / 2, y4 + H / 2, ls='--', col=INK3)
    ax.text(xl + 1.35, (y4 + y6) / 2 + H / 2,
            'meta agent adapts $V$, $\\theta_{\mathrm{gate}}$, $\eta$',
            fontsize=6.2, color=INK2, rotation=90,
            ha='center', va='center')

    # shrink any label that does not fit its box, measured rather than guessed
    fig.canvas.draw()
    rend = fig.canvas.get_renderer()
    p0 = ax.transData.transform((0, 0))
    px = ax.transData.transform((1, 0))[0] - p0[0]
    py = ax.transData.transform((0, 1))[1] - p0[1]
    smallest = 99.0
    for t, wmax, hmax in labels:
        for _ in range(12):
            bb = t.get_window_extent(rend)
            r = min(wmax * px / max(bb.width, 1e-6),
                    hmax * py / max(bb.height, 1e-6))
            if r >= 1.0:
                break
            t.set_fontsize(max(t.get_fontsize() * max(r, 0.88) * 0.99, 4.0))
        smallest = min(smallest, t.get_fontsize())
        if t.get_fontsize() < 6.4:
            print('     tight: %.2f pt  %r' % (t.get_fontsize(),
                                               t.get_text().split(chr(10))[0]))
    print('     smallest box font: %.2f pt' % smallest)
    save(fig, 'fig0_methodology')


# ---------------------------------------------------------------- Fig. 3
def fig_trace():
    import sys
    sys.path.insert(0, HERE)
    from scenarios import cfg_for
    from cofa import Simulator
    import policies as P
    out = {}
    for name, mk in [('Edge-Only', P.EdgeOnly), ('CoFA', P.CoFA)]:
        cfg = cfg_for('S1', seed=3, T=12.0, trace_user=7)
        r = Simulator(cfg, mk(cfg)).run()
        out[name] = r['trace']
    t = np.array(out['CoFA']['t'])
    sel = (t >= 3.0) & (t <= 8.0)
    fig, axs = plt.subplots(3, 1, figsize=(W1, 3.7), sharex=True)
    fig.subplots_adjust(hspace=0.16)
    for name in ('Edge-Only', 'CoFA'):
        tr = out[name]
        big = name in PROPOSED
        kw = dict(color=gcol(name), ls=DASH[name],
                  lw=1.5 if big else 0.9, zorder=4 if big else 3)
        axs[0].plot(t[sel], 1000 * np.array(tr['aoi'])[sel], label=LBL[name], **kw)
        axs[1].plot(t[sel], np.array(tr['aoc'])[sel], **kw)
        axs[2].plot(t[sel], np.abs(np.array(tr['dc']))[sel], **kw)
    for a, lab in zip(axs, ['(a) AoI [ms]', '(b) AoC  $\\Delta_u^{\\mathrm{c}}$',
                            '(c) $|w^{\\top}(x-\\hat{x})|$']):
        style(a)
        a.set_ylabel(lab)
        a.margins(x=0)
    axs[2].set_xlabel('time [s]')
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=gcol(n), ls=DASH[n], lw=1.5 if n in PROPOSED else 1.0,
                label=LBL[n]) for n in ('Edge-Only', 'CoFA')]
    fig.legend(handles=h, loc='upper center', bbox_to_anchor=(0.5, 0.985),
               ncol=2, handlelength=2.4, columnspacing=1.6)
    save(fig, 'fig2_trace')


# ---------------------------------------------------------------- results figures
def fig_main_bars(df):
    """Three measures, twelve configurations, three scenarios.

    A dot plot rather than bars: the accuracy panel needs a zoomed range to be
    readable at all, and a bar whose baseline is not zero misrepresents its own
    length.  Rows are ordered by mean critical-instant accuracy so the claim the
    paper makes - that the decision-aware families occupy the top - is the first
    thing the eye reads.  Colour carries the group; the row label carries the
    identity."""
    order = (df[df.method.isin(ORDER)].groupby('method').critical_accuracy
             .mean().sort_values().index.tolist())
    y = np.arange(len(order))
    mets = [('critical_accuracy', 'Critical-instant accuracy [%]', False),
            ('uplink_mbps', 'Uplink traffic [Mb/s]', True),
            ('restore_le20', 'Restored within 20 ms [%]', False)]
    fig, axs = plt.subplots(1, 3, figsize=(W2, 2.9), sharey=True)
    fig.subplots_adjust(wspace=0.10)
    for ax, (met, lab, logx) in zip(axs, mets):
        style(ax, xgrid=True)
        ax.grid(axis='y', visible=False)
        for i, m in enumerate(order):
            c = gcol(m)
            xs = [df[(df.scenario == sc) & (df.method == m)][met].mean()
                  for sc in SCEN]
            ax.plot([min(xs), max(xs)], [y[i]] * 2, '-', color=c, lw=0.7,
                    solid_capstyle='round', zorder=1)
            for sc, x in zip(SCEN, xs):
                ax.plot(x, y[i], SMK[sc], color=c, ms=3.7, zorder=3,
                        mec='white', mew=0.45)
        if logx:
            ax.set_xscale('log')
        ax.set_xlabel(lab)
        ax.tick_params(axis='y', length=0)
        ax.margins(x=0.09, y=0.06)
    axs[0].set_yticks(y)
    axs[0].set_yticklabels([SHORT[m] for m in order], color=INK)
    from matplotlib.lines import Line2D
    extra = [Line2D([], [], color=INK3, marker=SMK[sc], ls='none', ms=3.6,
                    label=sc) for sc in SCEN]
    group_legend(fig, y=1.06, extra=extra)
    save(fig, 'fig3_main_bars')


def fig_pareto(df):
    """Accuracy against the traffic it costs.

    Twelve points in a panel this size cannot all carry a floating text label:
    the previous version labelled eight of them, which left four blue points
    unidentifiable and put the "CoFA" label nearer to a neighbouring green
    marker than to its own.  Identity is therefore carried by a marker key, one
    entry per policy, exactly as in the sweep figures - so every point can be
    named and no label can be attached to the wrong mark.
    """
    from matplotlib.lines import Line2D
    fig, axs = plt.subplots(1, 3, figsize=(W2, 2.6))
    fig.subplots_adjust(wspace=0.26)
    for ax, sc in zip(axs, SCEN):
        style(ax, xgrid=True)
        d = df[df.scenario == sc]
        # every method meets the same twenty realisations, so the seed effect is
        # common to all of them and is removed before the interval is formed
        cen = {c: d.groupby('seed')[c].transform('mean') - d[c].mean()
               for c in ('uplink_mbps', 'critical_accuracy')}
        for m in ORDER:
            dd = d[d.method == m]
            if not len(dd):
                continue
            c, big = gcol(m), m in PROPOSED
            msk = (d.method == m).values
            ax.errorbar(dd.uplink_mbps.mean(), dd.critical_accuracy.mean(),
                        xerr=ci95(dd.uplink_mbps.values - cen['uplink_mbps'].values[msk]),
                        yerr=ci95(dd.critical_accuracy.values
                                  - cen['critical_accuracy'].values[msk]),
                        marker=MARK[m], color=c, ms=6.8 if big else 4.4,
                        mec='white', mew=0.5, lw=0.7, elinewidth=0.7,
                        zorder=4 if big else 3)
        ax.set_xscale('log')
        ax.set_xlabel('Uplink traffic [Mb/s]')
        ax.set_title(f'Scenario {sc}', pad=3)
        ax.margins(x=0.22, y=0.16)
    axs[0].set_ylabel('Critical-instant\ndecision accuracy [%]')
    key = [Line2D([], [], color=gcol(m), marker=MARK[m],
                  ms=5.6 if m in PROPOSED else 4.2, ls='none',
                  mec='white', mew=0.5, label=SHORT[m]) for m in ORDER]
    fig.legend(handles=key, loc='upper center', bbox_to_anchor=(0.5, 1.13),
               ncol=6, handlelength=0.9, columnspacing=1.0,
               handletextpad=0.35, borderpad=0.0)
    save(fig, 'fig4_pareto')


def sweep(df, xcol, xlabel, name, metrics=None, xdiv=1.0):
    """One operating condition swept across the eight comparable policies.

    Colour carries the family, so the reader sees at a glance that the warm
    curve sits above the green ones and both sit above the blue ones; dash
    pattern and marker carry the individual policy, which the legend spells
    out.  Traffic spans two decades across the families, so its panel is
    logarithmic; ticks are placed at the levels that were actually simulated
    rather than at round numbers between them.

    The interval is the seed-paired one: every method meets the same
    realisation at every level, so the seed-to-seed spread is common to all of
    them and is removed before the interval is formed.  Drawn raw it would be
    several times the distance between the curves it is meant to qualify, and
    would say nothing about the comparison the panel is for."""
    metrics = metrics or [('critical_accuracy', 'Critical-instant accuracy [%]'),
                          ('uplink_mbps', 'Uplink traffic [Mb/s]'),
                          ('restore_le20', 'Restored within 20 ms [%]')]
    fig, axs = plt.subplots(1, len(metrics), figsize=(W2, 2.35))
    fig.subplots_adjust(wspace=0.30)
    lv = sorted(df[xcol].unique())
    for ax, (met, lab) in zip(axs, metrics):
        style(ax)
        for m in SWEEP:
            d = df[df.method == m]
            if not len(d):
                continue
            mu, er = within_seed(d, xcol, met)
            big = m in PROPOSED
            ax.errorbar(mu.index, mu.values, yerr=er.values, marker=MARK[m],
                        ls=DASH[m], color=gcol(m), label=LBL[m],
                        lw=1.8 if big else 1.0, elinewidth=0.6,
                        ms=5.4 if big else 3.6, zorder=4 if big else 3)
        if met == 'uplink_mbps':
            ax.set_yscale('log')
        # tick labels are written out, so matplotlib never places a shared
        # exponent where the axis label belongs
        ax.set_xticks(lv, labels=[f'{v / xdiv:g}' for v in lv])
        ax.set_xlabel(xlabel)
        ax.set_ylabel(lab)
        ax.margins(x=0.06)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, ncol=4, loc='upper center', bbox_to_anchor=(0.5, 1.05),
               columnspacing=1.2, handlelength=2.6, handletextpad=0.4,
               fontsize=6.4)
    save(fig, name)


ABL = ['w/o causal importance', 'w/o AoC (AoI instead)',
       'w/o predictive migration', 'w/o adaptive fidelity level',
       'w/o placement agent', 'w/o adaptive meta-agent']
ABL_SHORT = {'w/o causal importance': 'causal importance',
             'w/o AoC (AoI instead)': 'AoC (AoI instead)',
             'w/o predictive migration': 'predictive migration',
             'w/o adaptive fidelity level': 'adaptive fidelity level',
             'w/o placement agent': 'placement agent',
             'w/o adaptive meta-agent': 'adaptive meta-agent'}


def paired_delta(d, variant, col, rel=False):
    """Mean and 95% interval of the per-seed difference (variant - full).

    The seeds are shared between the full system and every ablated variant, so
    the difference is formed within a seed before it is averaged; the common
    random numbers then cancel and the interval reflects the effect of removing
    the component rather than the spread of the environment."""
    f = d[d.variant == 'CoFA (full)'].set_index('seed')[col]
    g = d[d.variant == variant].set_index('seed')[col]
    s = g.index.intersection(f.index)
    dl = g.loc[s] - f.loc[s]
    if rel:
        dl = 100.0 * dl / f.loc[s]
    return float(dl.mean()), ci95(dl.values)


def _delta_panel(ax, d, col, rel, label, order, scen=None):
    y = np.arange(len(order))[::-1]
    ax.axvline(0, color=INK3, lw=0.8, zorder=2)
    if scen is None:
        for i, v in enumerate(order):
            m, e = paired_delta(d, v, col, rel)
            ax.errorbar(m, y[i], xerr=e, marker='o', ms=4.2,
                        color=GROUP['proposed'], elinewidth=0.7, zorder=4)
    else:
        for sc, dy in zip(scen, np.linspace(0.24, -0.24, len(scen))):
            ds = d[d.scenario == sc]
            for i, v in enumerate(order):
                m, e = paired_delta(ds, v, col, rel)
                ax.errorbar(m, y[i] + dy, xerr=e, marker=SMK[sc], ms=3.8,
                            color=SCOL[sc], elinewidth=0.7, zorder=4)
    ax.set_yticks(y)
    ax.set_ylim(-0.7, len(order) - 0.3)
    ax.set_xlabel(label)
    return y


def fig_admission():
    """The admission-limited cell: which policies hold up, how the queue weight
    trades accuracy against traffic, and what each component contributes."""
    d = pd.read_csv(os.path.join(RES, 'e9_admission.csv'))
    v = pd.read_csv(os.path.join(RES, 'e10_sens_V_admission.csv'))
    a = pd.read_csv(os.path.join(RES, 'e9b_admission_ablation.csv'))
    fig, axs = plt.subplots(1, 3, figsize=(W2, 2.65),
                            gridspec_kw=dict(width_ratios=[1.05, 0.95, 1.0]))
    fig.subplots_adjust(wspace=0.44)

    ax = style(axs[0], xgrid=True)
    mu = {m: d[d.method == m].critical_accuracy.mean() for m in ORDER}
    seq = sorted(ORDER, key=lambda m: mu[m])
    y = np.arange(len(seq))
    for i, m in enumerate(seq):
        ax.errorbar(mu[m], i, xerr=ci95(d[d.method == m].critical_accuracy),
                    marker=MARK[m], ms=5.4 if m in PROPOSED else 3.8,
                    color=gcol(m), elinewidth=0.7, zorder=4)
    ax.set_yticks(y)
    ax.set_yticklabels([SHORT[m] for m in seq], color=INK)
    ax.grid(axis='y', visible=False)
    ax.set_xlabel('Critical-instant accuracy [%]')
    ax.set_title('(a) admission-limited cell', pad=4)
    ax.margins(x=0.10, y=0.05)

    ax = style(axs[1])
    lv = sorted(v.p_V.unique())
    mu2, er2 = within_seed(v, 'p_V', 'critical_accuracy')
    ax.errorbar(mu2.index, mu2.values, yerr=er2.values, marker='*', ms=6,
                color=GROUP['proposed'], elinewidth=0.7)
    ax.set_xscale('log')
    # a rotated 5.6 pt label is not readable at print size, so the panel is
    # ticked at every other simulated level and the labels stay horizontal
    ax.set_xticks(lv[::2], labels=[f'{x:g}' for x in lv[::2]])
    ax.get_xaxis().set_minor_locator(matplotlib.ticker.NullLocator())
    ax.set_xlabel('queue weight $V$')
    ax.set_ylabel('Critical-instant accuracy [%]')
    ax.set_title('(b) queue-weight sweep', pad=4)
    # the effect is null, and an axis fitted to a null effect magnifies noise
    # into a trend; the panel is given a full point of range so that flat looks
    # flat next to the differences the rest of the figure shows
    ctr = 0.5 * (mu2.min() + mu2.max())
    ax.set_ylim(ctr - 0.5, ctr + 0.5)

    ax = style(axs[2], xgrid=True)
    order = [o for o in ABL if o in set(a.variant)]
    _delta_panel(ax, a, 'critical_accuracy', False,
                 '$\\Delta$ accuracy vs CoFA [points]', order)
    ax.yaxis.tick_right()          # the labels have nowhere to go on the left
    ax.set_yticklabels([ABL_SHORT[o] for o in order], fontsize=6.2, color=INK)
    ax.tick_params(axis='y', length=0, pad=2)
    ax.grid(axis='y', visible=False)
    ax.set_title('(c) component removed', pad=4)
    ax.margins(x=0.12)
    save(fig, 'fig10_admission')


def fig_ablation(df):
    """What each component is worth, as the change it causes when it is removed.

    Plotting the level of each variant would put the whole story inside the last
    two percent of a bar; the quantity of interest is the difference from the
    full system, so that is what is drawn, against a zero reference, paired by
    seed.  Accuracy is in points, traffic relative, because the two move on very
    different scales."""
    order = [o for o in ABL if o in set(df.variant)]
    fig, axs = plt.subplots(1, 2, figsize=(W2, 2.35),
                            gridspec_kw=dict(width_ratios=[1.0, 1.0]))
    fig.subplots_adjust(wspace=0.10)
    # one component is worth several points and the rest a fraction of one, so a
    # linear axis would collapse five of the six rows onto the reference line;
    # the scale is linear through zero and logarithmic outside it, and the tick
    # at the transition marks where that change happens
    scal = [dict(linthresh=0.2, ticks=[-5, -1, -0.2, 0, 0.2],
                 lab=['-5', '-1', '-0.2', '0', '+0.2']),
            dict(linthresh=20, ticks=[0, 20, 100, 700],
                 lab=['0', '+20', '+100', '+700'])]
    for j, (ax, col, rel, lab) in enumerate([
            (axs[0], 'critical_accuracy', False,
             '$\\Delta$ critical-instant accuracy [points]'),
            (axs[1], 'uplink_mbps', True, '$\\Delta$ uplink traffic [%]')]):
        style(ax, xgrid=True)
        _delta_panel(ax, df, col, rel, lab, order, scen=SCEN)
        ax.set_xscale('symlog', linthresh=scal[j]['linthresh'], linscale=0.7)
        ax.set_xticks(scal[j]['ticks'], labels=scal[j]['lab'])
        ax.get_xaxis().set_minor_locator(matplotlib.ticker.NullLocator())
        ax.grid(axis='y', visible=False)
        ax.set_yticklabels([ABL_SHORT[o] for o in order] if j == 0
                           else [''] * len(order), fontsize=6.6, color=INK)
        ax.margins(x=0.10)
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=SCOL[sc], marker=SMK[sc], ls='none', ms=4,
                label=f'Scenario {sc}') for sc in SCEN]
    h.append(Line2D([], [], color=INK3, lw=0.8, label='CoFA (full)'))
    fig.legend(handles=h, loc='upper center', bbox_to_anchor=(0.5, 1.10),
               ncol=4, handletextpad=0.4, columnspacing=1.6)
    save(fig, 'fig11_ablation')


def within_seed(d, xc, col):
    g = d.copy()
    g['adj'] = g[col] - g.groupby('seed')[col].transform('mean') + g[col].mean()
    mu = g.groupby(xc)['adj'].mean()
    n = g.groupby(xc)['adj'].count()
    k = len(g[xc].unique())
    sd = g.groupby(xc)['adj'].std(ddof=1) * np.sqrt(k / max(k - 1, 1))
    return mu, 1.96 * sd / np.sqrt(n)


def fig_sensitivity():
    """Each control parameter swept alone, on a common pair of rows: what it
    does to decision quality above, what it costs in traffic below.  The two
    quantities were previously stacked into an inset, which made the cost curve
    unreadable; they are given equal room here and share an x-axis, so a knee in
    one can be read against the same abscissa in the other."""
    specs = [('e7a_sens_V.csv', 'p_V', 'queue weight $V$', True),
             ('e7b_sens_theta.csv', 'p_theta_i', 'importance gate $\\theta$', True),
             ('e7c_sens_eta.csv', 'p_eta_floor', 'fidelity floor $\\eta$', True),
             ('e7d_sens_target.csv', 'p_cfs_target', 'meta target $\\phi$', False)]
    TITLES = ['queue weight', 'importance gate', 'fidelity floor',
              'meta target']
    fig, axs = plt.subplots(2, 4, figsize=(W2, 3.05), sharex='col', sharey='row')
    fig.subplots_adjust(wspace=0.10, hspace=0.14)
    for j, (f, col, lab, logx) in enumerate(specs):
        d = pd.read_csv(os.path.join(RES, f))
        lv = sorted(d[col].unique())
        for r, (met, ylab) in enumerate(
                [('critical_accuracy', 'Critical-instant\naccuracy [%]'),
                 ('uplink_mbps', 'Uplink traffic\n[Mb/s]')]):
            ax = style(axs[r, j])
            mu, er = within_seed(d, col, met)
            ax.errorbar(mu.index, mu.values, yerr=er.values,
                        marker='*' if r == 0 else 'o', ms=6 if r == 0 else 3.6,
                        color=GROUP['proposed'], elinewidth=0.7, lw=1.4)
            if logx:
                ax.set_xscale('log')
            # the meta-target levels are closely spaced and all seven labels
            # collide at this width, so every other one is drawn
            keep = lv if len(lv) <= 6 else lv[::2]
            ax.set_xticks(lv, labels=[f'{x:g}' if x in keep else ''
                                      for x in lv])
            ax.get_xaxis().set_minor_locator(matplotlib.ticker.NullLocator())
            ax.margins(x=0.10)
            if r == 0:
                ax.set_ylim(86.2, 89.6)
            if r == 1:
                ax.set_yscale('log')
                ax.set_ylim(5.5, 85)
                ax.set_yticks([8, 10, 20, 40, 60],
                              labels=['8', '10', '20', '40', '60'])
                ax.get_yaxis().set_minor_locator(
                    matplotlib.ticker.NullLocator())
                ax.set_xlabel(lab)
                ax.tick_params(axis='x', labelsize=5.6, labelrotation=45)
                for tl in ax.get_xticklabels():
                    tl.set_ha('right')
                    tl.set_rotation_mode('anchor')
            if j == 0:
                ax.set_ylabel(ylab)
            if r == 0:
                ax.set_title(f'({chr(97 + j)}) {TITLES[j]}', pad=3, fontsize=6.6)
    save(fig, 'fig12_sensitivity')


def fig_robust():
    """The decision model the gate relies on is deliberately mis-specified, by
    rotating the estimated decision boundary away from the true one."""
    d = pd.read_csv(os.path.join(RES, 'e8_robustness.csv'))
    fig, axs = plt.subplots(1, 2, figsize=(W2, 2.35))
    fig.subplots_adjust(wspace=0.26)
    ms = [m for m in ORDER if m in set(d.method)]
    for ax, met, lab, lg in [
            (axs[0], 'critical_accuracy', 'Critical-instant accuracy [%]', False),
            (axs[1], 'uplink_mbps', 'Uplink traffic [Mb/s]', True)]:
        style(ax)
        for m in ms:
            mu, er = within_seed(d[d.method == m], 'p_w_err_deg', met)
            big = m in PROPOSED
            ax.errorbar(mu.index, mu.values, yerr=er.values, marker=MARK[m],
                        ls=DASH[m], color=gcol(m), label=LBL[m],
                        lw=1.8 if big else 1.0, elinewidth=0.6,
                        ms=5.4 if big else 3.6, zorder=4 if big else 3)
            ax.annotate(SHORT[m], (mu.index[-1], mu.values[-1]),
                        textcoords='offset points', xytext=(5, 0), ha='left',
                        va='center', fontsize=6.0, color=INK2)
        if lg:
            ax.set_yscale('log')
        lv = sorted(d.p_w_err_deg.unique())
        ax.set_xticks(lv)
        ax.set_xlabel('angular error of the decision model [deg]')
        ax.set_ylabel(lab)
        ax.set_xlim(lv[0] - 0.04 * lv[-1], lv[-1] * 1.26)   # room for the labels
    group_legend(fig, y=1.02)
    save(fig, 'fig13_robustness')


def fig_dqn():
    """Convergence of both learned baselines, over independent training seeds,
    plus the spread each seed produces on the evaluation block."""
    d = pd.read_csv(os.path.join(RES, 'e0_dqn_convergence.csv'))
    has_seed = 'train_seed' in d.columns
    q = os.path.join(RES, 'e15_drl_seeds.csv')
    has_eval = os.path.exists(q)
    n = 3 if has_eval else 2
    fig, axs = plt.subplots(1, n, figsize=(W2, 2.35))
    fig.subplots_adjust(wspace=0.40)
    for a in axs:
        style(a)
    C = {'DRL (DQN)': gcol('DRL (DQN)'), 'DRL-CF': gcol('DRL-CF')}

    # six curves in one panel need two keys, not six legend entries: colour is
    # the learner and dash is the scenario, so the legend is 2 + 3 short items
    SLS = {'S1': (0, ()), 'S2': (0, (4, 1.4)), 'S3': (0, (1.4, 1.4))}

    # The two learners optimise *different* reward functions - one
    # network-centric, one decision-centric - so their rewards are not on a
    # common scale and plotting the raw values side by side would invite a
    # comparison that means nothing.  The question this panel answers is
    # whether each has converged, so each curve is rescaled to its own range
    # over its own training run and only the shape is read.
    def _norm(v):
        v = np.asarray(v, dtype=float)
        lo, hi = np.nanmin(v), np.nanmax(v)
        return (v - lo) / (hi - lo) if hi > lo else np.zeros_like(v)

    # episode-to-episode reward is dominated by the exploration noise of a
    # single episode; the question here is the trend, so each curve is a
    # centred rolling mean over nine episodes
    def _smooth(v, k=9):
        return pd.Series(np.asarray(v, dtype=float)).rolling(
            k, center=True, min_periods=1).mean().values

    for sc in SCEN:
        for var in ('DRL (DQN)', 'DRL-CF'):
            dd = d[(d.scenario == sc) & (d.variant == var)]
            if has_seed:
                # only the mean over the three training seeds is drawn: the
                # tinted min-max band is gone with the rest of the shading, and
                # replacing it by its two edges put eighteen lines in one
                # panel.  The seed spread is what panel (c) is for, and it
                # shows it exactly rather than as an envelope.
                g = dd.groupby('episode').mean_reward
                axs[0].plot(g.mean().index, _smooth(_norm(g.mean().values)),
                            color=C[var], lw=1.0, ls=SLS[sc])
                ev = dd.dropna(subset=['eval_critical_accuracy'])
                ge = ev.groupby('episode').eval_critical_accuracy
                axs[1].plot(ge.mean().index, _smooth(ge.mean().values, 5),
                            color=C[var], lw=1.0, ls=SLS[sc])
            else:
                axs[0].plot(dd.episode, _smooth(_norm(dd.mean_reward.values)),
                            color=C[var], lw=1.0, ls=SLS[sc])
                ev = dd.dropna(subset=['eval_critical_accuracy'])
                axs[1].plot(ev.episode, ev.eval_critical_accuracy, color=C[var],
                            lw=1.0, ls=SLS[sc])
    axs[0].set_xlabel('training episode')
    axs[0].set_ylabel('own reward, rescaled\nto its own range')
    axs[0].set_title('(a) reward, per policy', pad=4)
    axs[0].set_ylim(-0.06, 1.06)
    axs[1].set_xlabel('training episode')
    axs[1].set_ylabel('held-out critical-instant\naccuracy [%]')
    axs[1].set_title('(b) held-out accuracy', pad=4)
    from matplotlib.lines import Line2D
    key = [Line2D([], [], color=C[v], lw=2.0, label=SHORT.get(v, v))
           for v in ('DRL (DQN)', 'DRL-CF')]
    key += [Line2D([], [], color=INK3, lw=1.0, ls=SLS[sc], label=sc)
            for sc in SCEN]
    fig.legend(handles=key, loc='upper center', bbox_to_anchor=(0.5, 1.09),
               ncol=5, handlelength=2.0, columnspacing=1.3,
               handletextpad=0.4, fontsize=6.4)

    if has_eval:
        e = pd.read_csv(q)
        e['tag'] = e.variant.str.split('|').str[0]
        e['ts'] = e.variant.str.split('|').str[1]
        g = e.groupby(['scenario', 'tag', 'ts']).critical_accuracy.mean().reset_index()
        ax = axs[2]
        xs = np.arange(len(SCEN))
        for i, var in enumerate(('DRL (DQN)', 'DRL-CF')):
            for j, sc in enumerate(SCEN):
                v = g[(g.scenario == sc) & (g.tag == var)].critical_accuracy.values
                x = xs[j] + (i - 0.5) * 0.34
                ax.plot([x] * len(v), v, 'o', color=C[var], ms=3.6)
                ax.plot([x - 0.11, x + 0.11], [v.mean()] * 2, '-', color=C[var],
                        lw=1.4)
        ax.set_xticks(xs, labels=SCEN)
        ax.grid(axis='x', visible=False)
        ax.set_ylabel('critical-instant accuracy [%]')
        ax.set_title('(c) per training seed', pad=4)
        ax.margins(y=0.16)
        top = ax.get_ylim()[1]
        for i, var in enumerate(('DRL (DQN)', 'DRL-CF')):
            ax.text(xs[0] + (i - 0.5) * 0.72, top, SHORT.get(var, var),
                    ha='center', va='top', fontsize=5.8, color=C[var])
    save(fig, 'fig14_dqn_convergence')


def fig_cfs_validation():
    frames = []
    for f in ('e1_main.csv', 'e9_admission.csv', 'e2_load.csv', 'e5_bandwidth.csv'):
        p = os.path.join(RES, f)
        if os.path.exists(p):
            frames.append(pd.read_csv(p))
    d = pd.concat(frames, ignore_index=True)
    fig, axs = plt.subplots(1, 3, figsize=(W2, 2.5),
                            gridspec_kw=dict(width_ratios=[1.0, 0.9, 1.15]))
    fig.subplots_adjust(wspace=0.52)
    for a in axs:
        style(a)
    for m in ORDER:
        dd = d[d.method == m]
        axs[0].scatter(dd.cfs, dd.critical_accuracy, s=1.4,
                       color=gcol(m), edgecolors='none', label=SHORT[m])
    axs[0].set_xlabel('CFS'); axs[0].set_ylabel('Critical-instant accuracy [%]')
    axs[0].set_title('(a) all runs, all policies', pad=4)
    # short names: the middle panel is narrow, and its row labels reach into
    # the panel on its left when spelled out.  The caption carries the full
    # names of the three components.
    parts = [('cfs', 'CFS'), ('cfs_dec', 'decision'),
             ('cfs_sem', 'fidelity'), ('cfs_tmp', 'freshness'),
             ('aoi_mean', 'AoI (neg.)')]
    rs = []
    for col, lab in parts:
        x = -d[col] if col == 'aoi_mean' else d[col]
        rs.append(np.corrcoef(x, d.critical_accuracy)[0, 1])
    # a horizontal bar keeps the five names horizontal and legible; rotated
    # two-line category labels under a vertical bar were unreadable
    lab = [p[1].replace('\n', ' ') for p in parts]
    y = np.arange(len(parts))[::-1]
    # these bars are candidate signals, not policies, so they take no family
    # colour: the composite is the darkest, its three components mid, and the
    # AoI reference lightest
    axs[1].barh(y, rs, 0.62, color=[INK] + [INK2] * 3 + [INK3],
                edgecolor='white', linewidth=0.6)
    axs[1].axvline(0, color=INK3, lw=0.8)
    # the correlations span -0.14 to 0.77, so the small ones are a few pixels
    # long and read as "no bar at all"; each therefore carries its value
    # the value always sits to the right of the bar's outer end for a positive
    # bar and just right of zero for a negative one, so that it can never run
    # into the category label on the left
    span = max(abs(min(rs)), abs(max(rs)))
    pad = 0.030 * span
    for yy, r in zip(y, rs):
        axs[1].text((r if r >= 0 else 0.0) + pad, yy, f'{r:+.2f}',
                    va='center', ha='left', fontsize=5.8, color=INK2)
    axs[1].set_xlim(min(rs) - 0.10 * span, max(rs) + 0.20 * span)
    axs[1].set_yticks(y, labels=lab)
    axs[1].tick_params(axis='y', labelsize=6.4, length=0)
    for tl in axs[1].get_yticklabels():
        tl.set_color(INK)
    axs[1].grid(axis='y', visible=False)
    axs[1].grid(axis='x', color=GRID, lw=0.5)
    axs[1].set_xlabel('Pearson $r$ with\ncritical-instant accuracy')
    axs[1].set_title('(b) each candidate signal', pad=4)

    off = {'CoFA-E': (-5, 4, 'right'), 'CoFA': (5, -4, 'left'),
           'Goal-Oriented': (5, 0, 'left'), 'AoII-Aware': (-5, 0, 'right'),
           'DRL-CF': (5, -2, 'left'), 'UoI-Aware': (5, 3, 'left'),
           'AoI-Aware': (5, 3, 'left'), 'Edge-Only': (-6, -1, 'right'),
           'Latency-Aware': (5, -6, 'left'), 'Semantic-Aware': (-5, 3, 'right'),
           'Cloud-Only': (5, -5, 'left'), 'DRL (DQN)': (5, -1, 'left')}
    for m in ORDER:
        dd = d[d.method == m]
        if len(dd) > 3:
            big = m in PROPOSED
            xy = (dd.cfs.mean(), dd.critical_accuracy.mean())
            axs[2].scatter(*xy, s=34 if big else 20, color=gcol(m),
                           marker=MARK[m], edgecolors='white', linewidths=0.5,
                           zorder=4)
            dx, dy, ha = off.get(m, (4, 3, 'left'))
            axs[2].annotate(SHORT[m], xy, textcoords='offset points',
                            xytext=(dx, dy), ha=ha, fontsize=5.6, color=INK2)
    axs[2].set_xlabel('CFS (policy mean)')
    axs[2].set_ylabel('Critical-instant accuracy [%]')
    axs[2].set_title('(c) policy means', pad=4)
    axs[2].margins(x=0.30, y=0.14)
    group_legend(fig, y=1.06)
    save(fig, 'fig15_cfs_validation')


def fig_cet_validation():
    """Predicted CET against the counterfactual benefit actually realised."""
    import gzip
    f = os.path.join(RES, 'e13_cet_validation.csv')
    df = pd.read_csv(f if os.path.exists(f) else f + '.gz')
    from scipy import stats
    from sklearn.metrics import roc_auc_score

    fig, ax = plt.subplots(1, 3, figsize=(W2, 2.45))
    fig.subplots_adjust(wspace=0.34)
    col, mk = SCOL, SMK
    for a in ax:
        style(a)

    # (a) calibration: binned predicted value against measured contrast
    a = ax[0]
    hi = 0.0
    for sc in SCEN:
        g = df[df.scenario == sc]
        q = np.unique(np.quantile(g.cet_pred[g.cet_pred > 0], np.linspace(0, 1, 9)))
        edges = np.concatenate(([-1e-9, 1e-9], q[1:]))
        idx = np.digitize(g.cet_pred, edges) - 1
        xs, ys = [], []
        for b in range(len(edges) - 1):
            m = idx == b
            if m.sum() < 40:
                continue
            xs.append(g.cet_pred[m].mean())
            ys.append(g.cet_emp[m].mean())
        hi = max(hi, max(xs + ys))
        a.plot(xs, ys, mk[sc] + '-', color=col[sc], ms=3.4, lw=1.2, label=sc)
    a.plot([0, hi], [0, hi], '-', color=INK3, lw=0.9, zorder=0)
    a.text(hi * 0.60, hi * 0.92, 'perfect calibration', fontsize=5.8,
           color=INK2, rotation=0)
    a.set_xlabel('predicted CET'); a.set_ylabel('measured contrast')
    a.set_title('(a) calibration', pad=4)
    a.legend(frameon=False, loc='upper left', handlelength=1.4)

    # (b) how far ahead the estimate stays informative
    b = ax[1]
    hs = [0, 5, 10, 20]
    for sc in SCEN:
        g = df[df.scenario == sc]
        r = [stats.spearmanr(g[f'pred_h{h}'],
                             (g[f'sup_h{h}'] - g[f'tx_h{h}']).clip(lower=0)
                             ).statistic for h in hs]
        b.plot([h * 10 for h in hs], r, mk[sc] + '-', color=col[sc], ms=3.6, lw=1.3,
               label=sc)
    b.axhline(0, color=INK3, lw=0.8)
    b.set_xlabel('look-ahead horizon [ms]')
    b.set_ylabel(r'Spearman $\rho$')
    b.set_title('(b) informativeness by horizon', pad=4)

    # (c) detecting the updates that actually matter, at a look-ahead.
    # A bar whose informative range is 0.5-1.0 has to be cut off at the
    # bottom to be readable, and a cut-off bar misstates its own ratio; the
    # comparison is therefore drawn as positions against the chance line.
    c = ax[2]
    SIG = [('CET', 'cet_pred'), ('present risk', 'p_now'), ('AoII', 'aoii'),
           ('mismatch', 'mismatch'), ('distortion', 'dist'), ('AoI', 'aoi')]
    y = np.arange(len(SIG))[::-1]
    c.axvline(0.5, color=INK3, lw=0.8, ls=(0, (2, 2)), zorder=2)
    for i, sc in enumerate(SCEN):
        g = df[df.scenario == sc]
        v = [roc_auc_score(g.critical_ahead, g[cc]) for _, cc in SIG]
        c.plot(v, y + (1 - i) * 0.22, mk[sc], color=col[sc], ms=3.8,
               ls='none', label=sc, zorder=4)
    c.set_yticks(y)
    c.set_yticklabels([n for n, _ in SIG], fontsize=6.4, color=INK)
    c.grid(axis='y', visible=False)
    c.grid(axis='x', color=GRID, lw=0.5)
    c.set_ylim(-0.7, len(SIG) - 0.3)
    c.set_xlabel('AUC, future decision flip')
    c.set_xlim(0.47, 0.98)
    c.text(0.5, len(SIG) - 0.55, ' chance', fontsize=5.8, color=INK2,
           ha='left', va='center')          # the scenario key is in panel (a)
    c.set_title('(c) detecting a future flip', pad=4)
    save(fig, 'fig17_cet_validation')


def fig_cdf():
    import sys, pickle
    sys.path.insert(0, HERE)
    from scenarios import cfg_for
    from cofa import Simulator
    from run_experiments import make_policy
    fig, ax = plt.subplots(figsize=(W1, 2.55))
    style(ax, xgrid=True)
    ends = {}
    for m in ORDER:
        lat = []
        for sd in (1, 2, 3):
            cfg = cfg_for('S1', seed=sd, T=14.0,
                          **({'cfs_target': 0.93} if m == 'CoFA-E' else {}))
            s = Simulator(cfg, make_policy(m, cfg, 'S1'))
            s.run()
            lat += [1000 * v for v in s.lat_crit]
        if not lat:
            continue
        lat = np.sort(np.array(lat))
        cdf = np.arange(1, len(lat) + 1) / len(lat)
        big = m in PROPOSED
        ax.plot(lat, cdf, color=gcol(m), ls=DASH[m], label=LBL[m],
                lw=1.8 if big else 0.9, zorder=4 if big else 3)
        ends[m] = (lat, cdf)
    ax.axvline(20, color=INK2, lw=0.8, ls=(0, (2, 2)), zorder=2)
    ax.text(20.8, 0.04, 'deadline', fontsize=6.0, color=INK2)

    # Every curve rises inside the first few milliseconds, so on a linear axis
    # a label set beside its own curve lands on top of four others and reads as
    # naming one of them - which is exactly what it did.  Two things fix it:
    # the axis is logarithmic, which spreads the crowded decade out, and each
    # label is tied to the point it names by a leader line, so the reading of
    # the figure no longer depends on which curve the text happens to cover.
    lead = dict(arrowstyle='-', lw=0.55, color=INK3,
                shrinkA=0.5, shrinkB=1.5)
    # every label is placed inside the axes: the previous CoFA-E offset put its
    # text on top of the y tick labels
    for m, q, dx, dy in [('CoFA', 0.66, 30, 14), ('CoFA-E', 0.30, 34, -12),
                         ('AoII-Aware', 0.97, -16, 13), ('Edge-Only', 0.42, 22, -16),
                         ('AoI-Aware', 0.74, 24, 12), ('Cloud-Only', 0.50, -6, -22)]:
        if m not in ends:
            continue
        lat, cdf = ends[m]
        ax.annotate(SHORT[m], (float(np.interp(q, cdf, lat)), q),
                    textcoords='offset points', xytext=(dx, dy),
                    fontsize=6.0, color=INK2,
                    ha='right' if dx < 0 else 'left', va='center',
                    arrowprops=lead,
                    bbox=dict(fc='white', ec='none', pad=0.8))
    ax.set_xscale('log')
    ax.set_xlim(0.9, 60)
    ax.set_xticks([1, 2, 5, 10, 20, 50], labels=['1', '2', '5', '10', '20', '50'])
    ax.get_xaxis().set_minor_locator(matplotlib.ticker.NullLocator())
    ax.set_ylim(0, 1.10)
    ax.set_yticks([0, .2, .4, .6, .8, 1.0])
    ax.set_xlabel('latency of causally critical updates [ms]')
    ax.set_ylabel('empirical CDF')
    group_legend(fig, y=1.0)
    save(fig, 'fig5_cdf')


if __name__ == '__main__':
    print('figures:')
    fig_architecture()
    fig_methodology()
    try:
        fig_trace()
    except Exception as e:
        print('  trace skipped', e)
    m = pd.read_csv(os.path.join(RES, 'e1_main.csv'))
    fig_main_bars(m)
    fig_pareto(m)
    for f, xc, xl, nm, xd in [
            ('e2_load.csv', 'p_n_users', 'number of concurrent users', 'fig6_load', 1.0),
            ('e3_mobility.csv', 'p_v_max', 'maximum user speed [m/s]', 'fig7_mobility', 1.0),
            ('e4_loss.csv', 'p_p_loss_base', 'residual packet erasure rate', 'fig8_loss', 1.0),
            ('e5_bandwidth.csv', 'p_bw_bs', 'bandwidth per cell [MHz]',
             'fig9_bandwidth', 1e6)]:
        p = os.path.join(RES, f)
        if os.path.exists(p):
            sweep(pd.read_csv(p), xc, xl, nm, xdiv=xd)
    if os.path.exists(os.path.join(RES, 'e9_admission.csv')):
        fig_admission()
    if os.path.exists(os.path.join(RES, 'e6_ablation.csv')):
        fig_ablation(pd.read_csv(os.path.join(RES, 'e6_ablation.csv')))
    if os.path.exists(os.path.join(RES, 'e7d_sens_target.csv')):
        fig_sensitivity()
    if os.path.exists(os.path.join(RES, 'e8_robustness.csv')):
        fig_robust()
    if os.path.exists(os.path.join(RES, 'e0_dqn_convergence.csv')):
        fig_dqn()
    fig_cfs_validation()
    fig_cet_validation()
    fig_cdf()
    print('done')
