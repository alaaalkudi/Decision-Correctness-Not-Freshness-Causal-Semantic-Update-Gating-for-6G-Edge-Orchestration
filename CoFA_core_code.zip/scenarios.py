import os

from cofa import Config

# S1 - dense immersive collaboration (pedestrian, linear-Gaussian context)
S1 = dict(T=20.0, n_users=100, area=600.0, v_min=0.8, v_max=2.2,
          bw_bs=100e6, max_conc=10, model='lin', head='linear', d=4,
          p_event=0.008, event_mag=1.35, p_loss_base=0.02,
          cycles_update=4.0e7, trans_rate=0.60)

# S2 - remotely embodied teleoperation (vehicular speed, safety critical)
S2 = dict(T=20.0, n_users=60, area=900.0, v_min=5.0, v_max=15.0,
          bw_bs=80e6, max_conc=8, model='lin', head='linear', d=4,
          p_event=0.016, event_mag=1.65, p_loss_base=0.05,
          cycles_update=6.0e7, trans_rate=0.90,
          mig_delay=0.025, ho_gap=0.035)

# S3 - non-linear XR head-pose / attention context with an MLP decision head.
# The latent process is non-Gaussian (heavy-tailed innovations, saccadic jumps),
# non-linear (physiological rate saturation, discrete attention switches), and
# the orchestrator only has a least-squares linear surrogate of its dynamics.
S3 = dict(T=20.0, n_users=80, area=700.0, v_min=0.6, v_max=1.8,
          bw_bs=100e6, max_conc=10, model='pose', head='mlp',
          p_loss_base=0.03, cycles_update=5.0e7, trans_rate=0.80,
          sem_thresh=0.35)

# S1C - admission-limited regime: the per-cell concurrency constraint binds,
# so the drift-plus-penalty ranking is actually exercised.
S1C = dict(S1)
S1C.update(n_users=160, max_conc=3, bw_bs=60e6)

# S1D - severely admission-limited: demand from the causal gate exceeds the
# per-cell service capacity, so the drift-plus-penalty ranking binds.
S1D = dict(S1)
S1D.update(n_users=200, max_conc=1, bw_bs=40e6)

# S4 - the same non-linear XR setting driven by a RECORDED trace instead of the
# generative pose model.  It is active only when a trace has been converted by
# sim/make_trace.py; `cfg_for` raises otherwise, so the campaign silently skips
# it rather than reporting a scenario that was never run.
TRACE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..',
                     'traces', 'trace.npy')
S4 = dict(T=20.0, n_users=80, area=700.0, v_min=0.6, v_max=1.8,
          bw_bs=100e6, max_conc=10, model='trace', head='mlp',
          trace_path=TRACE, p_loss_base=0.03, cycles_update=5.0e7,
          trans_rate=0.80, sem_thresh=0.35)

SCEN = {"S1": S1, "S2": S2, "S3": S3, "S1C": S1C, "S1D": S1D, "S4": S4}
HAVE_TRACE = os.path.exists(TRACE)


def cfg_for(scen, seed=0, **over):
    d = dict(SCEN[scen])
    d.update(over)
    d['seed'] = seed
    return Config(**d)
