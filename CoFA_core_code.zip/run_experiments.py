"""Full experimental campaign (revision 2)."""
from __future__ import annotations
import os, sys, time, pickle
import numpy as np
import pandas as pd
from multiprocessing import Pool

from cofa import Config, Simulator
from scenarios import cfg_for
import policies as P
from dqn import DQNPolicy, MLP, SDIM, ADIM

RES = os.path.join(os.path.dirname(__file__), '..', 'results')
os.makedirs(RES, exist_ok=True)

METHODS = ["Cloud-Only", "Edge-Only", "Latency-Aware", "AoI-Aware",
           "AoII-Aware", "UoI-Aware", "DRL (DQN)", "DRL-CF",
           "Semantic-Aware", "Goal-Oriented", "CoFA", "CoFA-E"]
BASE = METHODS[:10]

_NETS = None
_NETS_ALL = None


def _load(fname):
    raw = pickle.load(open(os.path.join(os.path.dirname(__file__), fname), 'rb'))
    out = {}
    for k, (W, b) in raw.items():
        n = MLP(SDIM, ADIM, seed=0)
        n.W, n.b = W, b
        out[k] = n
    return out


def _nets():
    global _NETS
    if _NETS is None:
        _NETS = _load('dqn_nets.pkl')
    return _NETS


def _nets_all():
    """Every training seed, for the training-seed study."""
    global _NETS_ALL
    if _NETS_ALL is None:
        _NETS_ALL = _load('dqn_nets_all.pkl')
    return _NETS_ALL


CLS = {"Cloud-Only": P.CloudOnly, "Edge-Only": P.EdgeOnly,
       "Latency-Aware": P.LatencyAware, "AoI-Aware": P.AoIScheduler,
       "AoII-Aware": P.AoIIScheduler, "UoI-Aware": P.UoIScheduler,
       "Semantic-Aware": P.SemanticTrig, "Goal-Oriented": P.GoalOriented}


def make_policy(name, cfg, scen, **kw):
    base_scen = 'S1' if scen in ('S1C', 'S1D') else scen
    if name in CLS:
        return CLS[name](cfg)
    if name in ("DRL (DQN)", "DRL-CF"):
        rw = 'decision' if name == 'DRL-CF' else 'qos'
        ts = kw.pop('train_seed', None)
        net = (_nets_all()[f'{base_scen}|{rw}|{ts}'] if ts is not None
               else _nets()[f'{base_scen}|{rw}'])
        return DQNPolicy(cfg, net=net, train=False, seed=3, reward=rw)
    if name in ("CoFA", "CoFA-E"):
        return P.CoFA(cfg, **kw)
    raise KeyError(name)


KEYS = ['decision_accuracy', 'critical_accuracy', 'cfs', 'cfs_dec', 'cfs_sem',
        'cfs_tmp', 'aoc_mean', 'aoc_p95', 'aoi_mean', 'latency_mean',
        'latency_p99', 'crit_latency_mean', 'crit_latency_p99', 'crit_miss',
        'scdd', 'crit_generated', 'restore_mean', 'restore_p99', 'restore_le20',
        'uplink_mbps', 'update_rate', 'energy_mj', 'handovers', 'migrations',
        'prewarm_mbps', 'orch_us', 'crit_frac', 'p_with_mean']


def one(job):
    exp, scen, method, seed, over, kw = job
    kw = dict(kw)
    if method == "CoFA-E":
        over = dict(over)
        over.setdefault('cfs_target', 0.93)
    cfg = cfg_for(scen, seed=seed, **over)
    r = Simulator(cfg, make_policy(method, cfg, scen, **kw), scenario=scen).run()
    row = dict(exp=exp, scenario=scen, method=method, seed=seed)
    row.update({k: r[k] for k in KEYS})
    row.update({('p_' + k): v for k, v in over.items()})
    row.update({('a_' + k): v for k, v in kw.items()})
    return row


NPROC = int(os.environ.get('SIM_NPROC', '2'))


def run(jobs, tag, nproc=None):
    nproc = NPROC if nproc is None else nproc
    t0 = time.time()
    with Pool(nproc) as p:
        rows = p.map(one, jobs, chunksize=1)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, f'{tag}.csv'), index=False)
    print(f'[{tag}] {len(rows)} runs in {time.time()-t0:.0f}s', flush=True)
    return df


ABL = {
    'CoFA (full)': {},
    'w/o causal importance': dict(use_cet=False),
    'w/o AoC (AoI instead)': dict(use_aoc=False),
    'w/o adaptive meta-agent': dict(use_adapt=False),
    'w/o predictive migration': dict(use_predho=False),
    'w/o adaptive fidelity level': dict(use_level=False),
    'w/o placement agent': dict(use_place=False),
}


if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'all'
    S20 = list(range(1, 21))
    S6 = list(range(1, 7))
    S8 = list(range(1, 9))
    TUNE = list(range(101, 109))      # tuning seeds, disjoint from 1-20

    if which in ('all', 'main'):
        run([('main', sc, m, sd, {}, {})
             for sc in ('S1', 'S2', 'S3') for m in METHODS for sd in S20],
            'e1_main')

    if which in ('all', 'adm'):
        run([('adm', 'S1C', m, sd, {}, {}) for m in METHODS for sd in S20],
            'e9_admission')
        jobs, names = [], []
        for vn, kw in ABL.items():
            for sd in list(range(1, 13)):
                jobs.append(('admabl', 'S1C', 'CoFA', sd, {}, kw))
                names.append(vn)
        df = run(jobs, 'e9b_admission_ablation_raw')
        df['variant'] = names
        df.to_csv(os.path.join(RES, 'e9b_admission_ablation.csv'), index=False)
        run([('admV', 'S1C', 'CoFA', sd, dict(V=v), {})
             for v in (0.1, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0)
             for sd in list(range(1, 11))], 'e10_sens_V_admission')

    if which in ('all', 'load'):
        run([('load', 'S1', m, sd, dict(n_users=n), {})
             for n in (40, 80, 120, 160, 200) for m in METHODS for sd in S6],
            'e2_load')

    if which in ('all', 'mob'):
        run([('mob', 'S2', m, sd, dict(v_min=max(v - 4, 0.5), v_max=v), {})
             for v in (2, 6, 10, 15, 25) for m in METHODS for sd in S6],
            'e3_mobility')

    if which in ('all', 'loss'):
        run([('loss', 'S1', m, sd, dict(p_loss_base=pl), {})
             for pl in (0.0, 0.05, 0.10, 0.20) for m in METHODS for sd in S6],
            'e4_loss')

    if which in ('all', 'bw'):
        run([('bw', 'S1', m, sd, dict(bw_bs=b * 1e6, max_conc=max(int(b / 10), 3)), {})
             for b in (20, 40, 60, 80, 100) for m in METHODS for sd in S6],
            'e5_bandwidth')

    if which in ('all', 'abl'):
        jobs, names = [], []
        for sc in ('S1', 'S2', 'S3'):
            for vn, kw in ABL.items():
                for sd in S20:
                    jobs.append(('abl', sc, 'CoFA', sd, {}, kw))
                    names.append(vn)
        df = run(jobs, 'e6_ablation_raw')
        df['variant'] = names
        df.to_csv(os.path.join(RES, 'e6_ablation.csv'), index=False)

    # The four parameter studies run on a TUNING seed block that is disjoint
    # from the evaluation seeds (1-20), so the operating point is not selected
    # on the seeds the comparison is reported on.
    if which in ('all', 'sens'):
        run([('sensV', 'S1', 'CoFA', sd, dict(V=v), {})
             for v in (0.25, 0.5, 1.0, 2.0, 4.0, 8.0) for sd in TUNE], 'e7a_sens_V')
        run([('sensT', 'S1', 'CoFA', sd, dict(theta_i=th), {})
             for th in (0.001, 0.0025, 0.005, 0.01, 0.02, 0.05) for sd in TUNE],
            'e7b_sens_theta')
        run([('sensE', 'S1', 'CoFA', sd, dict(eta_floor=e), {})
             for e in (0.05, 0.10, 0.20, 0.30, 0.60, 1.20) for sd in TUNE],
            'e7c_sens_eta')
        run([('sensF', 'S1', 'CoFA', sd, dict(cfs_target=f), {})
             for f in (0.90, 0.93, 0.95, 0.965, 0.975, 0.985, 0.992) for sd in TUNE],
            'e7d_sens_target')

    # ---- revision 5 -------------------------------------------------------
    # (a) the look-ahead set is a design choice; the CET validation shows its
    #     far terms are weakly informative under linearisation, so its effect
    #     on the closed loop is measured directly.
    if which in ('all', 'hor'):
        HS = {'h0': (0,), 'h0_5': (0, 5), 'h0_10': (0, 5, 10),
              'h0_20': (0, 5, 10, 20), 'h0_40': (0, 5, 10, 20, 40)}
        jobs, names = [], []
        for sc in ('S1', 'S3'):
            for nm, hh in HS.items():
                # the look-ahead study runs on the full evaluation block, so
                # that its numbers are directly comparable with the main
                # comparison rather than differing by the seed block
                for sd in list(range(1, 21)):
                    jobs.append(('hor', sc, 'CoFA', sd, dict(horizons=hh), {}))
                    names.append(nm)
        df = run(jobs, 'e14_horizons_raw')
        df['hset'] = names
        df.to_csv(os.path.join(RES, 'e14_horizons.csv'), index=False)

    # (b) AoC and AoI enter the ranking with different units, so comparing them
    #     at a single V is not like-for-like; each backlog gets its own V sweep
    #     in the regime where the ranking actually binds.
    if which in ('all', 'aoiv'):
        jobs, names = [], []
        for use_aoc in (True, False):
            for v in (0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0, 128.0):
                for sd in list(range(1, 13)):
                    jobs.append(('aoiv', 'S1D', 'CoFA', sd, dict(V=v),
                                 dict(use_aoc=use_aoc)))
                    names.append('AoC' if use_aoc else 'AoI')
        df = run(jobs, 'e16_backlog_v_raw')
        df['backlog'] = names
        df.to_csv(os.path.join(RES, 'e16_backlog_v.csv'), index=False)

    # (c) the interference proxy is decoupled from the neighbours' scheduling;
    #     the ordering is re-measured under an uplink model in which it is not
    if which in ('all', 'intf'):
        run([('intf', 'S1', m, sd, dict(intf_model='sched'), {})
             for m in METHODS for sd in list(range(1, 13))], 'e18_interference_sched')

    # (c) every training seed of both learned policies, on the evaluation seeds
    if which in ('all', 'drlseeds'):
        import itertools
        jobs, names = [], []
        for sc in ('S1', 'S2', 'S3'):
            for rw, tag in (('qos', 'DRL (DQN)'), ('decision', 'DRL-CF')):
                for ts in (7, 23, 41):
                    for sd in S20:
                        jobs.append(('drlseed', sc, tag, sd, {},
                                     dict(train_seed=ts)))
                        names.append(f'{tag}|{ts}')
        df = run(jobs, 'e15_drl_seeds_raw')
        df['variant'] = names
        df.to_csv(os.path.join(RES, 'e15_drl_seeds.csv'), index=False)

    if which in ('all', 'rob'):
        run([('rob', 'S1', m, sd, dict(w_err_deg=w), {})
             for w in (0, 10, 20, 30, 45)
             for m in ('CoFA', 'Goal-Oriented', 'AoI-Aware', 'AoII-Aware')
             for sd in list(range(1, 11))], 'e8_robustness')

    print('ALL DONE', flush=True)
