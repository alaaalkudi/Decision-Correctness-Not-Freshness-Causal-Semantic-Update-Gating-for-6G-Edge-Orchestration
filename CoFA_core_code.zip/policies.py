"""Orchestration policies: the proposed CoFA plus nine baselines."""
from __future__ import annotations
import numpy as np


# ----------------------------------------------------------------------------
def _lvl_arrays(sim):
    c = sim.cfg
    return (np.array([l[0] for l in c.levels]) * c.B0,
            np.array([l[1] for l in c.levels]))


def _est_latency(sim, t, sinr_db, bits):
    """Estimated completion latency per user at the serving edge and the cloud."""
    c = sim.cfg
    nb = np.bincount(sim.serv[sim.tx_active], minlength=c.n_bs) + 1
    share = c.bw_bs / nb[sim.serv]
    S, I = sim._powers()
    rate = share * np.log2(1 + sim.sinr_at(S, I, share))
    t_tx = bits / np.maximum(rate, 1e3)
    q_edge = np.maximum(sim.node_free[:c.n_bs] - t, 0.0)[sim.serv]
    l_edge = t_tx + q_edge + c.cycles_update / sim.f_edge[sim.serv]
    q_cloud = max(sim.node_free[c.n_bs] - t, 0.0)
    l_cloud = t_tx + c.bh_delay + q_cloud + c.cycles_update / c.f_cloud + c.bh_delay
    return l_edge, l_cloud, t_tx


def _proj_err(sim):
    """|w_loc . (x - xhat)| : estimation error in the decision-relevant direction."""
    W = sim.head.wloc(sim.x)
    return np.abs(np.einsum('ij,ij->i', sim.x - sim.xh, W))


class Base:
    name = "base"

    def __init__(self, cfg):
        self.cfg = cfg
        self.last_score = None

    def _empty(self, sim):
        self.last_score = np.zeros(sim.N)
        return (np.zeros(sim.N, dtype=bool),
                np.full(sim.N, len(self.cfg.levels) - 1, dtype=np.int64),
                sim.serv.copy())


# ----------------------------------------------------------------------------
# Network-centric baselines
# ----------------------------------------------------------------------------
class CloudOnly(Base):
    name = "Cloud-Only"

    def decide(self, sim, t, it, cet, margin, mismatch, sinr_db, free):
        sel, lvl, tgt = self._empty(sim)
        sel = (sim.age_slots >= self.cfg.period_slots) & free
        self.last_score = sim.age_slots.astype(float)
        return sel, lvl, np.full(sim.N, -1, dtype=np.int64)


class EdgeOnly(Base):
    name = "Edge-Only"

    def decide(self, sim, t, it, cet, margin, mismatch, sinr_db, free):
        sel, lvl, tgt = self._empty(sim)
        sel = (sim.age_slots >= self.cfg.period_slots) & free
        self.last_score = sim.age_slots.astype(float)
        return sel, lvl, sim.serv.copy()


class LatencyAware(Base):
    """Greedy min-latency offloading (canonical QoS heuristic)."""
    name = "Latency-Aware"

    def decide(self, sim, t, it, cet, margin, mismatch, sinr_db, free):
        c = self.cfg
        lb, _ = _lvl_arrays(sim)
        sel, lvl, tgt = self._empty(sim)
        sel = (sim.age_slots >= c.period_slots) & free
        l_edge, l_cloud, _ = _est_latency(sim, t, sinr_db, lb[-1])
        tgt = np.where(l_cloud < l_edge, -1, sim.serv)
        self.last_score = -np.minimum(l_edge, l_cloud)
        return sel, lvl, tgt.astype(np.int64)


class AoIScheduler(Base):
    """Max-age-first scheduling (AoI-optimal family)."""
    name = "AoI-Aware"

    def decide(self, sim, t, it, cet, margin, mismatch, sinr_db, free):
        c = self.cfg
        sel, lvl, tgt = self._empty(sim)
        k = c.max_conc * c.n_bs
        idx = np.argsort(-sim.aoi)[:k]
        sel = np.zeros(sim.N, dtype=bool)
        sel[idx] = True
        sel &= free & (sim.age_slots >= 2)
        self.last_score = sim.aoi
        return sel, lvl, sim.serv.copy()


# ----------------------------------------------------------------------------
# Freshness-of-meaning / goal-oriented baselines
# ----------------------------------------------------------------------------
class AoIIScheduler(Base):
    """Age of Incorrect Information: transmit only while the receiver's decision
    is wrong, prioritised by accumulated incorrectness (purely reactive)."""
    name = "AoII-Aware"

    def decide(self, sim, t, it, cet, margin, mismatch, sinr_db, free):
        sel, lvl, tgt = self._empty(sim)
        sel = mismatch & free & (sim.age_slots >= 1)
        self.last_score = sim.aoii
        return sel, lvl, sim.serv.copy()


class UoIScheduler(Base):
    """Urgency of Information: age weighted by an exogenous context weight, here
    the inverse decision margin (decision-aware but not innovation-aware)."""
    name = "UoI-Aware"

    def decide(self, sim, t, it, cet, margin, mismatch, sinr_db, free):
        c = self.cfg
        sel, lvl, tgt = self._empty(sim)
        score = sim.aoi / (margin + 0.10)
        sel = (score > c.uoi_thresh) & free & (sim.age_slots >= 1)
        self.last_score = score
        return sel, lvl, sim.serv.copy()


class SemanticTrig(Base):
    """Distortion-triggered transmission in signal space."""
    name = "Semantic-Aware"

    def decide(self, sim, t, it, cet, margin, mismatch, sinr_db, free):
        c = self.cfg
        sel, lvl, tgt = self._empty(sim)
        err = np.linalg.norm(sim.x - sim.xh, axis=1)
        thr = c.sem_thresh * sim.xscale * np.sqrt(sim.d)
        sel = (err > thr) & free & (sim.age_slots >= 2)
        lvl = np.where(err > 2 * thr, len(c.levels) - 1, 1).astype(np.int64)
        self.last_score = err
        return sel, lvl, sim.serv.copy()


class GoalOriented(Base):
    """Strong goal-oriented scheduler: transmits when the *current* estimated
    decision-error probability exceeds a threshold, prioritised by it. It uses
    the same decision model as CoFA but no interventional contrast and no
    look-ahead, so it reacts to present risk rather than to the causal effect of
    transmitting."""
    name = "Goal-Oriented"

    def decide(self, sim, t, it, cet, margin, mismatch, sinr_db, free):
        c = self.cfg
        _, ls = _lvl_arrays(sim)
        sel, lvl, tgt = self._empty(sim)
        p = sim.p_err_now()
        sel = ((p > c.goal_thresh) | mismatch) & free & (sim.age_slots >= 1)
        need = margin / 1.5
        lvl = np.full(sim.N, len(c.levels) - 1, dtype=np.int64)
        for j in range(len(c.levels) - 1, -1, -1):
            lvl = np.where(ls[j] <= need, j, lvl)
        lvl = np.maximum(np.where(mismatch, len(c.levels) - 1, lvl), 1)
        self.last_score = p
        return sel, lvl.astype(np.int64), sim.serv.copy()


# ----------------------------------------------------------------------------
# Proposed
# ----------------------------------------------------------------------------
class CoFA(Base):
    name = "CoFA"

    def __init__(self, cfg, use_cet=True, use_aoc=True, use_adapt=True,
                 use_predho=True, use_level=True, use_place=True):
        super().__init__(cfg)
        self.use_cet, self.use_aoc = use_cet, use_aoc
        self.use_adapt, self.use_predho = use_adapt, use_predho
        self.use_level, self.use_place = use_level, use_place
        self.V = cfg.V
        self.theta = cfg.theta_i
        self.eta = cfg.eta_floor
        self.m_ref = None
        self.cfs_ewma = cfg.cfs_target

    def decide(self, sim, t, it, cet, margin, mismatch, sinr_db, free):
        c = self.cfg
        lb, ls = _lvl_arrays(sim)
        N = sim.N

        # (a) semantic fidelity level, matched to the local decision margin
        if self.use_level:
            need = margin / getattr(self, 'kk', 1.5)
            lvl = np.full(N, len(c.levels) - 1, dtype=np.int64)
            for j in range(len(c.levels) - 1, -1, -1):
                lvl = np.where(ls[j] <= need, j, lvl)
            lvl = np.where(mismatch, len(c.levels) - 1, lvl)
            lvl = np.maximum(lvl, getattr(self, 'minlvl', 1))
        else:
            lvl = np.full(N, len(c.levels) - 1, dtype=np.int64)
        bits = lb[lvl]

        # (b) placement
        l_edge, l_cloud, _ = _est_latency(sim, t, sinr_db, bits)
        tgt = (np.where(l_cloud < l_edge, -1, sim.serv) if self.use_place
               else sim.serv.copy()).astype(np.int64)

        # (c) predictive pre-migration
        if self.use_predho:
            rsrp = sim._rsrp_dbm()
            best = np.argmax(rsrp, axis=1)
            gap = rsrp[np.arange(N), best] - rsrp[np.arange(N), sim.serv]
            soon = (best != sim.serv) & (gap > c.ho_hyst_db * 0.45)
            if soon.any():
                sim.request_prewarm(soon, best, t)
        else:
            soon = np.zeros(N, dtype=bool)

        # (d) drift-plus-penalty ranking
        aoc = sim.aoc if self.use_aoc else sim.aoi
        imp = cet if self.use_cet else np.full(N, 0.05)
        lat = np.where(tgt < 0, l_cloud, l_edge)
        pdel = 1.0 / (1.0 + np.exp(-sinr_db / 3.0))
        score = (aoc + self.V * imp) * pdel / (bits / c.B0) / np.maximum(lat / 0.02, 0.5)
        score = np.where(soon, score * 1.4, score)

        # (e) causal gate with a representational-fidelity floor that is
        #     relative to the local margin but bounded away from zero by the
        #     typical margin of the task, so that near-boundary users are
        #     governed by the causal term rather than by the floor
        if self.m_ref is None:
            self.m_ref = float(np.median(margin))
        else:
            self.m_ref = 0.999 * self.m_ref + 0.001 * float(np.median(margin))
        derr = _proj_err(sim)
        gate = (imp > self.theta) | mismatch | (derr > self.eta * (margin + self.m_ref))
        sel = gate & free & (sim.age_slots >= 1)
        self.last_score = score
        return sel, lvl, tgt

    def post_step(self, sim, t, it):
        if not self.use_adapt or it % 25 != 0:
            return
        c = self.cfg
        self.cfs_ewma = 0.9 * self.cfs_ewma + 0.1 * float(sim._cfs().mean())
        util = float(sim.tx_active.mean())
        if self.cfs_ewma < c.cfs_target and util < 0.55:
            self.theta = max(self.theta * 0.90, 1e-4)
            self.eta = max(self.eta * 0.97, 0.04)
            self.V = min(self.V * 1.05, 12.0)
        elif util > 0.75 or self.cfs_ewma > c.cfs_target + 0.03:
            self.theta = min(self.theta * 1.10, 0.25)
            self.eta = min(self.eta * 1.03, 3.0)
            self.V = max(self.V * 0.97, 0.3)
