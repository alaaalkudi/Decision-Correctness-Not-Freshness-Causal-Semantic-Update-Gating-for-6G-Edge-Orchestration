"""
Decision-centric edge orchestration for 6G immersive applications.
Slotted system-level simulator with strict common random numbers.

Design notes (revision 2):
  * Common random numbers. The latent state trajectory, the mobility and
    shadowing realisation, the per-(user,slot) erasure draws, the
    reconstruction-noise draws and the backhaul jitter are all pre-generated
    from dedicated streams indexed by the seed alone. Every policy therefore
    experiences a bit-identical environment realisation.
  * Decision heads are pluggable: a linear margin rule (scenarios S1/S2) and a
    non-linear MLP head (scenario S3). The importance estimator uses the local
    boundary normal, so it is defined for both.
  * The Causal Effect of Transmission propagates the reconstruction noise
    through the dynamics, i.e. the post-update projected variance at horizon h
    is S_h + s_l^2 ||A^h' w||^2.
  * Reliability is measured over *generated* critical updates (an erased update
    counts as a miss) and, policy-independently, as the decision-restoration
    delay after each ground-truth decision transition.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from scipy.special import ndtr
import time

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------

@dataclass
class Config:
    # --- simulation ---
    T: float = 20.0
    dt: float = 0.010
    seed: int = 0
    warmup: float = 2.0

    # --- topology ---
    area: float = 600.0
    n_bs: int = 7
    n_users: int = 100

    # --- mobility ---
    v_min: float = 0.8
    v_max: float = 2.2
    pause_p: float = 0.002

    # --- radio ---
    fc_GHz: float = 28.0
    bw_bs: float = 100e6
    max_conc: int = 10
    p_tx_dbm: float = 23.0
    ant_gain_db: float = 30.0
    nf_db: float = 7.0
    shadow_db: float = 7.8
    ho_hyst_db: float = 4.0
    ttt: float = 0.100
    ho_gap: float = 0.030
    p_loss_base: float = 0.02

    # --- compute ---
    f_edge: float = 25e9
    f_cloud: float = 250e9
    f_local: float = 1.0e9
    kappa: float = 1e-28
    cycles_update: float = 4.0e7
    bh_delay: float = 0.012
    bh_jit: float = 0.004
    mig_delay: float = 0.020

    # --- semantic payload levels: (bit fraction, reconstruction std) ---
    B0: float = 40e3
    levels: tuple = ((0.15, 0.55), (0.40, 0.28), (1.00, 0.08))

    # --- application / cognitive state ---
    model: str = "lin"              # "lin", "pose", or "trace" (recorded)
    trace_path: str = ""            # .npy of shape (K+1, N, d) for model="trace"
    head: str = "linear"            # "linear" or "mlp"
    d: int = 4
    rho: float = 0.992
    sigma_w: float = 0.055
    p_event: float = 0.008
    event_mag: float = 1.35
    theta_c: float = 0.85
    theta_q: float = 1.0            # >0 enables decision-threshold calibration
    trans_rate: float = 0.60        # target decision transitions [1/s/user]

    # --- pose model (scenario S3) ---
    sac_rate: float = 0.012         # saccade rate per slot
    sac_mag: float = 3.2            # saccadic angular-rate impulse [rad/s]
    ou_a: float = 0.972
    ou_s: float = 0.16
    t_df: float = 3.0               # Student-t degrees of freedom (heavy tails)
    rate_max: float = 6.0           # physiological angular-rate limit [rad/s]
    tgt_rate: float = 0.004         # attention-target switch rate per slot

    # --- CFS ---
    a_dec: float = 0.5
    a_sem: float = 0.3
    a_tmp: float = 0.2
    sigma_s: float = 1.00
    tau_a: float = 1.20
    psi0: float = 0.005

    # --- interference model ---
    # 'geom'  : a geometry-only proxy, independent of the neighbouring cells'
    #           scheduling, so every policy sees a bit-identical channel
    #           (the default, and what strict common random numbers requires);
    # 'sched' : uplink interference from the users actually transmitting in
    #           other cells this slot, used to test whether the approximation
    #           is load bearing for the policy ordering.
    intf_model: str = "geom"
    surrogate: str = "warmup"     # "oracle" fits A on the whole realisation
    beta_iso: float = 0.08
    log_inr: bool = False       # record the realised interference-to-noise ratio

    # --- CET estimator ---
    horizons: tuple = (0, 5, 10, 20)
    w_err_deg: float = 0.0

    # --- orchestrator ---
    V: float = 2.0
    theta_i: float = 0.005
    eta_floor: float = 0.30
    ho_lookahead: float = 0.5
    adapt: bool = True
    cfs_target: float = 0.975

    # --- reliability ---
    deadline: float = 0.020         # critical-update deadline [s]
    crit_cet: float = 0.05          # CET above which an update is "critical"

    # --- diagnostics ---
    trace_user: int = -1

    # --- baseline knobs ---
    period_slots: int = 5
    sem_thresh: float = 0.45
    aoii_thresh: float = 0.0
    uoi_thresh: float = 0.06
    goal_thresh: float = 0.06


def hex_bs_positions(area, n_bs):
    c = area / 2.0
    if n_bs == 1:
        return np.array([[c, c]])
    r = area * 0.29
    pts = [[c, c]]
    for k in range(n_bs - 1):
        ang = 2 * np.pi * k / (n_bs - 1)
        pts.append([c + r * np.cos(ang), c + r * np.sin(ang)])
    return np.array(pts)


# ----------------------------------------------------------------------------
# Decision heads
# ----------------------------------------------------------------------------

class LinearHead:
    """Three-class margin rule on a fixed causal direction."""
    kind = 'linear'

    def __init__(self, w, theta):
        self.w = w
        self.theta = theta

    def decide(self, X):
        v = X @ self.w
        return np.where(v > self.theta, 2, np.where(v < -self.theta, 0, 1))

    def margin(self, X):
        v = np.abs(X @ self.w)
        return np.maximum(np.abs(v - self.theta), 1e-3)

    def wloc(self, X):
        return np.broadcast_to(self.w, (X.shape[0], self.w.size))


class MLPHead:
    """Three-class MLP decision head; the local boundary normal is the gradient
    of the margin between the top two classes."""
    kind = 'mlp'

    def __init__(self, W1, b1, W2, b2, bias=None):
        self.W1, self.b1, self.W2, self.b2 = W1, b1, W2, b2
        self.bias = np.zeros(W2.shape[1]) if bias is None else bias

    def _fwd(self, X):
        z1 = X @ self.W1 + self.b1
        a1 = np.tanh(z1)
        return a1 @ self.W2 + self.b2 + self.bias, a1

    def decide(self, X):
        z, _ = self._fwd(X)
        return np.argmax(z, axis=1)

    def _top2(self, X):
        z, a1 = self._fwd(X)
        idx = np.argsort(-z, axis=1)
        i1, i2 = idx[:, 0], idx[:, 1]
        n = X.shape[0]
        gap = z[np.arange(n), i1] - z[np.arange(n), i2]
        # gradient of (z_i1 - z_i2) wrt X
        dz = self.W2[:, i1] - self.W2[:, i2]          # (h, n)
        g = ((1 - a1 ** 2).T * dz)                     # (h, n)
        grad = self.W1 @ g                             # (d, n)
        return gap, grad.T                             # (n,), (n,d)

    def margin(self, X):
        gap, grad = self._top2(X)
        return np.maximum(gap / np.maximum(np.linalg.norm(grad, axis=1), 1e-9), 1e-3)

    def wloc(self, X):
        _, grad = self._top2(X)
        return grad / np.maximum(np.linalg.norm(grad, axis=1, keepdims=True), 1e-9)


# ----------------------------------------------------------------------------
# Latent-state generators (policy independent -> pre-generated)
# ----------------------------------------------------------------------------

def gen_linear(cfg, A, rng, K, N):
    d = cfg.d
    X = np.empty((K + 1, N, d))
    x = rng.normal(0, 0.6, (N, d))
    X[0] = x
    for k in range(K):
        x = x @ A.T + rng.normal(0, cfg.sigma_w, (N, d))
        ev = rng.random(N) < cfg.p_event
        if ev.any():
            j = rng.normal(0, 1, (int(ev.sum()), d))
            j /= np.linalg.norm(j, axis=1, keepdims=True)
            x[ev] += cfg.event_mag * j * rng.choice([-1, 1], (int(ev.sum()), 1))
        X[k + 1] = x
    return X


def gen_pose(cfg, rng, K, N):
    """Non-linear, non-Gaussian head-pose / attention model (scenario S3).

    State: [yaw, pitch, yaw_rate, pitch_rate, target_bearing, closing_rate].
    Angular rates follow a heavy-tailed Ornstein-Uhlenbeck process punctuated by
    saccadic impulses and saturated at a physiological limit; the attention
    target switches as a discrete jump process; the closing rate is passed
    through a smooth saturating non-linearity. Parameter magnitudes follow
    reported head-motion and saccade statistics for seated XR use.
    """
    d = 6
    dt = cfg.dt
    X = np.empty((K + 1, N, d))
    yaw = rng.uniform(-0.6, 0.6, N)
    pit = rng.uniform(-0.35, 0.35, N)
    yr = np.zeros(N)
    pr = np.zeros(N)
    bear = rng.uniform(-1.0, 1.0, N)
    clos = rng.normal(0, 0.4, N)
    X[0] = np.stack([yaw, pit, yr, pr, bear, clos], axis=1)
    a, s, nu = cfg.ou_a, cfg.ou_s, cfg.t_df
    for k in range(K):
        # heavy-tailed innovations (Student-t, unit-scaled)
        tn = rng.standard_t(nu, (N, 2)) / np.sqrt(nu / (nu - 2.0))
        yr = a * yr + s * tn[:, 0]
        pr = a * pr + 0.6 * s * tn[:, 1]
        sac = rng.random(N) < cfg.sac_rate
        if sac.any():
            m = int(sac.sum())
            sgn = rng.choice([-1.0, 1.0], m)
            yr[sac] += cfg.sac_mag * sgn * rng.random(m)
            pr[sac] += 0.4 * cfg.sac_mag * rng.choice([-1.0, 1.0], m) * rng.random(m)
        # physiological saturation (non-linear)
        yr = cfg.rate_max * np.tanh(yr / cfg.rate_max)
        pr = 0.6 * cfg.rate_max * np.tanh(pr / (0.6 * cfg.rate_max))
        yaw = np.clip(yaw + yr * dt, -1.6, 1.6)
        pit = np.clip(pit + pr * dt, -0.8, 0.8)
        # attention target: discrete switches + slow drift
        sw = rng.random(N) < cfg.tgt_rate
        if sw.any():
            bear[sw] = rng.uniform(-1.2, 1.2, int(sw.sum()))
        bear = 0.999 * bear + 0.01 * rng.standard_t(nu, N) / np.sqrt(nu / (nu - 2.0)) * 0.05
        clos = 0.99 * clos + 0.06 * rng.normal(0, 1, N)
        X[k + 1] = np.stack([yaw, pit, yr, pr, bear,
                             1.5 * np.tanh(clos)], axis=1)
    return X


_CAL_CACHE = {}


# ----------------------------------------------------------------------------
# Simulator
# ----------------------------------------------------------------------------

class Simulator:
    def __init__(self, cfg: Config, policy, scenario: str = "S1"):
        self.cfg = cfg
        self.policy = policy
        self.scenario = scenario
        # --- dedicated streams: all indexed by the seed only, so that every
        #     policy sees the identical environment realisation (CRN).
        self.mrng = np.random.default_rng(100_000 + cfg.seed)   # task model
        self.srng = np.random.default_rng(300_000 + cfg.seed)   # latent state
        self.crng = np.random.default_rng(400_000 + cfg.seed)   # channel/mobility
        self.erng = np.random.default_rng(500_000 + cfg.seed)   # erasure / noise
        self._build()

    # ------------------------------------------------------------------
    def _build(self):
        c = self.cfg
        self._it = -1
        self._ck = self._rk = self._pk = -2
        self._pl = self._rs = self._pw = None
        self._inr_log = []
        N = c.n_users
        self.N = N
        self.nsteps = K = int(c.T / c.dt)
        mrng, srng, crng, erng = self.mrng, self.srng, self.crng, self.erng

        # ---------------- application model ----------------
        if c.model == 'lin':
            d = c.d
            off = mrng.normal(0, 0.05, (d, d))
            np.fill_diagonal(off, 0.0)
            M = np.eye(d) + off
            M = M / np.max(np.abs(np.linalg.eigvals(M)))
            self.A = c.rho * M                       # true and assumed dynamics
            self.Q = (c.sigma_w ** 2) * np.eye(d)
            self.X = gen_linear(c, self.A, srng, K, N)
        elif c.model == 'trace':
            # A recorded motion trace enters through exactly the interface the
            # generative models use: a pre-generated (K+1, N, d) array that no
            # policy can influence, so common random numbers still hold.  The
            # orchestrator again gets only a least-squares linear surrogate
            # identified from the warm-up window.
            Xt = np.load(c.trace_path)
            if Xt.shape[0] < K + 1:
                reps = int(np.ceil((K + 1) / Xt.shape[0]))
                Xt = np.concatenate([Xt] * reps, axis=0)
            if Xt.shape[1] < N:
                Xt = np.concatenate(
                    [Xt] * int(np.ceil(N / Xt.shape[1])), axis=1)
            # a per-user circular phase offset, drawn from the state stream, so
            # that the seed still selects the realisation
            off = srng.integers(0, Xt.shape[0], N)
            self.X = np.stack([np.roll(Xt[:, u % Xt.shape[1], :], -off[u],
                                       axis=0)[:K + 1] for u in range(N)],
                              axis=1)
            d = self.X.shape[2]
            kcal = min(int(c.warmup / c.dt), K - 1)
            Z0 = self.X[:kcal].reshape(-1, d)
            Z1 = self.X[1:kcal + 1].reshape(-1, d)
            self.A = np.linalg.lstsq(Z0, Z1, rcond=None)[0].T
            self.Q = np.cov((Z1 - Z0 @ self.A.T).T)
        else:
            d = 6
            self.X = gen_pose(c, srng, K, N)
            # the orchestrator has only a *fitted linear surrogate* of the
            # unknown non-linear dynamics, identified causally from the
            # warm-up window alone (a short calibration phase) and never from
            # the measurement window
            kcal = min(int(c.warmup / c.dt), K - 1)
            if getattr(c, 'surrogate', 'warmup') == 'oracle':
                kcal = K - 1          # clairvoyant: the whole realisation
            Z0 = self.X[:kcal].reshape(-1, d)
            Z1 = self.X[1:kcal + 1].reshape(-1, d)
            self.A = np.linalg.lstsq(Z0, Z1, rcond=None)[0].T
            res = Z1 - Z0 @ self.A.T
            self.Q = np.cov(res.T)
        self.d = d

        # ---------------- decision head ----------------
        self.head, self.theta_c = self._make_head(mrng)
        c.theta_c = self.theta_c

        # ---------------- CET kernels ----------------
        Ssum = np.zeros((d, d))
        cache = {0: (np.eye(d), np.zeros((d, d)))}
        for h in range(1, max(c.horizons) + 1):
            Ssum = self.A @ Ssum @ self.A.T + self.Q
            cache[h] = (np.linalg.matrix_power(self.A, h), Ssum.copy())
        self.Ah = {h: cache[h][0] for h in c.horizons}
        self.Sg = {h: cache[h][1] for h in c.horizons}
        self.Apow = [np.eye(d)]
        for _ in range(60):
            self.Apow.append(self.A @ self.Apow[-1])

        # ---------------- pre-generated randomness ----------------
        self.U_er = erng.random((K, N))                       # erasure draws
        self.Z_rec = erng.normal(0, 1, (K, N, d))             # recon. noise
        self.J_bh = np.abs(erng.normal(0, 1, (K, N)))         # backhaul jitter
        self.pos = crng.uniform(0.05 * c.area, 0.95 * c.area, (N, 2))
        self.wp = crng.uniform(0, c.area, (N, 2))
        self.spd = crng.uniform(c.v_min, c.v_max, N)
        self.shadow = crng.normal(0, c.shadow_db, (N, c.n_bs))
        self._sh_inn = crng.normal(0, c.shadow_db, (K, N, c.n_bs))
        self._wp_u = crng.random((K, N))
        self._wp_new = crng.uniform(0, c.area, (K, N, 2))

        self.xscale = float(np.std(self.X))
        self.bs = hex_bs_positions(c.area, c.n_bs)
        self.f_edge = c.f_edge * mrng.uniform(0.6, 1.4, c.n_bs)

        # ---------------- state ----------------
        self.x = self.X[0].copy()
        self.xh = self.x.copy()
        self.age_slots = np.zeros(N, dtype=np.int64)
        self.aoc = np.zeros(N)
        self.aoi = np.zeros(N)
        self.aoii = np.zeros(N)          # accumulated incorrectness (AoII)
        self.prev_dec = None
        self.since_change = np.full(N, 10 ** 6, dtype=np.int64)
        self.restore_t0 = np.full(N, -1.0)

        self.serv = self._best_bs()
        self.host = self.serv.copy()
        self.warm = self.serv.copy()
        self.warm2 = np.full(N, -2, dtype=np.int64)
        self.prewarm_q = []
        self._cold_ages = []
        self.prewarm_bits = 0.0
        self.ttt_t = np.zeros(N)
        self.ttt_cand = self.serv.copy()
        self.ho_until = np.zeros(N)

        self.rem_bits = np.zeros(N)
        self.tx_active = np.zeros(N, dtype=bool)
        self.tx_level = np.zeros(N, dtype=np.int64)
        self.tx_target = np.zeros(N, dtype=np.int64)
        self.tx_sample = np.zeros((N, d))
        self.tx_gen_t = np.zeros(N)
        self.tx_energy = np.zeros(N)
        self.tx_cet = np.zeros(N)
        self.pending = np.zeros(N, dtype=bool)
        self.inflight = []
        self.node_free = np.zeros(c.n_bs + 1)

        self.m = dict(steps=0, correct=0, crit_steps=0, crit_correct=0,
                      cfs=0.0, cfs_dec=0.0, cfs_sem=0.0, cfs_tmp=0.0,
                      aoc=0.0, aoi=0.0, bits=0.0, updates=0,
                      energy=0.0, ho=0, mig=0, sched=0,
                      crit_gen=0, crit_ok=0, pw=0.0)
        self.lat_samples, self.lat_crit, self.restore = [], [], []
        self.aoc_samples, self.cfs_series, self.acc_series = [], [], []
        self.trace = {k: [] for k in ('t', 'aoi', 'aoc', 'dc', 'cet',
                                      'dec', 'dechat', 'tx', 'cfs')}
        self.orch_time = 0.0

    # ------------------------------------------------------------------
    def _make_head(self, mrng):
        """Build the decision head and calibrate it to the target ground-truth
        decision-transition rate, so that task difficulty is comparable across
        seeds, scenarios and head types."""
        c, d = self.cfg, self.d
        key = (c.seed, c.model, c.head, c.trans_rate, c.dt, d,
               c.sigma_w, c.p_event, c.event_mag, c.rho, c.sac_rate, c.ou_s)
        Xc = self.X[:, :min(self.N, 48), :]
        Kc = Xc.shape[0]
        if c.head == 'linear':
            w = mrng.normal(0, 1, d)
            w /= np.linalg.norm(w)
            if key in _CAL_CACHE:
                return LinearHead(w, _CAL_CACHE[key]), _CAL_CACHE[key]
            hist = Xc @ w
            cand = np.quantile(np.abs(hist), np.linspace(0.40, 0.998, 60))
            best, berr = cand[-1], np.inf
            for th in cand:
                cls = np.where(hist > th, 2, np.where(hist < -th, 0, 1))
                rate = (cls[1:] != cls[:-1]).sum() / (cls.shape[1] * (Kc - 1) * c.dt)
                if abs(rate - c.trans_rate) < berr:
                    berr, best = abs(rate - c.trans_rate), th
            _CAL_CACHE[key] = float(best)
            return LinearHead(w, float(best)), float(best)
        # --- MLP head
        nh = 12
        W1 = mrng.normal(0, 1.0 / np.sqrt(d), (d, nh))
        b1 = mrng.normal(0, 0.2, nh)
        W2 = mrng.normal(0, 1.0 / np.sqrt(nh), (nh, 3))
        b2 = mrng.normal(0, 0.1, 3)
        if key in _CAL_CACHE:
            bmid = _CAL_CACHE[key]
            return MLPHead(W1, b1, W2, b2, np.array([0.0, bmid, 0.0])), 1.0
        flat = Xc.reshape(-1, d)
        z, _ = MLPHead(W1, b1, W2, b2)._fwd(flat)
        best, berr = 0.0, np.inf
        for bmid in np.linspace(-1.5, 3.0, 46):
            zz = z + np.array([0.0, bmid, 0.0])
            cls = np.argmax(zz, axis=1).reshape(Kc, -1)
            rate = (cls[1:] != cls[:-1]).sum() / (cls.shape[1] * (Kc - 1) * c.dt)
            if abs(rate - c.trans_rate) < berr:
                berr, best = abs(rate - c.trans_rate), float(bmid)
        _CAL_CACHE[key] = best
        return MLPHead(W1, b1, W2, b2, np.array([0.0, best, 0.0])), 1.0

    # ------------------------------------------------------------------
    def _pathloss_db(self):
        c = self.cfg
        if self._ck == self._it:
            return self._pl
        dist = np.linalg.norm(self.pos[:, None, :] - self.bs[None, :, :], axis=2)
        dist = np.maximum(dist, 10.0)
        pl = 32.4 + 20 * np.log10(c.fc_GHz) + 31.9 * np.log10(dist)
        self._pl = pl + self.shadow
        self._ck = self._it
        return self._pl

    def _rsrp_dbm(self):
        if self._rk == self._it:
            return self._rs
        self._rs = self.cfg.p_tx_dbm + self.cfg.ant_gain_db - self._pathloss_db()
        self._rk = self._it
        return self._rs

    def _best_bs(self):
        return np.argmax(self._rsrp_dbm(), axis=1)

    def _powers(self):
        c = self.cfg
        sched = (c.intf_model == 'sched')
        if self._pk == self._it and not sched:
            return self._pw
        rsrp = self._rsrp_dbm()
        srv = rsrp[np.arange(self.N), self.serv]
        lin = 10 ** (rsrp / 10.0)
        S = 10 ** (srv / 10.0)
        if not sched:
            I = c.beta_iso * (lin.sum(axis=1) - S)
        else:
            # uplink interference at the serving cell from the users that are
            # actually transmitting to *other* cells in this slot
            act = self.tx_active
            if act.any():
                tot = lin[act].sum(axis=0)                     # (n_bs,)
                same = np.zeros(c.n_bs)
                np.add.at(same, self.serv[act],
                          lin[act, self.serv[act]])
                I = c.beta_iso * (tot[self.serv] - same[self.serv])
            else:
                I = np.zeros(self.N)
            I = np.maximum(I, 0.0)
        self._pw = (S, I)
        self._pk = self._it
        return self._pw

    def _n0(self):
        return 10 ** ((-174 + self.cfg.nf_db) / 10.0)

    def sinr_at(self, S, I, bw):
        return S / (I + self._n0() * bw)

    def _sinr_db(self):
        c = self.cfg
        S, I = self._powers()
        return 10 * np.log10(self.sinr_at(S, I, c.bw_bs / c.max_conc))

    # ------------------------------------------------------------------
    def _mobility(self, it):
        c = self.cfg
        v = self.wp - self.pos
        dn = np.linalg.norm(v, axis=1, keepdims=True)
        redraw = (dn[:, 0] < 5.0) | (self._wp_u[it] < c.pause_p)
        if redraw.any():
            self.wp[redraw] = self._wp_new[it][redraw]
            v = self.wp - self.pos
            dn = np.linalg.norm(v, axis=1, keepdims=True)
        self.pos += (v / np.maximum(dn, 1e-6)) * (self.spd[:, None] * c.dt)
        np.clip(self.pos, 0, c.area, out=self.pos)
        self.shadow = 0.999 * self.shadow + np.sqrt(1 - 0.999 ** 2) * self._sh_inn[it]

    def _handover(self, t):
        c = self.cfg
        rsrp = self._rsrp_dbm()
        best = np.argmax(rsrp, axis=1)
        srv_v = rsrp[np.arange(self.N), self.serv]
        best_v = rsrp[np.arange(self.N), best]
        trig = (best != self.serv) & (best_v > srv_v + c.ho_hyst_db)
        same = trig & (best == self.ttt_cand)
        self.ttt_t = np.where(same, self.ttt_t + c.dt, 0.0)
        self.ttt_cand = np.where(trig, best, self.serv)
        do_ho = same & (self.ttt_t >= c.ttt)
        if do_ho.any():
            self.serv[do_ho] = best[do_ho]
            self.ttt_t[do_ho] = 0.0
            self.ho_until[do_ho] = t + c.ho_gap
            self.m['ho'] += int(do_ho.sum())
        self.ho_margin = best_v - srv_v
        return do_ho

    # ------------------------------------------------------------------
    def _rotate(self, W):
        """Apply the orchestrator's angular model error to local normals."""
        c = self.cfg
        if c.w_err_deg <= 0:
            return W
        a = np.deg2rad(c.w_err_deg)
        U = self._werr_u
        U = U - (np.sum(U * W, axis=1, keepdims=True)) * W
        U /= np.maximum(np.linalg.norm(U, axis=1, keepdims=True), 1e-9)
        return np.cos(a) * W + np.sin(a) * U

    def _cet(self, level_sigma):
        """Closed-form Causal Effect of Transmission, per user.

        p_no(h)  = P(|w'A^h e + n_h| > m),           n_h ~ N(0, S_h)
        p_wit(h) = P(|w'A^h z + n_h| > m),           z ~ N(0, s_l^2 I)
                 -> variance S_h + s_l^2 ||A^h' w||^2
        """
        c = self.cfg
        e = self.x - self.xh
        W = self.head.wloc(self.x)
        margin = self.head.margin(self.x)
        if c.w_err_deg > 0:
            W = self._rotate(W)
        cet = np.zeros(self.N)
        for h in c.horizons:
            Ah, Sh = self.Ah[h], self.Sg[h]
            mu = np.einsum('ij,ij->i', e @ Ah.T, W)
            s_no = np.einsum('ij,ij->i', W @ Sh, W)
            sig_no = np.sqrt(np.maximum(s_no, 1e-12))
            p_no = ndtr((-margin - mu) / sig_no) + 1.0 - ndtr((margin - mu) / sig_no)
            gh = np.sum((W @ Ah) ** 2, axis=1)          # ||A^h' w||^2
            sig_w = np.sqrt(np.maximum(s_no + level_sigma ** 2 * gh, 1e-12))
            p_w = 2.0 * (1.0 - ndtr(margin / sig_w))
            cet += np.maximum(p_no - p_w, 0.0)
            if h == c.horizons[0]:
                self._pw0 = p_w        # irreducible post-update error prob.
        cet /= len(c.horizons)
        mismatch = self.head.decide(self.x) != self.head.decide(self.xh)
        return cet, margin, mismatch

    def p_err_now(self):
        """Estimated current decision-error probability without transmitting
        (the h=0 term of the estimator); used by the goal-oriented baseline."""
        W = self.head.wloc(self.x)
        if self.cfg.w_err_deg > 0:
            W = self._rotate(W)
        margin = self.head.margin(self.x)
        e = self.x - self.xh
        h = self.cfg.horizons[min(1, len(self.cfg.horizons) - 1)]
        Ah, Sh = self.Ah[h], self.Sg[h]
        mu = np.einsum('ij,ij->i', e @ Ah.T, W)
        sig = np.sqrt(np.maximum(np.einsum('ij,ij->i', W @ Sh, W), 1e-12))
        return ndtr((-margin - mu) / sig) + 1.0 - ndtr((margin - mu) / sig)

    def request_prewarm(self, mask, targets, t):
        for u in np.where(mask)[0]:
            tg = int(targets[u])
            if tg >= 0 and tg != self.warm[u] and tg != self.warm2[u] and \
               not any(q[1] == u and q[2] == tg for q in self.prewarm_q):
                self.prewarm_q.append((t + self.cfg.mig_delay, u, tg))
                self.prewarm_bits += 2.0 * self.cfg.B0

    def _decide(self, s):
        return self.head.decide(s)

    def _cfs_parts(self):
        c = self.cfg
        dec = (self.head.decide(self.x) == self.head.decide(self.xh)).astype(float)
        W = self.head.wloc(self.x)
        dc = np.einsum('ij,ij->i', self.x - self.xh, W)
        mg = c.sigma_s * self.head.margin(self.x) + 0.10
        sem = np.exp(-(dc ** 2) / (2 * mg ** 2))
        tmp = np.exp(-self.aoc / c.tau_a)
        return dec, sem, tmp

    def _cfs(self):
        c = self.cfg
        dec, sem, tmp = self._cfs_parts()
        return c.a_dec * dec + c.a_sem * sem + c.a_tmp * tmp

    # ------------------------------------------------------------------
    def run(self):
        c = self.cfg
        dt = c.dt
        lvl_bits = np.array([l[0] for l in c.levels]) * c.B0
        lvl_sig = np.array([l[1] for l in c.levels])
        p_tx_w = 10 ** ((c.p_tx_dbm - 30) / 10.0)
        warm = int(c.warmup / dt)
        self.crit_win = int(0.200 / dt)
        e_enc = 1000.0 * c.kappa * (c.f_local ** 2) * (c.cycles_update * 0.25)  # mJ
        if c.w_err_deg > 0:
            self._werr_u = self.mrng.normal(0, 1, (self.N, self.d))

        for it in range(self.nsteps):
            t = it * dt
            self._it = it
            # ---- 1. physical layer
            self._mobility(it)
            self._ck = self._rk = self._pk = -2
            self._handover(t)
            self._pk = -2
            sinr_db = self._sinr_db()

            # ---- 2. latent state (pre-generated: identical for every policy)
            self.x = self.X[it + 1]
            self.xh = self.xh @ self.A.T
            self.age_slots += 1
            self.aoi += dt

            # ---- 3. importance
            cet, margin, mismatch = self._cet(lvl_sig[1])
            self.aoc += np.maximum(cet - c.psi0, 0.0)
            self.aoii += mismatch * dt

            # ---- 4. orchestration
            t0 = time.perf_counter()
            free = ~self.tx_active & ~self.pending & (t >= self.ho_until)
            sel, lvl, tgt = self.policy.decide(self, t, it, cet, margin,
                                               mismatch, sinr_db, free)
            self.orch_time += time.perf_counter() - t0
            sel = sel & free
            if sel.any():
                idx = np.where(sel)[0]
                bs_i = self.serv[idx]
                order = np.lexsort((-self.policy.last_score[idx], bs_i))
                idx_s, bs_s = idx[order], bs_i[order]
                cnt_g = np.bincount(bs_s, minlength=c.n_bs)
                starts = np.concatenate(([0], np.cumsum(cnt_g)[:-1]))
                rank = np.arange(idx_s.size) - starts[bs_s]
                busy = np.bincount(self.serv[self.tx_active], minlength=c.n_bs)
                keep = rank < np.maximum(c.max_conc - busy[bs_s], 0)
                sel = np.zeros(self.N, dtype=bool)
                sel[idx_s[keep]] = True
            if sel.any():
                self.tx_active[sel] = True
                self.pending[sel] = True
                self.tx_level[sel] = lvl[sel]
                self.tx_target[sel] = tgt[sel]
                self.rem_bits[sel] = lvl_bits[lvl[sel]]
                self.tx_sample[sel] = self.x[sel]
                self.tx_gen_t[sel] = t
                self.tx_cet[sel] = cet[sel]
                self.tx_energy[sel] = 0.0
                self.m['sched'] += int(sel.sum())
                ncrit = int((cet[sel] > c.crit_cet).sum())
                if it > warm:
                    self.m['crit_gen'] += ncrit

            # ---- 5. uplink
            act_idx = np.where(self.tx_active)[0]
            if act_idx.size:
                nb = np.bincount(self.serv[act_idx], minlength=c.n_bs)
                share = c.bw_bs / np.maximum(nb[self.serv[act_idx]], 1)
                Sp, Ip = self._powers()
                if c.log_inr and t >= c.warmup:
                    self._inr_log.append(Ip[act_idx] /
                                         np.maximum(self._n0() * share, 1e-30))
                rate = share * np.log2(1 + self.sinr_at(Sp[act_idx], Ip[act_idx], share))
                rate = np.where(t < self.ho_until[act_idx], 0.0, rate)
                sent = np.minimum(self.rem_bits[act_idx], rate * dt)
                frac = np.where(rate > 0, sent / np.maximum(rate * dt, 1e-9), 0.0)
                self.tx_energy[act_idx] += p_tx_w * dt * frac
                self.rem_bits[act_idx] -= sent
                self.m['bits'] += sent.sum()
                for u in act_idx[self.rem_bits[act_idx] <= 1e-6]:
                    self.tx_active[u] = False
                    # energy is spent whether or not the block survives
                    self.m['energy'] += 1000.0 * self.tx_energy[u] + e_enc
                    # Residual block error after hybrid ARQ.  The logistic term
                    # is scaled by (1 - p_loss_base) rather than by 1/2, so
                    # that the erasure probability tends to one as the SINR
                    # falls away instead of saturating near one half: with the
                    # old prefactor a user in deep outage still delivered about
                    # half of its blocks, which flattered every policy and in
                    # particular the ones that transmit rarely and at bad SINR.
                    bler = (c.p_loss_base
                            + (1.0 - c.p_loss_base) / (1 + np.exp(sinr_db[u] - 2.0)))
                    if self.U_er[it, u] < bler:
                        self.pending[u] = False        # erased: counted as a miss
                        continue
                    node = self.tx_target[u]
                    ni = c.n_bs if node < 0 else node
                    arr = t
                    if node < 0:
                        arr += c.bh_delay + c.bh_jit * self.J_bh[it, u]
                    else:
                        if node != self.serv[u]:
                            arr += c.mig_delay
                        if node != self.warm[u] and node != self.warm2[u]:
                            arr += c.mig_delay
                            self.m['mig'] += 1
                            self._cold_ages.append(int(self.age_slots[u]))
                    f = self.f_edge[node] if node >= 0 else c.f_cloud
                    fin = max(arr, self.node_free[ni]) + c.cycles_update / f
                    self.node_free[ni] = fin
                    self.inflight.append((fin, u, self.tx_level[u], node,
                                          self.tx_gen_t[u],
                                          self.tx_sample[u].copy(),
                                          float(self.tx_cet[u]), it))

            # ---- 5b. background pre-warming
            if self.prewarm_q:
                rest = []
                for (tr, u, tg) in self.prewarm_q:
                    if tr <= t:
                        self.warm2[u] = tg
                    else:
                        rest.append((tr, u, tg))
                self.prewarm_q = rest

            # ---- 6. arrivals
            if self.inflight:
                keep = []
                for rec in self.inflight:
                    fin, u, lv, node, gen, samp, cval, git = rec
                    if fin <= t:
                        lag = min(int(round((t - gen) / dt)), 60)
                        self.xh[u] = self.Apow[lag] @ samp + \
                            lvl_sig[lv] * self.Z_rec[it, u]
                        self.age_slots[u] = 0
                        self.pending[u] = False
                        self.aoc[u] = 0.0
                        self.aoi[u] = 0.0
                        self.aoii[u] = 0.0
                        self.host[u] = node
                        if node >= 0:
                            self.warm[u] = node
                        lat = fin - gen + (c.bh_delay if node < 0 else 0.0)
                        self.m['updates'] += 1
                        if git > warm:
                            self.lat_samples.append(lat)
                            if cval > c.crit_cet:
                                self.lat_crit.append(lat)
                                if lat <= c.deadline:
                                    self.m['crit_ok'] += 1
                    else:
                        keep.append(rec)
                self.inflight = keep

            # ---- 7. metrics
            dtrue = self.head.decide(self.x)
            dhat = self.head.decide(self.xh)
            if self.prev_dec is None:
                self.prev_dec = dtrue.copy()
            changed = dtrue != self.prev_dec
            self.since_change = np.where(changed, 0, self.since_change + 1)
            self.prev_dec = dtrue
            ok = dtrue == dhat
            # policy-independent decision-restoration delay
            if changed.any():
                self.restore_t0[changed & ~ok] = t
            done_r = (self.restore_t0 >= 0) & ok
            if done_r.any() and it > warm:
                self.restore.extend((t - self.restore_t0[done_r]).tolist())
            self.restore_t0[done_r] = -1.0

            if it > warm:
                crit = self.since_change <= self.crit_win
                self.m['steps'] += self.N
                self.m['correct'] += int(ok.sum())
                self.m['crit_steps'] += int(crit.sum())
                self.m['crit_correct'] += int((ok & crit).sum())
                dec, sem, tmp = self._cfs_parts()
                cfs = c.a_dec * dec + c.a_sem * sem + c.a_tmp * tmp
                self.m['cfs'] += float(cfs.sum())
                self.m['cfs_dec'] += float(dec.sum())
                self.m['cfs_sem'] += float(sem.sum())
                self.m['cfs_tmp'] += float(tmp.sum())
                self.m['aoc'] += float(self.aoc.sum())
                self.m['pw'] += float(self._pw0.sum())
                self.m['aoi'] += float(self.aoi.sum())
                if it % 10 == 0:
                    self.aoc_samples.append(self.aoc.copy())
                    self.cfs_series.append(float(cfs.mean()))
                    self.acc_series.append(float(ok.mean()))

            if c.trace_user >= 0:
                u = c.trace_user
                W = self.head.wloc(self.x)
                self.trace['t'].append(t)
                self.trace['aoi'].append(float(self.aoi[u]))
                self.trace['aoc'].append(float(self.aoc[u]))
                self.trace['dc'].append(float((self.x[u] - self.xh[u]) @ W[u]))
                self.trace['cet'].append(float(cet[u]))
                self.trace['dec'].append(int(dtrue[u]))
                self.trace['dechat'].append(int(dhat[u]))
                self.trace['tx'].append(bool(sel[u]))
                self.trace['cfs'].append(float(self._cfs()[u]))

            if hasattr(self.policy, 'post_step'):
                self.policy.post_step(self, t, it)

        return self._results()

    # ------------------------------------------------------------------
    def _results(self):
        c, m = self.cfg, self.m
        eff_T = c.T - c.warmup
        aocs = np.concatenate(self.aoc_samples) if self.aoc_samples else np.zeros(1)
        lat = np.array(self.lat_samples) if self.lat_samples else np.zeros(1)
        latc = np.array(self.lat_crit) if self.lat_crit else np.zeros(1)
        res = np.array(self.restore) if self.restore else np.zeros(1)
        cg = max(m['crit_gen'], 1)
        return dict(
            decision_accuracy=100.0 * m['correct'] / max(m['steps'], 1),
            critical_accuracy=100.0 * m['crit_correct'] / max(m['crit_steps'], 1),
            cfs=m['cfs'] / max(m['steps'], 1),
            cfs_dec=m['cfs_dec'] / max(m['steps'], 1),
            cfs_sem=m['cfs_sem'] / max(m['steps'], 1),
            cfs_tmp=m['cfs_tmp'] / max(m['steps'], 1),
            aoc_mean=m['aoc'] / max(m['steps'], 1),
            aoc_p95=float(np.percentile(aocs, 95)),
            p_with_mean=m['pw'] / max(m['steps'], 1),
            aoi_mean=1000.0 * m['aoi'] / max(m['steps'], 1),
            latency_mean=1000.0 * float(lat.mean()),
            latency_p99=1000.0 * float(np.percentile(lat, 99)),
            crit_latency_mean=1000.0 * float(latc.mean()),
            crit_latency_p99=1000.0 * float(np.percentile(latc, 99)),
            crit_miss=100.0 * (1.0 - m['crit_ok'] / cg),
            scdd=100.0 * m['crit_ok'] / cg,
            crit_generated=m['crit_gen'] / eff_T / self.N,
            restore_mean=1000.0 * float(res.mean()),
            restore_p99=1000.0 * float(np.percentile(res, 99)),
            restore_le20=100.0 * float((res <= c.deadline).mean()),
            uplink_mbps=m['bits'] / eff_T / 1e6,
            update_rate=m['updates'] / eff_T / self.N,
            energy_mj=m['energy'] / eff_T / self.N,
            handovers=m['ho'] / eff_T,
            migrations=m['mig'] / eff_T,
            prewarm_mbps=self.prewarm_bits / eff_T / 1e6,
            orch_us=1e6 * self.orch_time / self.nsteps,
            crit_frac=100.0 * m['crit_steps'] / max(m['steps'], 1),
            cfs_series=self.cfs_series,
            acc_series=self.acc_series,
            trace=self.trace,
        )
